import React from 'react';
import { HEROES } from '../game/heroes';
import { MAPS } from '../game/maps';
import { analyzeAdaptiveMemory } from '../game/adaptiveAI';
import { computeHeroStats, xpRequiredForLevel } from '../game/progression';
import { AdaptiveBotMemory, GameMode, PlayerProfile } from '../game/types';

interface TitleOverlayProps {
  profile: PlayerProfile;
  memory: AdaptiveBotMemory;
  onStart: () => void;
  onModeChange: (mode: GameMode) => void;
  onOpenHeroes: () => void;
  onOpenMaps: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  profile,
  memory,
  onStart,
  onModeChange,
  onOpenHeroes,
  onOpenMaps,
}) => {
  const hero = HEROES[profile.selectedHeroId];
  const progress = profile.heroProgress[profile.selectedHeroId];
  const stats = computeHeroStats(hero.id, progress);
  const map = MAPS[profile.selectedMapId];
  const insights = analyzeAdaptiveMemory(memory);
  const xpNeeded = xpRequiredForLevel(progress.level);
  const xpPct = Math.min(100, Math.round((progress.xp / xpNeeded) * 100));

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between p-6 md:p-10 pointer-events-none">
      {/* Subtle left-side reading scrim over the live sweeping arena canvas */}
      <div
        className="fixed inset-y-0 left-0 w-full md:w-[56%] pointer-events-none"
        style={{
          background:
            'linear-gradient(90deg, rgba(7,11,16,0.92) 0%, rgba(7,11,16,0.74) 68%, rgba(7,11,16,0) 100%)',
        }}
      />

      {/* Top minimal resource line (no website nav bar!) */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-3 text-xs text-slate-300 font-mono-tabular">
          <span>Scrap: <strong className="text-amber-400">{profile.scrap}</strong></span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Menang: <strong className="text-slate-100">{profile.totalWins}</strong>/{profile.totalMatches}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Bot Adaptif: <strong className="text-amber-300">Lv.{insights.adaptationLevel}</strong></span>
        </div>
      </div>

      {/* Main Focal Title Anchor (Asymmetric Left Third) */}
      <div className="relative z-10 max-w-xl my-auto pointer-events-auto">
        {/* Bespoke Inline SVG Title Emblem Lockup */}
        <svg
          viewBox="0 0 540 112"
          className="w-full max-w-[490px] h-auto mb-5"
          role="img"
          aria-label="Bayang Peluru — Tactical Stealth Arena Shooter"
        >
          <defs>
            <linearGradient id="coneBeam" x1="0%" y1="50%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.85" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
            </linearGradient>
          </defs>
          {/* Diegetic Flashlight Cone & Crosshair Crest */}
          <polygon points="34,54 156,14 156,94" fill="url(#coneBeam)" opacity="0.28" />
          <circle cx="34" cy="54" r="22" fill="#131b26" stroke="#f59e0b" strokeWidth="2.5" />
          <circle cx="34" cy="54" r="9" fill="none" stroke="#fde68a" strokeWidth="1.8" />
          <line x1="34" y1="24" x2="34" y2="38" stroke="#f59e0b" strokeWidth="2" />
          <line x1="34" y1="70" x2="34" y2="84" stroke="#f59e0b" strokeWidth="2" />
          <line x1="4" y1="54" x2="18" y2="54" stroke="#f59e0b" strokeWidth="2" />
          <line x1="50" y1="54" x2="64" y2="54" stroke="#f59e0b" strokeWidth="2" />
          <circle cx="34" cy="54" r="3" fill="#f59e0b" />

          {/* Athletic Condensed Title Wordmark */}
          <text
            x="76"
            y="64"
            fill="#f8fafc"
            fontFamily="Barlow Condensed, sans-serif"
            fontWeight="800"
            fontSize="58"
            letterSpacing="2"
          >
            BAYANG PELURU
          </text>
          <text
            x="78"
            y="90"
            fill="#94a3b8"
            fontFamily="Plus Jakarta Sans, sans-serif"
            fontWeight="600"
            fontSize="13"
            letterSpacing="1.2"
          >
            ARENA TAKTIS · BOT ADAPTIF · KOORDINASI SKUAD
          </text>
        </svg>

        {/* Active Loadout Summary Strip (Clean unboxed metadata, no pill clutter) */}
        <div className="mb-6 flex items-center gap-4 p-3.5 rounded-lg bg-[#111824]/95 border border-slate-700/60">
          <div className="relative w-16 h-16 rounded-md overflow-hidden shrink-0 bg-slate-800 border border-slate-700">
            <img
              src={hero.portraitUrl}
              alt={hero.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="font-display text-2xl font-bold tracking-wide text-slate-50 truncate">
                {hero.name} <span className="text-slate-400 font-normal text-lg">— {hero.epithet}</span>
              </h2>
              <span className="font-mono-tabular text-xs font-semibold text-amber-400 shrink-0">
                Lv.{progress.level}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-400 mt-0.5">
              <span>{hero.role}</span>
              <span aria-hidden="true">·</span>
              <span>{stats.rankTitle}</span>
              <span aria-hidden="true">·</span>
              <span>Peta: <strong className="text-slate-200">{map.name}</strong></span>
            </div>
            {/* Compact XP progress line */}
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 transition-transform origin-left"
                  style={{ width: `${xpPct}%` }}
                />
              </div>
              <span className="text-[11px] font-mono-tabular text-slate-400 shrink-0">
                {progress.xp}/{xpNeeded} XP
              </span>
            </div>
          </div>
        </div>

        {/* Mode Segmented Selector */}
        <div className="mb-5">
          <div
            role="group"
            aria-label="Pilih mode pertempuran"
            className="inline-flex p-1 rounded-lg bg-[#111824]/95 border border-slate-700/60"
          >
            <button
              type="button"
              onClick={() => onModeChange('team3v3')}
              className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                profile.selectedMode === 'team3v3'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Mode Tim 3v3
            </button>
            <button
              type="button"
              onClick={() => onModeChange('solo')}
              className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                profile.selectedMode === 'solo'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Mode Solo 1v5
            </button>
          </div>
          <p className="mt-2 text-xs text-slate-400">
            {profile.selectedMode === 'team3v3'
              ? 'Berjuang bersama 2 bot sekutu cerdas dengan visi bersama, kebangkitan rekan, dan komando taktis 1–4.'
              : 'Bertahan hidup seorang diri melawan 5 bot adaptif yang terus mempelajari pola pergerakanmu.'}
          </p>
        </div>

        {/* Action Buttons (<= 3 Menu Actions, 1 clear primary CTA) */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            data-start="true"
            onClick={(e) => {
              e.currentTarget.blur();
              onStart();
            }}
            className="px-7 py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-display text-xl font-bold tracking-wider uppercase transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            Mulai Pertempuran
          </button>

          <button
            type="button"
            onClick={onOpenHeroes}
            className="px-5 py-3.5 rounded-lg bg-[#16202e] hover:bg-[#1e2b3d] text-slate-100 border border-slate-700/80 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400"
          >
            Pahlawan &amp; Upgrade
          </button>

          <button
            type="button"
            onClick={onOpenMaps}
            className="px-5 py-3.5 rounded-lg bg-[#16202e] hover:bg-[#1e2b3d] text-slate-100 border border-slate-700/80 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400"
          >
            Peta &amp; Intel Bot
          </button>
        </div>
      </div>

      {/* Flat borderless bottom control hint line */}
      <div className="relative z-10 text-xs text-slate-400 tracking-wide">
        WASD Gerak · Mouse Bidik &amp; Tembak · Q Skill Aktif · E Ultimate · F Auto-Tembak · 1–4 Komando Tim · P Jeda
      </div>
    </div>
  );
};
