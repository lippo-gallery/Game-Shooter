import React, { useEffect, useState } from 'react';
import { HEROES } from '../game/heroes';
import { MAPS } from '../game/maps';
import { HudSnapshot, SquadCommand } from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  muted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onRestart: () => void;
  onToggleAutoFire: () => void;
  onTriggerActive: () => void;
  onTriggerUltimate: () => void;
  onSquadCommand: (cmd: SquadCommand) => void;
}

const COMMANDS: { id: SquadCommand; key: string; label: string }[] = [
  { id: 'follow', key: '1', label: 'Ikuti' },
  { id: 'attack', key: '2', label: 'Serang' },
  { id: 'defend', key: '3', label: 'Tahan' },
  { id: 'regroup', key: '4', label: 'Kumpul' },
];

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  muted,
  onToggleMute,
  onPause,
  onRestart,
  onToggleAutoFire,
  onTriggerActive,
  onTriggerUltimate,
  onSquadCommand,
}) => {
  const [ghostHp, setGhostHp] = useState(hud.playerHp);

  // Delayed trailing damage ghost bar
  useEffect(() => {
    if (hud.playerHp >= ghostHp) {
      setGhostHp(hud.playerHp);
      return;
    }
    const timer = window.setTimeout(() => setGhostHp(hud.playerHp), 280);
    return () => window.clearTimeout(timer);
  }, [hud.playerHp, ghostHp]);

  const hero = HEROES[hud.playerHeroId];
  const map = MAPS[hud.mapId];
  const hpPct = Math.max(0, Math.min(100, (hud.playerHp / Math.max(1, hud.playerMaxHp)) * 100));
  const ghostPct = Math.max(hpPct, Math.min(100, (ghostHp / Math.max(1, hud.playerMaxHp)) * 100));
  const armorPct = Math.max(0, Math.min(100, (hud.playerArmor / Math.max(1, hud.playerMaxArmor)) * 100));
  const criticalHp = hpPct > 0 && hpPct <= 30;

  const mins = Math.floor(hud.matchTime / 60);
  const secs = hud.matchTime % 60;
  const clockStr = `${mins}:${secs.toString().padStart(2, '0')}`;

  const allies = hud.actors.filter((a) => a.team === 'A' && !a.isPlayer);

  return (
    <div className="fixed inset-0 z-20 pointer-events-none select-none">
      {/* Subtle critical low-HP peripheral vignette */}
      {criticalHp && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            boxShadow: 'inset 0 0 95px rgba(220, 38, 38, 0.45)',
          }}
        />
      )}

      {/* TOP-LEFT CLUSTER: Match State, Alive Count, Adaptation Level */}
      <div className="fixed top-4 left-4 flex flex-col gap-2">
        <div className="flex items-center gap-4 px-3.5 py-2 rounded-lg bg-[#0c121b]/88 border border-slate-700/60">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">
              {hud.mode === 'team3v3' ? 'Skuad' : 'Kamu'}
            </div>
            <div className="font-display text-2xl font-bold text-emerald-400 leading-none font-mono-tabular">
              {hud.alliesAlive}
              <span className="text-slate-500 text-base">/{hud.alliesTotal}</span>
            </div>
          </div>

          <div className="w-px h-7 bg-slate-700/70" />

          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">Musuh</div>
            <div className="font-display text-2xl font-bold text-rose-400 leading-none font-mono-tabular">
              {hud.enemiesAlive}
              <span className="text-slate-500 text-base">/{hud.enemiesTotal}</span>
            </div>
          </div>

          <div className="w-px h-7 bg-slate-700/70" />

          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">Eliminasi</div>
            <div className="font-display text-2xl font-bold text-amber-400 leading-none font-mono-tabular">
              {hud.playerKills}
            </div>
          </div>

          <div className="w-px h-7 bg-slate-700/70" />

          <div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">Waktu</div>
            <div className="font-mono-tabular text-sm font-semibold text-slate-100 leading-tight mt-0.5">
              {clockStr}
            </div>
          </div>
        </div>

        {/* Compact Adaptive AI Live Readout */}
        <div className="px-3 py-1.5 rounded-md bg-[#0c121b]/82 border border-slate-800/80 text-[11px] text-slate-300 max-w-[270px]">
          <span className="font-mono-tabular text-amber-400 font-semibold">
            Bot Adaptif Lv.{hud.adaptationLevel}
          </span>
          <span aria-hidden="true" className="mx-1.5 text-slate-600">·</span>
          <span className="text-slate-300">{map.name}</span>
        </div>

        {/* Team 3v3 Allied Status Strip */}
        {hud.mode === 'team3v3' && allies.length > 0 && (
          <div className="flex flex-col gap-1">
            {allies.map((ally) => (
              <div
                key={ally.id}
                className="px-2.5 py-1.5 rounded-md bg-[#0c121b]/82 border border-slate-800/80 w-52"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-200 font-medium truncate">{ally.name}</span>
                  <span
                    className={`font-mono-tabular text-[10px] ${
                      !ally.alive
                        ? 'text-slate-500'
                        : ally.downed
                          ? 'text-amber-400 font-bold'
                          : 'text-emerald-400'
                    }`}
                  >
                    {!ally.alive ? 'Gugur' : ally.downed ? 'Tumbang!' : `${ally.hp} HP`}
                  </span>
                </div>
                <div className="mt-1 h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${ally.downed ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${Math.max(0, Math.min(100, (ally.hp / Math.max(1, ally.maxHp)) * 100))}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* TOP-CENTER: Compact Diegetic Radio Callout & Kill Feed */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 max-w-md px-4">
        {hud.radioCallout && (
          <div className="px-3.5 py-1.5 rounded-md bg-[#0c121b]/90 border border-amber-500/50 text-xs font-medium text-amber-200 text-center">
            {hud.radioCallout}
          </div>
        )}
        {hud.playerDowned && (
          <div className="px-4 py-2 rounded-md bg-rose-950/92 border border-rose-500/70 text-xs font-semibold text-rose-100 text-center">
            Kamu Tumbang! Tunggu rekan skuad membangkitkan ({Math.round(hud.playerReviveProgress * 100)}%)
          </div>
        )}
        {hud.killFeed.length > 0 && (
          <div className="flex flex-col items-center gap-1">
            {hud.killFeed.slice(-2).map((item) => (
              <div
                key={item.id}
                className={`px-2.5 py-1 rounded bg-[#0c121b]/82 text-[11px] font-medium ${
                  item.tone === 'ally'
                    ? 'text-emerald-300'
                    : item.tone === 'enemy'
                      ? 'text-rose-300'
                      : 'text-slate-300'
                }`}
              >
                {item.text}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* TOP-RIGHT CLUSTER: Utility Buttons + Live Architectural Minimap */}
      <div className="fixed top-4 right-4 flex flex-col items-end gap-2">
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            type="button"
            tabIndex={-1}
            aria-label={muted ? 'Nyalakan suara' : 'Bisukan suara'}
            title="Suara (M)"
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleMute();
            }}
            className="w-9 h-9 rounded-lg bg-[#0c121b]/90 hover:bg-[#1a2536] border border-slate-700/70 flex items-center justify-center text-slate-200 transition-colors cursor-pointer"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M11 5L6 9H2v6h4l5 4V5z" />
              {muted ? (
                <path d="M23 9l-6 6M17 9l6 6" stroke="#f87171" />
              ) : (
                <path d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14" />
              )}
            </svg>
          </button>

          <button
            type="button"
            tabIndex={-1}
            aria-label="Jeda permainan"
            title="Jeda (P)"
            onClick={(e) => {
              e.currentTarget.blur();
              onPause();
            }}
            className="w-9 h-9 rounded-lg bg-[#0c121b]/90 hover:bg-[#1a2536] border border-slate-700/70 flex items-center justify-center text-slate-200 transition-colors cursor-pointer"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor">
              <rect x="6" y="5" width="4" height="14" rx="1" />
              <rect x="14" y="5" width="4" height="14" rx="1" />
            </svg>
          </button>

          <button
            type="button"
            tabIndex={-1}
            aria-label="Ulangi pertempuran"
            title="Ulangi"
            onClick={(e) => {
              e.currentTarget.blur();
              onRestart();
            }}
            className="w-9 h-9 rounded-lg bg-[#0c121b]/90 hover:bg-[#1a2536] border border-slate-700/70 flex items-center justify-center text-slate-200 transition-colors cursor-pointer"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 12a9 9 0 109-9 9.75 9.75 0 00-6.74 2.74L3 8" />
              <path d="M3 3v5h5" />
            </svg>
          </button>
        </div>

        {/* Real-Geometry Corner Minimap */}
        <div className="w-36 sm:w-44 aspect-[16/11] rounded-lg overflow-hidden bg-[#0c121b]/90 border border-slate-700/70 p-1">
          <svg viewBox={`0 0 ${map.width} ${map.height}`} className="w-full h-full">
            <rect x="0" y="0" width={map.width} height={map.height} fill="#0b1017" />
            {map.obstacles.map((obs) => {
              if (obs.kind !== 'wall' && obs.kind !== 'low_cover') return null;
              return (
                <rect
                  key={obs.id}
                  x={obs.x}
                  y={obs.y}
                  width={obs.w}
                  height={obs.h}
                  fill={obs.kind === 'wall' ? '#334155' : '#475569'}
                />
              );
            })}
            {/* Storm ring */}
            <circle
              cx={map.width * 0.5}
              cy={map.height * 0.5}
              r={hud.stormRadius}
              fill="none"
              stroke="rgba(239,68,68,0.65)"
              strokeWidth="16"
            />
            {/* Actors */}
            {hud.actors.map((a) => {
              if (!a.alive) return null;
              if (a.team === 'B' && !a.visibleToPlayer) return null;
              return (
                <circle
                  key={a.id}
                  cx={a.x}
                  cy={a.y}
                  r={a.isPlayer ? 36 : 28}
                  fill={a.isPlayer ? '#f59e0b' : a.team === 'A' ? '#10b981' : '#ef4444'}
                />
              );
            })}
          </svg>
        </div>
      </div>

      {/* BOTTOM-LEFT CLUSTER: Hero Vitality, Armor, Ammo & Auto-Fire Toggle */}
      <div className="fixed bottom-4 left-4 flex items-end gap-3">
        <div className="p-3 rounded-lg bg-[#0c121b]/90 border border-slate-700/70 flex items-center gap-3.5 min-w-[270px] sm:min-w-[310px]">
          <div className="w-12 h-12 rounded-md overflow-hidden shrink-0 border border-amber-500/60 bg-slate-800">
            <img
              src={hero.portraitUrl}
              alt={hero.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-baseline justify-between gap-2">
              <span className="font-display text-lg font-bold text-slate-50 leading-none">
                {hero.name}
              </span>
              <span className="font-mono-tabular text-xs text-slate-300">
                <strong className={criticalHp ? 'text-rose-400' : 'text-emerald-400'}>
                  {hud.playerHp}
                </strong>
                /{hud.playerMaxHp} HP ·{' '}
                <strong className="text-sky-400">{hud.playerArmor}</strong> ARM
              </span>
            </div>

            {/* Continuous HP Bar with Trailing Ghost Bar */}
            <div className="relative mt-1.5 h-2.5 bg-slate-800 rounded-sm overflow-hidden">
              <div
                className="absolute inset-y-0 left-0 bg-amber-300/75 transition-all duration-300"
                style={{ width: `${ghostPct}%` }}
              />
              <div
                className={`absolute inset-y-0 left-0 transition-all duration-100 ${
                  criticalHp ? 'bg-rose-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${hpPct}%` }}
              />
            </div>

            {/* Armor Bar */}
            <div className="mt-1 h-1.5 bg-slate-800 rounded-sm overflow-hidden">
              <div
                className="h-full bg-sky-400 transition-all duration-100"
                style={{ width: `${armorPct}%` }}
              />
            </div>

            {/* Ammo & Auto-Fire Controls */}
            <div className="mt-2 flex items-center justify-between gap-2">
              <div className="font-mono-tabular text-xs text-slate-200">
                {hud.reloading ? (
                  <span className="text-amber-400">
                    Isi Ulang {Math.round(hud.reloadProgress * 100)}%
                  </span>
                ) : (
                  <span>
                    Peluru <strong className="text-amber-400">{hud.ammo}</strong>/{hud.maxAmmo}
                  </span>
                )}
              </div>

              <button
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onToggleAutoFire();
                }}
                className={`pointer-events-auto px-2 py-0.5 rounded text-[11px] font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer border ${
                  hud.autoFire
                    ? 'bg-amber-500/20 border-amber-500/70 text-amber-300'
                    : 'bg-slate-800 border-slate-700 text-slate-400'
                }`}
              >
                Auto-Tembak [F]: {hud.autoFire ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM-RIGHT CLUSTER: Skills [Q]/[E] & Squad Commands [1-4] */}
      <div className="fixed bottom-4 right-4 flex flex-col items-end gap-2">
        {/* Team 3v3 Live Squad Coordination Strip */}
        {hud.mode === 'team3v3' && (
          <div
            role="group"
            aria-label="Komando taktis skuad"
            className="flex items-center gap-1 p-1 rounded-lg bg-[#0c121b]/90 border border-slate-700/70 pointer-events-auto"
          >
            {COMMANDS.map((c) => {
              const active = hud.squadCommand === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    onSquadCommand(c.id);
                  }}
                  className={`px-2.5 py-1.5 rounded text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-emerald-500 text-slate-950'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  [{c.key}] {c.label}
                </button>
              );
            })}
          </div>
        )}

        {/* Active [Q] & Ultimate [E] Skill Sockets */}
        <div className="flex items-center gap-2.5 pointer-events-auto">
          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onTriggerActive();
            }}
            className={`relative min-w-[138px] p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
              hud.activeCooldown <= 0
                ? 'bg-[#121c2a]/95 border-amber-500/80 hover:bg-[#1a283c]'
                : 'bg-[#0c121b]/90 border-slate-700/70 opacity-85'
            }`}
          >
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-mono-tabular font-bold text-amber-400">[Q]</span>
              <span className="font-mono-tabular text-slate-300">
                {hud.activeCooldown > 0
                  ? `${hud.activeCooldown.toFixed(1)}d`
                  : hud.activeDuration > 0
                    ? 'AKTIF'
                    : 'SIAP'}
              </span>
            </div>
            <div className="mt-0.5 text-xs font-semibold text-slate-100 truncate">
              {hero.activeSkill.name}
            </div>
          </button>

          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onTriggerUltimate();
            }}
            className={`relative min-w-[146px] p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
              hud.ultimateCooldown <= 0
                ? 'bg-[#1a1a14]/95 border-amber-400 hover:bg-[#272417]'
                : 'bg-[#0c121b]/90 border-slate-700/70 opacity-85'
            }`}
          >
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-mono-tabular font-bold text-amber-300">[E] ULT</span>
              <span className="font-mono-tabular text-slate-300">
                {hud.ultimateCooldown > 0
                  ? `${hud.ultimateCooldown.toFixed(1)}d`
                  : hud.ultimateDuration > 0
                    ? 'AKTIF'
                    : 'SIAP'}
              </span>
            </div>
            <div className="mt-0.5 text-xs font-semibold text-slate-100 truncate">
              {hero.ultimateSkill.name}
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
