import React, { useState } from 'react';
import { HERO_LIST, HEROES } from '../game/heroes';
import {
  computeHeroStats,
  getUpgradeCost,
  MAX_UPGRADE_RANK,
  UPGRADE_META,
  xpRequiredForLevel,
} from '../game/progression';
import { HeroId, PlayerProfile, UpgradeAttribute } from '../game/types';

interface HeroRosterModalProps {
  profile: PlayerProfile;
  onSelectHero: (heroId: HeroId) => void;
  onUpgrade: (heroId: HeroId, attr: UpgradeAttribute) => void;
  onClose: () => void;
}

const UPGRADE_KEYS: UpgradeAttribute[] = ['firepower', 'vitality', 'agility', 'optics', 'skillMastery'];

export const HeroRosterModal: React.FC<HeroRosterModalProps> = ({
  profile,
  onSelectHero,
  onUpgrade,
  onClose,
}) => {
  const [inspectId, setInspectId] = useState<HeroId>(profile.selectedHeroId);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const hero = HEROES[inspectId];
  const progress = profile.heroProgress[inspectId];
  const stats = computeHeroStats(inspectId, progress);
  const xpNeeded = xpRequiredForLevel(progress.level);
  const xpPct = Math.min(100, Math.round((progress.xp / xpNeeded) * 100));
  const isEquipped = profile.selectedHeroId === inspectId;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Pahlawan dan Upgrade"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 md:p-6 bg-[#06090e]/85"
    >
      <div className="w-full max-w-5xl max-h-[90vh] flex flex-col rounded-xl bg-[#0f1621] border border-slate-700/70 shadow-2xl overflow-hidden">
        {/* Header Bar */}
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-wide text-slate-50">
              Daftar Pahlawan &amp; Bengkel Upgrade
            </h2>
            <p className="text-xs text-slate-400">
              Setiap hero memiliki latar cerita, kekuatan, kelemahan, skill unik, dan level progresif tersendiri.
            </p>
          </div>
          <div className="flex items-center gap-5 shrink-0">
            <div className="text-right">
              <div className="text-[11px] text-slate-400">Scrap Tersedia</div>
              <div className="font-mono-tabular text-lg font-bold text-amber-400">{profile.scrap}</div>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Tutup jendela pahlawan"
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>

        {/* Body Split */}
        <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-[240px_1fr] overflow-hidden">
          {/* Left Hero Selector Rail */}
          <div className="border-b md:border-b-0 md:border-r border-slate-800 p-3 flex md:flex-col gap-2 overflow-x-auto md:overflow-y-auto tactical-scroll">
            {HERO_LIST.map((item) => {
              const prog = profile.heroProgress[item.id];
              const active = item.id === inspectId;
              const selected = item.id === profile.selectedHeroId;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setInspectId(item.id)}
                  className={`flex items-center gap-3 p-2.5 rounded-lg text-left transition-colors shrink-0 md:w-full cursor-pointer border ${
                    active
                      ? 'bg-[#1a2536] border-amber-500/70'
                      : 'bg-transparent border-transparent hover:bg-slate-800/60'
                  }`}
                >
                  <div className="w-12 h-12 rounded-md overflow-hidden shrink-0 bg-slate-800 border border-slate-700 flex items-center justify-center">
                    {!failedImages[item.id] ? (
                      <img
                        src={item.portraitUrl}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        onError={() => setFailedImages((prev) => ({ ...prev, [item.id]: true }))}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="font-display text-lg font-bold text-amber-400">
                        {item.name.slice(0, 2)}
                      </span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-semibold text-sm text-slate-100 truncate">{item.name}</span>
                      <span className="font-mono-tabular text-[11px] text-amber-400 shrink-0">
                        Lv.{prog.level}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      {item.role} {selected ? '· Aktif' : ''}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Detailed Hero Dossier & Upgrades */}
          <div className="p-5 md:p-6 overflow-y-auto tactical-scroll space-y-6">
            {/* Hero Identity + Portrait + Level Bar */}
            <div className="flex flex-col sm:flex-row gap-5 items-start">
              <div className="w-32 h-32 sm:w-36 sm:h-36 rounded-lg overflow-hidden shrink-0 bg-slate-800 border border-slate-700 flex items-center justify-center">
                {!failedImages[hero.id] ? (
                  <img
                    src={hero.portraitUrl}
                    alt={`Potret ${hero.name}`}
                    referrerPolicy="no-referrer"
                    onError={() => setFailedImages((prev) => ({ ...prev, [hero.id]: true }))}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="font-display text-3xl font-bold text-amber-400">{hero.name}</span>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-display text-3xl font-bold text-slate-50 leading-none">
                      {hero.name}
                    </h3>
                    <div className="mt-1 flex flex-wrap items-center gap-x-2 text-xs text-slate-400">
                      <span className="text-amber-400 font-medium">{hero.epithet}</span>
                      <span aria-hidden="true">·</span>
                      <span>{hero.role}</span>
                      <span aria-hidden="true">·</span>
                      <span>Senjata: {hero.weapon.name}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectHero(hero.id)}
                    disabled={isEquipped}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      isEquipped
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 cursor-default'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                    }`}
                  >
                    {isEquipped ? 'Hero Terpilih' : `Pilih ${hero.name}`}
                  </button>
                </div>

                {/* Lore Story */}
                <p className="mt-3 text-sm text-slate-300 leading-relaxed">{hero.lore}</p>

                {/* Dynamic Leveling & Mastery Progress */}
                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-200 font-medium">
                      Level {progress.level} · {stats.rankTitle}
                    </span>
                    <span className="font-mono-tabular text-slate-400">
                      Daya Tempur {stats.powerRating} · {progress.xp}/{xpNeeded} XP
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500" style={{ width: `${xpPct}%` }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Strengths & Weaknesses */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800/80">
              <div>
                <h4 className="text-xs font-semibold text-emerald-400 tracking-wide mb-2">
                  Kekuatan Utama
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {hero.strengths.map((s) => (
                    <li key={s} className="leading-snug">+ {s}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-xs font-semibold text-rose-400 tracking-wide mb-2">
                  Kelemahan Taktis
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {hero.weaknesses.map((w) => (
                    <li key={w} className="leading-snug">- {w}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Upgradeable Attributes */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
                <h4 className="font-display text-xl font-bold text-slate-100">
                  Upgrade Kemampuan
                </h4>
                <div className="text-xs font-mono-tabular text-slate-400">
                  HP {stats.maxHp} · Armor {stats.maxArmor} · DMG {stats.damage} · Kec {stats.speed} · Visi {stats.visionRange}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {UPGRADE_KEYS.map((attr) => {
                  const meta = UPGRADE_META[attr];
                  const rank = progress.upgrades[attr];
                  const cost = getUpgradeCost(rank);
                  const maxed = rank >= MAX_UPGRADE_RANK;
                  const canAfford = !maxed && profile.scrap >= cost;

                  return (
                    <div
                      key={attr}
                      className="p-3 rounded-lg bg-[#141d2b] border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-slate-100">{meta.label}</span>
                          <span className="text-[11px] font-mono-tabular text-amber-400">
                            {meta.bonusPerRank}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">{meta.effectDesc}</p>
                        {/* 5 Upgrade Sockets */}
                        <div className="mt-2 flex items-center gap-1.5" aria-label={`Rank ${rank} dari 5`}>
                          {[0, 1, 2, 3, 4].map((idx) => (
                            <span
                              key={idx}
                              className={`h-1.5 flex-1 rounded-sm ${
                                idx < rank ? 'bg-amber-500' : 'bg-slate-700/80'
                              }`}
                            />
                          ))}
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => onUpgrade(hero.id, attr)}
                        aria-label={`Upgrade ${meta.label} untuk ${hero.name}`}
                        className={`px-3 py-2 rounded-md text-xs font-semibold font-mono-tabular transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          maxed
                            ? 'bg-slate-800 text-emerald-400 cursor-default'
                            : canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                              : 'bg-slate-800/80 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        {maxed ? 'MAX' : `${cost} Scrap`}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Skill Set & Level Evolution Milestones */}
            <div className="pt-2 border-t border-slate-800/80">
              <h4 className="font-display text-xl font-bold text-slate-100 mb-3">
                Skill Set &amp; Evolusi Level
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-lg bg-[#141d2b] border border-slate-800">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400">Pasif</span>
                    <span className={stats.passiveEvolved ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                      {stats.passiveEvolved ? 'Evolusi Aktif' : 'Evolusi Lv.2'}
                    </span>
                  </div>
                  <div className="font-semibold text-sm text-slate-100">{hero.passive.name}</div>
                  <p className="mt-1 text-xs text-slate-400 leading-relaxed">{hero.passive.description}</p>
                  <p className="mt-2 text-[11px] text-amber-300/90">{hero.passive.evolutionNote}</p>
                </div>

                <div className="p-3.5 rounded-lg bg-[#141d2b] border border-slate-800">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-amber-400 font-mono-tabular">Aktif [{hero.activeSkill.keyHint}]</span>
                    <span className="font-mono-tabular text-slate-400">{stats.activeCooldown}d CD</span>
                  </div>
                  <div className="font-semibold text-sm text-slate-100">{hero.activeSkill.name}</div>
                  <p className="mt-1 text-xs text-slate-400 leading-relaxed">{hero.activeSkill.description}</p>
                  <p className="mt-2 text-[11px] text-amber-300/90">{hero.activeSkill.evolutionNote}</p>
                </div>

                <div className="p-3.5 rounded-lg bg-[#141d2b] border border-slate-800">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-amber-400 font-mono-tabular">Ultimate [{hero.ultimateSkill.keyHint}]</span>
                    <span className="font-mono-tabular text-slate-400">{stats.ultimateCooldown}d CD</span>
                  </div>
                  <div className="font-semibold text-sm text-slate-100">{hero.ultimateSkill.name}</div>
                  <p className="mt-1 text-xs text-slate-400 leading-relaxed">{hero.ultimateSkill.description}</p>
                  <p className="mt-2 text-[11px] text-amber-300/90">{hero.ultimateSkill.evolutionNote}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
