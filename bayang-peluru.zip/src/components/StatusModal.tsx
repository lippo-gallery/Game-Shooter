import React from 'react';
import { HEROES } from '../game/heroes';
import { MAPS } from '../game/maps';
import { GamePhase, MatchSummary } from '../game/types';

interface StatusModalProps {
  phase: GamePhase;
  summary: MatchSummary | null;
  onResume: () => void;
  onRestart: () => void;
  onOpenHeroes: () => void;
  onTitle: () => void;
}

export const StatusModal: React.FC<StatusModalProps> = ({
  phase,
  summary,
  onResume,
  onRestart,
  onOpenHeroes,
  onTitle,
}) => {
  if (phase !== 'paused' && phase !== 'gameover') return null;

  if (phase === 'paused') {
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Permainan Dijeda"
        className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-[#06090e]/82"
      >
        <div className="w-full max-w-md rounded-xl bg-[#0f1621] border border-slate-700/80 p-6 shadow-2xl">
          <h2 className="font-display text-3xl font-bold tracking-wide text-slate-50">
            Pertempuran Dijeda
          </h2>
          <p className="mt-1 text-sm text-slate-400">
            Simulasi arena dan pergerakan bot dihentikan sementara.
          </p>

          <div className="mt-6 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={onResume}
              className="w-full py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-sm transition-colors cursor-pointer"
            >
              Lanjutkan Pertempuran
            </button>
            <button
              type="button"
              onClick={onRestart}
              className="w-full py-3 rounded-lg bg-[#16202e] hover:bg-[#1e2c3e] text-slate-100 border border-slate-700 text-sm font-semibold transition-colors cursor-pointer"
            >
              Ulangi Ronde
            </button>
            <button
              type="button"
              onClick={onTitle}
              className="w-full py-3 rounded-lg bg-transparent hover:bg-slate-800/70 text-slate-300 text-sm font-medium transition-colors cursor-pointer"
            >
              Kembali ke Menu Utama
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!summary) return null;
  const hero = HEROES[summary.heroId];
  const map = MAPS[summary.mapId];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={summary.victory ? 'Kemenangan Pertempuran' : 'Pertempuran Berakhir'}
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-[#06090e]/85"
    >
      <div className="w-full max-w-lg rounded-xl bg-[#0f1621] border border-slate-700/80 p-6 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2
              className={`font-display text-4xl font-extrabold tracking-wide ${
                summary.victory ? 'text-amber-400' : 'text-rose-400'
              }`}
            >
              {summary.victory ? 'KEMENANGAN TAKTIS' : 'SKUAD TUMBANG'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {hero.name} · {map.name} · {summary.mode === 'team3v3' ? 'Mode Tim 3v3' : 'Mode Solo 1v5'}
            </p>
          </div>
          {summary.leveledUp && (
            <div className="px-3 py-1 rounded-md bg-amber-500/20 border border-amber-500/60 text-xs font-bold text-amber-300 font-mono-tabular shrink-0">
              NAIK LEVEL {summary.previousLevel} → {summary.newLevel}
            </div>
          )}
        </div>

        {/* Frozen Run Mastery / Progress Metrics */}
        <div className="mt-5 grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-[#141d2b] border border-slate-800">
            <div className="text-[11px] text-slate-400">Eliminasi</div>
            <div className="font-display text-2xl font-bold text-slate-50 font-mono-tabular mt-0.5">
              {summary.eliminations}
            </div>
          </div>
          <div className="p-3 rounded-lg bg-[#141d2b] border border-slate-800">
            <div className="text-[11px] text-slate-400">Total Damage</div>
            <div className="font-display text-2xl font-bold text-slate-50 font-mono-tabular mt-0.5">
              {summary.damageDealt}
            </div>
          </div>
          <div className="p-3 rounded-lg bg-[#141d2b] border border-slate-800">
            <div className="text-[11px] text-slate-400">Bertahan</div>
            <div className="font-display text-2xl font-bold text-slate-50 font-mono-tabular mt-0.5">
              {summary.survivalSeconds}d
            </div>
          </div>
        </div>

        {/* Progression & Adaptive Bot Summary */}
        <div className="mt-4 p-3.5 rounded-lg bg-[#141d2b] border border-slate-800 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Progres Pahlawan ({hero.name})</span>
            <span className="font-mono-tabular font-semibold text-emerald-400">
              +{summary.xpEarned} XP · +{summary.scrapEarned} Scrap
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Adaptasi Bot Musuh</span>
            <span className="font-mono-tabular font-semibold text-amber-400">
              Lv.{summary.adaptationLevelBefore} → Lv.{summary.adaptationLevelAfter}
            </span>
          </div>
          <p className="text-slate-300 pt-1.5 border-t border-slate-800/80 leading-relaxed">
            {summary.botCounterNote}
          </p>
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            data-start="true"
            onClick={onRestart}
            className="flex-1 py-3 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-display text-lg font-bold tracking-wider uppercase transition-colors whitespace-nowrap cursor-pointer"
          >
            {summary.victory ? 'Main Lagi' : 'Coba Lagi'}
          </button>
          <button
            type="button"
            onClick={onOpenHeroes}
            className="py-3 px-4 rounded-lg bg-[#16202e] hover:bg-[#1e2c3e] text-slate-100 border border-slate-700 text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer"
          >
            Upgrade Hero
          </button>
          <button
            type="button"
            onClick={onTitle}
            className="py-3 px-4 rounded-lg bg-transparent hover:bg-slate-800 text-slate-300 text-sm font-medium transition-colors whitespace-nowrap cursor-pointer"
          >
            Menu Utama
          </button>
        </div>
      </div>
    </div>
  );
};
