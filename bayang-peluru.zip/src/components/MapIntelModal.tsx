import React from 'react';
import { MAP_LIST, MAPS } from '../game/maps';
import { analyzeAdaptiveMemory } from '../game/adaptiveAI';
import { AdaptiveBotMemory, MapId } from '../game/types';

interface MapIntelModalProps {
  selectedMapId: MapId;
  memory: AdaptiveBotMemory;
  onSelectMap: (mapId: MapId) => void;
  onResetMemory: () => void;
  onClose: () => void;
}

export const MapIntelModal: React.FC<MapIntelModalProps> = ({
  selectedMapId,
  memory,
  onSelectMap,
  onResetMemory,
  onClose,
}) => {
  const activeMap = MAPS[selectedMapId];
  const insights = analyzeAdaptiveMemory(memory);
  const hm = memory.heatmaps[selectedMapId];
  const maxHeat = Math.max(1, ...hm.cells);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Pilih Peta dan Intel Bot Adaptif"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 md:p-6 bg-[#06090e]/85"
    >
      <div className="w-full max-w-5xl max-h-[90vh] flex flex-col rounded-xl bg-[#0f1621] border border-slate-700/70 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-wide text-slate-50">
              Peta Pertempuran &amp; Intel Bot Adaptif
            </h2>
            <p className="text-xs text-slate-400">
              Pilih arena strategis dengan rintangan unik dan pantau pola pergerakan yang telah dipelajari bot.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup jendela peta"
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Tutup
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 min-h-0 overflow-y-auto tactical-scroll p-5 md:p-6 space-y-6">
          {/* 4 Selectable Maps with Real SVG Architectural Blueprints */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {MAP_LIST.map((m) => {
              const isSelected = m.id === selectedMapId;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onSelectMap(m.id)}
                  className={`p-3 rounded-lg text-left transition-colors flex flex-col cursor-pointer border ${
                    isSelected
                      ? 'bg-[#1a2536] border-amber-500'
                      : 'bg-[#141d2b] border-slate-800 hover:border-slate-600'
                  }`}
                >
                  {/* Live SVG Blueprint from actual map obstacle geometry */}
                  <div className="w-full aspect-[16/11] rounded-md overflow-hidden bg-[#0b1017] border border-slate-800 mb-3">
                    <svg viewBox={`0 0 ${m.width} ${m.height}`} className="w-full h-full">
                      <rect x="0" y="0" width={m.width} height={m.height} fill={m.palette.floorBase} />
                      {m.obstacles.map((obs) => {
                        const fill =
                          obs.kind === 'wall'
                            ? m.palette.wallBorder
                            : obs.kind === 'low_cover'
                              ? '#64748b'
                              : obs.kind === 'crate'
                                ? '#b45309'
                                : obs.kind === 'bush'
                                  ? '#15803d'
                                  : '#dc2626';
                        return (
                          <rect
                            key={obs.id}
                            x={obs.x}
                            y={obs.y}
                            width={obs.w}
                            height={obs.h}
                            fill={fill}
                            opacity={obs.kind === 'bush' ? 0.65 : 0.9}
                          />
                        );
                      })}
                    </svg>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="font-display text-lg font-bold text-slate-100 leading-tight">
                      {m.name}
                    </span>
                    {isSelected && (
                      <span className="text-[11px] font-semibold text-amber-400 shrink-0">Aktif</span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5">{m.subtitle}</span>
                  <p className="text-xs text-slate-300 mt-2 leading-snug flex-1">{m.description}</p>
                </button>
              );
            })}
          </div>

          {/* Active Map Legend & Live Adaptive Bot Memory Heatmap */}
          <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-5 pt-4 border-t border-slate-800">
            {/* Heatmap Overlay over Active Map */}
            <div className="p-4 rounded-lg bg-[#141d2b] border border-slate-800">
              <div className="flex items-center justify-between gap-2 mb-3">
                <div>
                  <h3 className="font-display text-xl font-bold text-slate-100">
                    Peta Panas Pergerakan — {activeMap.name}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Zona oranye menunjukkan area yang sering kamu lewati dan mulai dipantau bot musuh.
                  </p>
                </div>
                <span className="font-mono-tabular text-xs text-amber-400 shrink-0">
                  {memory.samples} sampel
                </span>
              </div>

              <div className="w-full aspect-[16/11] rounded-md overflow-hidden border border-slate-800 bg-[#0b1017]">
                <svg viewBox={`0 0 ${activeMap.width} ${activeMap.height}`} className="w-full h-full">
                  <rect x="0" y="0" width={activeMap.width} height={activeMap.height} fill={activeMap.palette.floorBase} />
                  {/* Heatmap cells */}
                  {hm.cells.map((heat, idx) => {
                    if (heat <= 0.1) return null;
                    const col = idx % hm.cols;
                    const row = Math.floor(idx / hm.cols);
                    const cw = activeMap.width / hm.cols;
                    const ch = activeMap.height / hm.rows;
                    const opacity = Math.min(0.75, (heat / maxHeat) * 0.65 + 0.12);
                    return (
                      <rect
                        key={idx}
                        x={col * cw}
                        y={row * ch}
                        width={cw}
                        height={ch}
                        fill="#f59e0b"
                        opacity={opacity}
                      />
                    );
                  })}
                  {/* Obstacles */}
                  {activeMap.obstacles.map((obs) => (
                    <rect
                      key={obs.id}
                      x={obs.x}
                      y={obs.y}
                      width={obs.w}
                      height={obs.h}
                      fill={
                        obs.kind === 'wall'
                          ? activeMap.palette.wallTop
                          : obs.kind === 'low_cover'
                            ? '#475569'
                            : obs.kind === 'crate'
                              ? '#92400e'
                              : obs.kind === 'bush'
                                ? '#166534'
                                : '#b91c1c'
                      }
                      stroke="rgba(226,232,240,0.22)"
                      strokeWidth="3"
                    />
                  ))}
                </svg>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-400">
                <span>Dinding Solid: Blokir visi &amp; peluru</span>
                <span aria-hidden="true">·</span>
                <span>Barikade Rendah: Peluru tembus</span>
                <span aria-hidden="true">·</span>
                <span>Peti Kayu: Hancurkan untuk item</span>
                <span aria-hidden="true">·</span>
                <span>Semak: Penyamaran senyap</span>
              </div>
            </div>

            {/* Adaptive AI Behavioral Dossier */}
            <div className="p-4 rounded-lg bg-[#141d2b] border border-slate-800 flex flex-col justify-between gap-4">
              <div>
                <div className="flex items-baseline justify-between gap-2 mb-3">
                  <h3 className="font-display text-xl font-bold text-slate-100">
                    Analisis Adaptasi Bot
                  </h3>
                  <span className="font-mono-tabular text-sm font-bold text-amber-400">
                    Adaptasi Lv.{insights.adaptationLevel}/10
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="pb-2.5 border-b border-slate-800">
                    <div className="text-slate-400">Kebiasaan Menghindar (Strafe)</div>
                    <div className="text-sm font-semibold text-slate-100 mt-0.5">
                      {insights.strafeTendencyLabel}
                    </div>
                  </div>
                  <div className="pb-2.5 border-b border-slate-800">
                    <div className="text-slate-400">Gaya Jarak Pertempuran</div>
                    <div className="text-sm font-semibold text-slate-100 mt-0.5">
                      {insights.rangeStyleLabel}{' '}
                      <span className="font-mono-tabular text-xs text-slate-400">
                        (~{memory.avgEngageRange}px)
                      </span>
                    </div>
                  </div>
                  <div className="pb-2.5 border-b border-slate-800">
                    <div className="text-slate-400">Tempo &amp; Penggunaan Cover</div>
                    <div className="text-sm font-semibold text-slate-100 mt-0.5">
                      {insights.tempoLabel}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400">Strategi Balasan Bot Saat Ini</div>
                    <p className="text-sm text-amber-300 mt-0.5 leading-relaxed">
                      {insights.counterTacticSummary}
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
                <span className="text-[11px] text-slate-400">
                  {activeMap.tacticalNote}
                </span>
                <button
                  type="button"
                  onClick={onResetMemory}
                  className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Reset Memori Bot
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
