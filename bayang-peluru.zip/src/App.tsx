/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  createDefaultAdaptiveMemory,
  loadAdaptiveMemory,
  saveAdaptiveMemory,
} from './game/adaptiveAI';
import { audioEngine } from './game/audio';
import { TacticalArenaEngine } from './game/engine';
import {
  applyUpgrade,
  grantMatchRewards,
  loadPlayerProfile,
  savePlayerProfile,
} from './game/progression';
import {
  AdaptiveBotMemory,
  GameMode,
  GamePhase,
  HeroId,
  HudSnapshot,
  MapId,
  MatchSummary,
  PlayerProfile,
  SquadCommand,
  UpgradeAttribute,
} from './game/types';
import { GameHud } from './components/GameHud';
import { HeroRosterModal } from './components/HeroRosterModal';
import { MapIntelModal } from './components/MapIntelModal';
import { StatusModal } from './components/StatusModal';
import { TitleOverlay } from './components/TitleOverlay';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<TacticalArenaEngine | null>(null);

  const [profile, setProfile] = useState<PlayerProfile>(() => loadPlayerProfile());
  const [memory, setMemory] = useState<AdaptiveBotMemory>(() => loadAdaptiveMemory());
  const [phase, setPhase] = useState<GamePhase>('title');
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [summary, setSummary] = useState<MatchSummary | null>(null);
  const [muted, setMuted] = useState(false);

  const [showHeroesModal, setShowHeroesModal] = useState(false);
  const [showMapsModal, setShowMapsModal] = useState(false);

  const profileRef = useRef(profile);
  const memoryRef = useRef(memory);
  profileRef.current = profile;
  memoryRef.current = memory;

  const startGame = useCallback(() => {
    setShowHeroesModal(false);
    setShowMapsModal(false);
    setSummary(null);
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    engineRef.current?.startMatch(profileRef.current, memoryRef.current);
  }, []);

  // Mount Canvas2D simulation engine ONCE so HUD state changes never reset the canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new TacticalArenaEngine(canvas, profileRef.current, memoryRef.current, {
      onHudUpdate: (snap) => setHud(snap),
      onPhaseChange: (nextPhase) => setPhase(nextPhase),
      onMemoryUpdate: (updatedMem) => {
        memoryRef.current = updatedMem;
      },
      onMatchEnd: (rawSummary, finalizedMemory) => {
        saveAdaptiveMemory(finalizedMemory);
        setMemory(finalizedMemory);

        const reward = grantMatchRewards(profileRef.current, {
          heroId: rawSummary.heroId,
          victory: rawSummary.victory,
          eliminations: rawSummary.eliminations,
          damageDealt: rawSummary.damageDealt,
          revives: rawSummary.revives,
          survivalSeconds: rawSummary.survivalSeconds,
          adaptationLevel: rawSummary.adaptationLevelAfter,
        });

        savePlayerProfile(reward.profile);
        setProfile(reward.profile);
        setSummary({
          ...rawSummary,
          xpEarned: reward.xpEarned,
          scrapEarned: reward.scrapEarned,
          previousLevel: reward.previousLevel,
          newLevel: reward.newLevel,
          leveledUp: reward.leveledUp,
        });
      },
    });

    engineRef.current = engine;
    engine.startLoop();

    // Support ?autostart=1 query parameter to skip directly into gameplay
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      engine.startMatch(profileRef.current, memoryRef.current);
    }

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // Keep engine synced with selected map/hero/upgrades when updated on Title
  useEffect(() => {
    engineRef.current?.updateConfig(profile, memory);
  }, [profile, memory]);

  // Pause background canvas redraw while full-screen Title modals cover the viewport
  useEffect(() => {
    engineRef.current?.setRenderPaused(showHeroesModal || showMapsModal);
  }, [showHeroesModal, showMapsModal]);

  // Global keyboard shortcuts: Enter/Space starts from Title, M toggles mute
  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      if (e.code === 'KeyM' && !showHeroesModal && !showMapsModal) {
        const nextMuted = audioEngine.toggleMute();
        setMuted(nextMuted);
        return;
      }
      if (
        phase === 'title' &&
        !showHeroesModal &&
        !showMapsModal &&
        (e.code === 'Enter' || e.code === 'Space')
      ) {
        // Avoid double-triggering if user focused a secondary button
        if (document.activeElement instanceof HTMLButtonElement) return;
        e.preventDefault();
        startGame();
      }
    };
    window.addEventListener('keydown', handleGlobalKeys);
    return () => window.removeEventListener('keydown', handleGlobalKeys);
  }, [phase, showHeroesModal, showMapsModal, startGame]);

  const handleSelectMode = (mode: GameMode) => {
    setProfile((prev) => {
      const next = { ...prev, selectedMode: mode };
      savePlayerProfile(next);
      return next;
    });
  };

  const handleSelectHero = (heroId: HeroId) => {
    setProfile((prev) => {
      const next = { ...prev, selectedHeroId: heroId };
      savePlayerProfile(next);
      return next;
    });
  };

  const handleUpgradeHero = (heroId: HeroId, attr: UpgradeAttribute) => {
    setProfile((prev) => {
      const res = applyUpgrade(prev, heroId, attr);
      if (res.success) {
        audioEngine.playPickup();
        savePlayerProfile(res.profile);
        return res.profile;
      }
      return prev;
    });
  };

  const handleSelectMap = (mapId: MapId) => {
    setProfile((prev) => {
      const next = { ...prev, selectedMapId: mapId };
      savePlayerProfile(next);
      return next;
    });
  };

  const handleResetMemory = () => {
    const fresh = createDefaultAdaptiveMemory();
    saveAdaptiveMemory(fresh);
    setMemory(fresh);
  };

  const handleToggleMute = () => {
    setMuted(audioEngine.toggleMute());
  };

  const handleReturnTitle = () => {
    setSummary(null);
    engineRef.current?.returnToTitle();
  };

  const handleOpenHeroesFromGameOver = () => {
    setSummary(null);
    engineRef.current?.returnToTitle();
    setShowHeroesModal(true);
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#0b1017]">
      {/* Isolated Full-Bleed Bird's-Eye Canvas */}
      <canvas
        ref={canvasRef}
        data-testid="arena-canvas"
        className="block w-full h-full cursor-crosshair"
      />

      {/* Title Screen Shell */}
      {phase === 'title' && (
        <TitleOverlay
          profile={profile}
          memory={memory}
          onStart={startGame}
          onModeChange={handleSelectMode}
          onOpenHeroes={() => setShowHeroesModal(true)}
          onOpenMaps={() => setShowMapsModal(true)}
        />
      )}

      {/* Active Gameplay HUD */}
      {phase === 'playing' && hud && (
        <GameHud
          hud={hud}
          muted={muted}
          onToggleMute={handleToggleMute}
          onPause={() => engineRef.current?.pauseGame()}
          onRestart={startGame}
          onToggleAutoFire={() => engineRef.current?.toggleAutoFire()}
          onTriggerActive={() => engineRef.current?.triggerActiveSkill()}
          onTriggerUltimate={() => engineRef.current?.triggerUltimateSkill()}
          onSquadCommand={(cmd: SquadCommand) => engineRef.current?.issueSquadCommand(cmd)}
        />
      )}

      {/* Pause / Victory / Game Over Modal */}
      <StatusModal
        phase={phase}
        summary={summary}
        onResume={() => engineRef.current?.resumeGame()}
        onRestart={startGame}
        onOpenHeroes={handleOpenHeroesFromGameOver}
        onTitle={handleReturnTitle}
      />

      {/* Hero Roster, Lore & Upgrade Workshop */}
      {showHeroesModal && (
        <HeroRosterModal
          profile={profile}
          onSelectHero={handleSelectHero}
          onUpgrade={handleUpgradeHero}
          onClose={() => setShowHeroesModal(false)}
        />
      )}

      {/* Map Selector & Live Adaptive Bot Intel */}
      {showMapsModal && (
        <MapIntelModal
          selectedMapId={profile.selectedMapId}
          memory={memory}
          onSelectMap={handleSelectMap}
          onResetMemory={handleResetMemory}
          onClose={() => setShowMapsModal(false)}
        />
      )}
    </main>
  );
}
