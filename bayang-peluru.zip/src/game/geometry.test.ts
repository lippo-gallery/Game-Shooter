import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildVisionConePolygon,
  circleIntersectsRect,
  hasLineOfSight,
  isPointInVisionCone,
  resolveCircleRects,
} from './geometry';
import { MAP_LIST } from './maps';
import { MapObstacle } from './types';

test('line of sight is blocked by solid wall but not by low cover', () => {
  const obstacles: MapObstacle[] = [
    { id: 'w1', kind: 'wall', x: 100, y: 50, w: 40, h: 100 },
    { id: 'lc1', kind: 'low_cover', x: 300, y: 50, w: 40, h: 100 },
  ];

  assert.equal(hasLineOfSight({ x: 50, y: 100 }, { x: 200, y: 100 }, obstacles), false);
  assert.equal(hasLineOfSight({ x: 250, y: 100 }, { x: 400, y: 100 }, obstacles, false), true);
  assert.equal(hasLineOfSight({ x: 250, y: 100 }, { x: 400, y: 100 }, obstacles, true), false);
});

test('vision cone raycasting stops at walls and detects targets inside cone', () => {
  const obstacles: MapObstacle[] = [{ id: 'w1', kind: 'wall', x: 200, y: 0, w: 30, h: 200 }];
  const poly = buildVisionConePolygon({ x: 100, y: 100 }, 0, 1.0, 300, obstacles, 12);
  assert.equal(poly.length, 14);
  // Center ray facing right should hit x = 200
  const centerRay = poly[7];
  assert.ok(Math.abs(centerRay.x - 200) < 2, `Expected center ray to stop at wall x=200, got ${centerRay.x}`);

  assert.equal(isPointInVisionCone({ x: 100, y: 100 }, 0, 1.0, 300, 60, { x: 170, y: 100 }, obstacles), true);
  assert.equal(isPointInVisionCone({ x: 100, y: 100 }, 0, 1.0, 300, 60, { x: 260, y: 100 }, obstacles), false);
});

test('circle-rect resolution pushes actor out of wall cleanly', () => {
  const obstacles: MapObstacle[] = [{ id: 'w1', kind: 'wall', x: 100, y: 100, w: 100, h: 100 }];
  const resolved = resolveCircleRects(95, 150, 20, obstacles);
  assert.ok(resolved.x <= 80.1, `Actor should be pushed left of x=80, got ${resolved.x}`);
});

test('all 4 maps have open spawn points free of blocking obstacles', () => {
  for (const map of MAP_LIST) {
    const blocking = map.obstacles.filter((o) => o.kind !== 'bush' && o.kind !== 'hazard');
    const allSpawns = [...map.teamASpawns, ...map.teamBSpawns, ...map.soloSpawns];
    for (const sp of allSpawns) {
      for (const obs of blocking) {
        assert.equal(
          circleIntersectsRect(sp.x, sp.y, 26, obs),
          false,
          `Spawn (${sp.x},${sp.y}) on ${map.id} overlaps obstacle ${obs.id}`
        );
      }
    }
  }
});
