import { HeroId } from './types';

class TacticalAudioEngine {
  private ctx: AudioContext | null = null;
  private muted = false;

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(next: boolean): void {
    this.muted = next;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    return this.muted;
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playShoot(heroId: HeroId, volume = 0.22): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const pitchVar = 0.93 + Math.random() * 0.14;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (heroId === 'kairo') {
      // Silenced crisp needle zip
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(680 * pitchVar, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.065);
      gain.gain.setValueAtTime(volume * 0.65, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    } else if (heroId === 'bima') {
      // Heavy industrial rotary thump
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(170 * pitchVar, now);
      osc.frequency.exponentialRampToValueAtTime(48, now + 0.09);
      gain.gain.setValueAtTime(volume * 0.9, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.095);
    } else if (heroId === 'laras') {
      // High-energy resonant rail rifle crack
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(980 * pitchVar, now);
      osc.frequency.exponentialRampToValueAtTime(110, now + 0.18);
      gain.gain.setValueAtTime(volume * 1.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    } else if (heroId === 'tala') {
      // Punchy scattergun boom
      osc.type = 'square';
      osc.frequency.setValueAtTime(220 * pitchVar, now);
      osc.frequency.exponentialRampToValueAtTime(38, now + 0.15);
      gain.gain.setValueAtTime(volume * 1.0, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    } else {
      // Dr. Vexa glass vial launcher pop
      osc.type = 'sine';
      osc.frequency.setValueAtTime(360 * pitchVar, now);
      osc.frequency.exponentialRampToValueAtTime(160, now + 0.11);
      gain.gain.setValueAtTime(volume * 0.85, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    }

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.22);
  }

  public playHit(heavy = false): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = heavy ? 'sawtooth' : 'triangle';
    osc.frequency.setValueAtTime(heavy ? 320 : 520, now);
    osc.frequency.exponentialRampToValueAtTime(heavy ? 70 : 180, now + (heavy ? 0.11 : 0.055));
    gain.gain.setValueAtTime(heavy ? 0.24 : 0.13, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (heavy ? 0.12 : 0.06));
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
  }

  public playSkill(isUltimate = false): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = isUltimate ? 'sawtooth' : 'sine';
    osc.frequency.setValueAtTime(isUltimate ? 240 : 340, now);
    osc.frequency.exponentialRampToValueAtTime(isUltimate ? 760 : 620, now + (isUltimate ? 0.26 : 0.14));
    gain.gain.setValueAtTime(isUltimate ? 0.22 : 0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isUltimate ? 0.32 : 0.18));
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.34);
  }

  public playPickup(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    [520, 740].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.055);
      gain.gain.setValueAtTime(0.13, now + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.055 + 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.055);
      osc.stop(now + i * 0.055 + 0.11);
    });
  }

  public playRadioPing(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.setValueAtTime(1120, now + 0.045);
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  public playOutcome(victory: boolean): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = victory ? [392, 493.88, 587.33, 783.99] : [330, 293.66, 220];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = victory ? 'triangle' : 'sawtooth';
      const t = now + idx * 0.11;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.16, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.26);
    });
  }
}

export const audioEngine = new TacticalAudioEngine();
