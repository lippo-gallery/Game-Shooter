import {
  AdaptiveBotMemory,
  BotArchetype,
  ComputedHeroStats,
  GameMode,
  GamePhase,
  HeroId,
  HudSnapshot,
  KillFeedItem,
  MapDefinition,
  MapId,
  MapObstacle,
  MatchSummary,
  PickupKind,
  PlayerProfile,
  SquadCommand,
  Vec2,
  WorldPickup,
} from './types';
import { HEROES, HERO_LIST } from './heroes';
import { MAPS } from './maps';
import {
  angleDiff,
  buildVisionConePolygon,
  circleIntersectsRect,
  clamp,
  dist,
  hasLineOfSight,
  isPointInVisionCone,
  isPositionInBush,
  normalizeAngle,
  pointInRect,
  rayIntersectRect,
  resolveCircleRects,
} from './geometry';
import {
  analyzeAdaptiveMemory,
  computeAdaptiveAimAngle,
  getAdaptationLevel,
  getTopPlayerHotspots,
  recordPlayerMovementSample,
} from './adaptiveAI';
import { computeBotDifficultyScale, computeHeroStats } from './progression';
import { audioEngine } from './audio';

interface SimActor {
  id: string;
  name: string;
  heroId: HeroId;
  team: 'A' | 'B';
  isPlayer: boolean;
  archetype: BotArchetype;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  radius: number;
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  speed: number;
  damage: number;
  visionRange: number;
  visionArcRad: number;
  footstepNoise: number;
  ammo: number;
  maxAmmo: number;
  reloading: boolean;
  reloadTimer: number;
  fireCooldown: number;
  activeCooldown: number;
  activeMaxCooldown: number;
  activeDuration: number;
  ultimateCooldown: number;
  ultimateMaxCooldown: number;
  ultimateDuration: number;
  skillPower: number;
  passiveEvolved: boolean;
  activeEvolved: boolean;
  ultimateEvolved: boolean;
  alive: boolean;
  downed: boolean;
  bleedoutTimer: number;
  reviveProgress: number;
  koTimer: number;
  hitFlashTimer: number;
  timeSinceDamaged: number;
  stillTimer: number;
  stepDistAcc: number;
  walkPhase: number;
  killBoostTimer: number;
  stealthTimer: number;
  cloakCritReady: boolean;
  pierceShotReady: boolean;
  revealedTimer: number;
  vulnerableTimer: number;
  slowTimer: number;
  visorBoostTimer: number;
  // Bot AI fields
  aiWaypoint: Vec2;
  aiRetargetTimer: number;
  aiStrafeDir: number;
  aiReactionTimer: number;
  aiTelegraphTimer: number;
  aiTelegraphMax: number;
  aiTelegraphTarget: Vec2 | null;
  aiTelegraphKind: 'none' | 'sniper' | 'breach';
  aiHasAttackToken: boolean;
  aiLastSeenEnemyPos: Vec2 | null;
  aiLastSeenTimer: number;
}

interface Projectile {
  active: boolean;
  ownerId: string;
  team: 'A' | 'B';
  heroId: HeroId;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  armorPen: number;
  remainingDist: number;
  color: string;
  radius: number;
  pierceLowCover: boolean;
  splashRadius: number;
  applyBioMark: boolean;
  isCrit: boolean;
}

interface DeployedTurret {
  id: string;
  ownerId: string;
  team: 'A' | 'B';
  x: number;
  y: number;
  angle: number;
  hp: number;
  maxHp: number;
  ttl: number;
  fireCooldown: number;
  damage: number;
}

interface TacticalZone {
  id: string;
  kind: 'spore' | 'heal' | 'breach_blast';
  team: 'A' | 'B';
  ownerId: string;
  x: number;
  y: number;
  radius: number;
  ttl: number;
  maxTtl: number;
  power: number;
  detonated?: boolean;
}

interface SoundRipple {
  active: boolean;
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  color: string;
}

interface Particle {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  drag: number;
}

interface EngineCallbacks {
  onHudUpdate: (snapshot: HudSnapshot) => void;
  onPhaseChange: (phase: GamePhase) => void;
  onMatchEnd: (summary: MatchSummary, updatedMemory: AdaptiveBotMemory) => void;
  onMemoryUpdate: (updatedMemory: AdaptiveBotMemory) => void;
}

const MAX_PARTICLES = 256;
const MAX_PROJECTILES = 140;
const MAX_RIPPLES = 48;

const BOT_CALLSIGNS: Record<BotArchetype, string[]> = {
  scout: ['Viper', 'Kelelawar', 'Silet'],
  marksman: ['Elang', 'Bidik', 'Lensa'],
  vanguard: ['Baja', 'Benteng', 'Gada'],
  breacher: ['Guntur', 'Badai', 'Mercon'],
};

const ALLY_CALLSIGNS = ['Raka', 'Sena', 'Nadia', 'Bara'];

export class TacticalArenaEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private visionCanvas: HTMLCanvasElement;
  private visionCtx: CanvasRenderingContext2D;
  private callbacks: EngineCallbacks;

  private rafId: number | null = null;
  private lastTimestamp = 0;
  private renderPaused = false;
  private dirtyStaticFrame = true;
  private resizeObserver: ResizeObserver | null = null;
  private viewW = 1280;
  private viewH = 720;
  private visionScale = 0.5;

  private phase: GamePhase = 'title';
  private mode: GameMode = 'team3v3';
  private map: MapDefinition = MAPS.cargo_docks;
  private obstacles: MapObstacle[] = [];
  private pickups: WorldPickup[] = [];
  private actors: SimActor[] = [];
  private turrets: DeployedTurret[] = [];
  private zones: TacticalZone[] = [];

  private projectiles: Projectile[] = [];
  private particles: Particle[] = [];
  private particleCursor = 0;
  private ripples: SoundRipple[] = [];
  private rippleCursor = 0;

  private profile: PlayerProfile;
  private adaptiveMemory: AdaptiveBotMemory;
  private startAdaptationLevel = 1;

  // Input state
  private keys = new Set<string>();
  private mouseScreen: Vec2 = { x: 640, y: 360 };
  private mouseDown = false;
  private autoFire = true;
  private squadCommand: SquadCommand = 'follow';
  private dashBufferTimer = 0;

  // Camera & Juice
  private camX = 800;
  private camY = 560;
  private shakeTrauma = 0;
  private hitstopTimer = 0;
  private titleTourTime = 0;

  // Match telemetry
  private matchTime = 0;
  private stormRadius = 1100;
  private stormMaxRadius = 1100;
  private hazardPulseTimer = 0;
  private sampleTimer = 0;
  private hudEmitTimer = 0;
  private finishDelayTimer = 0;
  private pendingVictory: boolean | null = null;
  private playerKills = 0;
  private playerDamage = 0;
  private playerRevives = 0;
  private killFeed: KillFeedItem[] = [];
  private killFeedSeq = 1;
  private radioCallout: string | null = null;
  private radioCalloutTimer = 0;
  private thermalScanTimer = 0;

  constructor(
    canvas: HTMLCanvasElement,
    profile: PlayerProfile,
    adaptiveMemory: AdaptiveBotMemory,
    callbacks: EngineCallbacks
  ) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not initialize 2D context');
    this.ctx = ctx;

    this.visionCanvas = document.createElement('canvas');
    const vctx = this.visionCanvas.getContext('2d');
    if (!vctx) throw new Error('Could not initialize offscreen vision context');
    this.visionCtx = vctx;

    this.profile = profile;
    this.adaptiveMemory = adaptiveMemory;
    this.callbacks = callbacks;

    // Pre-allocate pooled buffers (zero GC in loop)
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        size: 3,
        life: 0,
        maxLife: 1,
        color: '#fff',
        drag: 0.92,
      });
    }
    for (let i = 0; i < MAX_PROJECTILES; i++) {
      this.projectiles.push({
        active: false,
        ownerId: '',
        team: 'A',
        heroId: 'kairo',
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        damage: 10,
        armorPen: 0,
        remainingDist: 0,
        color: '#fff',
        radius: 3,
        pierceLowCover: false,
        splashRadius: 0,
        applyBioMark: false,
        isCrit: false,
      });
    }
    for (let i = 0; i < MAX_RIPPLES; i++) {
      this.ripples.push({
        active: false,
        x: 0,
        y: 0,
        radius: 0,
        maxRadius: 80,
        alpha: 0,
        color: '#f59e0b',
      });
    }

    this.syncSize();
    this.bindEvents();
    this.setupTitleTour(profile.selectedMapId);
  }

  public startLoop(): void {
    if (this.rafId !== null) return;
    this.lastTimestamp = performance.now();
    const tick = (now: number) => {
      const rawDt = (now - this.lastTimestamp) / 1000;
      this.lastTimestamp = now;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

      const isStaticState = this.renderPaused || this.phase === 'paused' || this.phase === 'gameover';
      if (!isStaticState) {
        this.update(dt);
        this.render();
        this.dirtyStaticFrame = true;
      } else if (this.dirtyStaticFrame) {
        this.render();
        this.dirtyStaticFrame = false;
      }
      this.rafId = window.requestAnimationFrame(tick);
    };
    this.rafId = window.requestAnimationFrame(tick);
  }

  public setRenderPaused(paused: boolean): void {
    this.renderPaused = paused;
    if (!paused) {
      this.lastTimestamp = performance.now();
      this.dirtyStaticFrame = true;
    }
  }

  public destroy(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.unbindEvents();
  }

  public updateConfig(profile: PlayerProfile, memory: AdaptiveBotMemory): void {
    const mapChanged = this.map.id !== profile.selectedMapId;
    this.profile = profile;
    this.adaptiveMemory = memory;
    if (this.phase === 'title' && mapChanged) {
      this.setupTitleTour(profile.selectedMapId);
    }
  }

  public getPhase(): GamePhase {
    return this.phase;
  }

  public toggleAutoFire(): boolean {
    this.autoFire = !this.autoFire;
    this.emitHud();
    return this.autoFire;
  }

  public issueSquadCommand(cmd: SquadCommand): void {
    if (this.phase !== 'playing' || this.mode !== 'team3v3') return;
    this.squadCommand = cmd;
    audioEngine.playRadioPing();
    const callouts: Record<SquadCommand, string> = {
      follow: 'Skuad: Formasi rapat di belakang pemimpin!',
      attack: 'Skuad: Maju & kepung musuh dari samping!',
      defend: 'Skuad: Tahan sektor & lindungi jalur masuk!',
      regroup: 'Skuad: Kumpul cepat untuk pemulihan & perlindungan!',
    };
    this.radioCallout = callouts[cmd];
    this.radioCalloutTimer = 3.2;
    const player = this.getPlayer();
    if (player) {
      this.spawnRipple(player.x, player.y, 120, '#10b981');
    }
    this.emitHud();
  }

  public triggerActiveSkill(): void {
    if (this.phase !== 'playing') return;
    const player = this.getPlayer();
    if (!player || !player.alive || player.downed) return;
    this.activateHeroSkill(player, 'active');
  }

  public triggerUltimateSkill(): void {
    if (this.phase !== 'playing') return;
    const player = this.getPlayer();
    if (!player || !player.alive || player.downed) return;
    this.activateHeroSkill(player, 'ultimate');
  }

  public startMatch(profile: PlayerProfile, memory: AdaptiveBotMemory): void {
    this.profile = profile;
    this.adaptiveMemory = memory;
    this.mode = profile.selectedMode;
    this.map = MAPS[profile.selectedMapId];
    this.startAdaptationLevel = getAdaptationLevel(memory);

    this.resetWorldEntities();
    this.clearInputs();

    const playerHeroId = profile.selectedHeroId;
    const playerProgress = profile.heroProgress[playerHeroId];
    const playerStats = computeHeroStats(playerHeroId, playerProgress);
    const diffScale = computeBotDifficultyScale(
      playerStats,
      this.startAdaptationLevel,
      profile.winStreak
    );

    // Spawn Player on Team A (clear open lane facing toward center)
    const spawnA = this.mode === 'team3v3' ? this.map.teamASpawns : this.map.soloSpawns;
    const playerPos = spawnA[0];
    const centerAngle = Math.atan2(this.map.height * 0.5 - playerPos.y, this.map.width * 0.5 - playerPos.x);

    const player = this.createActor({
      id: 'player',
      name: HEROES[playerHeroId].name,
      heroId: playerHeroId,
      team: 'A',
      isPlayer: true,
      archetype: 'scout',
      pos: playerPos,
      angle: centerAngle,
      stats: playerStats,
    });
    this.actors.push(player);

    // Spawn Allied Bots in Team 3v3
    if (this.mode === 'team3v3') {
      const allyHeroes = this.pickComplementaryHeroes(playerHeroId, 2);
      allyHeroes.forEach((hid, idx) => {
        const baseProg = {
          heroId: hid,
          level: Math.max(1, playerProgress.level),
          xp: 0,
          matchesPlayed: 0,
          wins: 0,
          eliminations: 0,
          upgrades: { ...playerProgress.upgrades },
        };
        const allyStats = computeHeroStats(hid, baseProg);
        const pos = this.map.teamASpawns[idx + 1] ?? { x: playerPos.x, y: playerPos.y + (idx === 0 ? -90 : 90) };
        const archetype: BotArchetype = hid === 'bima' ? 'vanguard' : hid === 'laras' ? 'marksman' : 'scout';
        this.actors.push(
          this.createActor({
            id: `ally_${idx}`,
            name: `${ALLY_CALLSIGNS[idx]} (${HEROES[hid].name})`,
            heroId: hid,
            team: 'A',
            isPlayer: false,
            archetype,
            pos,
            angle: centerAngle,
            stats: allyStats,
          })
        );
      });
    }

    // Spawn Adaptive Enemy Bots
    const enemyCount = this.mode === 'team3v3' ? 3 : 5;
    const enemySpawns = this.mode === 'team3v3' ? this.map.teamBSpawns : this.map.soloSpawns.slice(1);
    const archetypes: BotArchetype[] = ['scout', 'marksman', 'vanguard', 'breacher', 'scout'];
    const enemyHeroPool: HeroId[] = ['kairo', 'laras', 'bima', 'vexa', 'tala'];

    for (let i = 0; i < enemyCount; i++) {
      const arch = archetypes[i % archetypes.length];
      const hid = enemyHeroPool[i % enemyHeroPool.length];
      const baseStats = computeHeroStats(hid, {
        heroId: hid,
        level: Math.max(1, playerProgress.level),
        xp: 0,
        matchesPlayed: 0,
        wins: 0,
        eliminations: 0,
        upgrades: {
          firepower: Math.min(5, Math.floor(playerProgress.level / 3)),
          vitality: Math.min(5, Math.floor(playerProgress.level / 3)),
          agility: Math.min(5, Math.floor(playerProgress.level / 4)),
          optics: Math.min(5, Math.floor(playerProgress.level / 4)),
          skillMastery: Math.min(5, Math.floor(playerProgress.level / 4)),
        },
      });

      const scaledStats: ComputedHeroStats = {
        ...baseStats,
        maxHp: Math.round(baseStats.maxHp * diffScale.hpScale),
        maxArmor: Math.round(baseStats.maxArmor * diffScale.hpScale),
        damage: Math.round(baseStats.damage * diffScale.damageScale),
      };

      const pos = enemySpawns[i % enemySpawns.length];
      const toCenter = Math.atan2(this.map.height * 0.5 - pos.y, this.map.width * 0.5 - pos.x);
      const names = BOT_CALLSIGNS[arch];
      const botName = `${names[i % names.length]}`;

      this.actors.push(
        this.createActor({
          id: `enemy_${i}`,
          name: botName,
          heroId: hid,
          team: 'B',
          isPlayer: false,
          archetype: arch,
          pos,
          angle: toCenter,
          stats: scaledStats,
          reactionDelay: diffScale.reactionDelay,
        })
      );
    }

    this.camX = player.x;
    this.camY = player.y;
    this.squadCommand = 'follow';
    this.matchTime = 0;
    this.stormMaxRadius = Math.hypot(this.map.width * 0.52, this.map.height * 0.52);
    this.stormRadius = this.stormMaxRadius;
    this.playerKills = 0;
    this.playerDamage = 0;
    this.playerRevives = 0;
    this.pendingVictory = null;
    this.finishDelayTimer = 0;
    this.killFeed = [];
    this.thermalScanTimer = 0;
    this.radioCallout =
      this.mode === 'team3v3'
        ? 'Skuad siap! Tekan 1–4 untuk komando taktis tim.'
        : 'Mode Solo aktif — waspadai jejak suara bot adaptif!';
    this.radioCalloutTimer = 3.8;

    this.setPhase('playing');
    this.emitHud();
  }

  public pauseGame(): void {
    if (this.phase !== 'playing') return;
    this.clearInputs();
    this.setPhase('paused');
    this.emitHud();
  }

  public resumeGame(): void {
    if (this.phase !== 'paused') return;
    this.clearInputs();
    this.setPhase('playing');
    this.emitHud();
  }

  public returnToTitle(): void {
    this.clearInputs();
    this.setupTitleTour(this.profile.selectedMapId);
    this.setPhase('title');
    this.emitHud();
  }

  private setPhase(next: GamePhase): void {
    this.phase = next;
    this.dirtyStaticFrame = true;
    document.body.dataset.state = next;
    this.callbacks.onPhaseChange(next);
  }

  private clearInputs(): void {
    this.keys.clear();
    this.mouseDown = false;
    this.dashBufferTimer = 0;
  }

  private pickComplementaryHeroes(playerHero: HeroId, count: number): HeroId[] {
    const preferredOrder: HeroId[] =
      playerHero === 'bima'
        ? ['tala', 'laras', 'vexa', 'kairo']
        : playerHero === 'tala'
          ? ['bima', 'laras', 'kairo', 'vexa']
          : ['bima', 'tala', 'laras', 'vexa', 'kairo'];
    return preferredOrder.filter((id) => id !== playerHero).slice(0, count);
  }

  private resetWorldEntities(): void {
    this.obstacles = this.map.obstacles.map((o) => ({ ...o }));
    this.actors = [];
    this.turrets = [];
    this.zones = [];
    for (const p of this.projectiles) p.active = false;
    for (const pt of this.particles) pt.active = false;
    for (const r of this.ripples) r.active = false;

    const kinds: PickupKind[] = ['armor', 'medkit', 'ammo', 'visor'];
    this.pickups = this.map.pickupSpots.map((spot, idx) => ({
      id: `pk_${idx}`,
      kind: kinds[idx % kinds.length],
      x: spot.x,
      y: spot.y,
      active: true,
      respawnTimer: 0,
    }));
  }

  private setupTitleTour(mapId: MapId): void {
    this.map = MAPS[mapId];
    this.resetWorldEntities();
    this.titleTourTime = 0;

    // Populate ambient patrolling bots for an atmospheric live bird's-eye title backdrop!
    const tourHeroes: HeroId[] = ['kairo', 'bima', 'laras', 'tala', 'vexa'];
    const spawns = this.map.soloSpawns;
    for (let i = 0; i < 4; i++) {
      const hid = tourHeroes[i % tourHeroes.length];
      const stats = computeHeroStats(hid, this.profile.heroProgress[hid]);
      const pos = spawns[i % spawns.length];
      this.actors.push(
        this.createActor({
          id: `tour_${i}`,
          name: HEROES[hid].name,
          heroId: hid,
          team: i < 2 ? 'A' : 'B',
          isPlayer: false,
          archetype: 'scout',
          pos,
          angle: i * 1.4,
          stats,
        })
      );
    }
    this.camX = this.map.width * 0.5;
    this.camY = this.map.height * 0.5;
  }

  private createActor(params: {
    id: string;
    name: string;
    heroId: HeroId;
    team: 'A' | 'B';
    isPlayer: boolean;
    archetype: BotArchetype;
    pos: Vec2;
    angle: number;
    stats: ComputedHeroStats;
    reactionDelay?: number;
  }): SimActor {
    const hero = HEROES[params.heroId];
    return {
      id: params.id,
      name: params.name,
      heroId: params.heroId,
      team: params.team,
      isPlayer: params.isPlayer,
      archetype: params.archetype,
      x: params.pos.x,
      y: params.pos.y,
      vx: 0,
      vy: 0,
      angle: params.angle,
      radius: hero.baseStats.radius,
      hp: params.stats.maxHp,
      maxHp: params.stats.maxHp,
      armor: params.stats.maxArmor,
      maxArmor: params.stats.maxArmor,
      speed: params.stats.speed,
      damage: params.stats.damage,
      visionRange: params.stats.visionRange,
      visionArcRad: params.stats.visionArcRad,
      footstepNoise: params.stats.footstepNoise,
      ammo: hero.weapon.magSize,
      maxAmmo: hero.weapon.magSize,
      reloading: false,
      reloadTimer: 0,
      fireCooldown: 0,
      activeCooldown: 0,
      activeMaxCooldown: params.stats.activeCooldown,
      activeDuration: 0,
      ultimateCooldown: 4, // Starts charging quickly
      ultimateMaxCooldown: params.stats.ultimateCooldown,
      ultimateDuration: 0,
      skillPower: params.stats.skillPowerMultiplier,
      passiveEvolved: params.stats.passiveEvolved,
      activeEvolved: params.stats.activeEvolved,
      ultimateEvolved: params.stats.ultimateEvolved,
      alive: true,
      downed: false,
      bleedoutTimer: 0,
      reviveProgress: 0,
      koTimer: 0,
      hitFlashTimer: 0,
      timeSinceDamaged: 5,
      stillTimer: 0,
      stepDistAcc: 0,
      walkPhase: 0,
      killBoostTimer: 0,
      stealthTimer: 0,
      cloakCritReady: false,
      pierceShotReady: false,
      revealedTimer: 0,
      vulnerableTimer: 0,
      slowTimer: 0,
      visorBoostTimer: 0,
      aiWaypoint: { x: this.map.width * 0.5, y: this.map.height * 0.5 },
      aiRetargetTimer: 0.4 + Math.random() * 0.8,
      aiStrafeDir: Math.random() < 0.5 ? 1 : -1,
      aiReactionTimer: params.reactionDelay ?? 0.25,
      aiTelegraphTimer: 0,
      aiTelegraphMax: 0.55,
      aiTelegraphTarget: null,
      aiTelegraphKind: 'none',
      aiHasAttackToken: false,
      aiLastSeenEnemyPos: null,
      aiLastSeenTimer: 0,
    };
  }

  private getPlayer(): SimActor | undefined {
    return this.actors.find((a) => a.isPlayer);
  }

  // ===== Event Binding =====
  private onKeyDown = (e: KeyboardEvent) => {
    const code = e.code;
    if (this.phase === 'title') {
      return;
    }

    if (code === 'Escape' || code === 'KeyP') {
      if (this.phase === 'playing') {
        e.preventDefault();
        this.pauseGame();
      } else if (this.phase === 'paused') {
        e.preventDefault();
        this.resumeGame();
      }
      return;
    }

    if (this.phase !== 'playing') return;

    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(code)) {
      e.preventDefault();
    }

    const wasDown = this.keys.has(code);
    this.keys.add(code);

    if (!wasDown) {
      if (code === 'KeyQ' || code === 'ShiftLeft') {
        this.dashBufferTimer = 0.14;
      } else if (code === 'KeyE' || code === 'Space') {
        this.triggerUltimateSkill();
      } else if (code === 'KeyR') {
        const p = this.getPlayer();
        if (p && !p.reloading && p.ammo < p.maxAmmo) {
          this.startReload(p);
        }
      } else if (code === 'KeyF') {
        this.toggleAutoFire();
      } else if (code === 'Digit1') {
        this.issueSquadCommand('follow');
      } else if (code === 'Digit2') {
        this.issueSquadCommand('attack');
      } else if (code === 'Digit3') {
        this.issueSquadCommand('defend');
      } else if (code === 'Digit4') {
        this.issueSquadCommand('regroup');
      }
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onMouseMove = (e: MouseEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    this.mouseScreen.x = e.clientX - rect.left;
    this.mouseScreen.y = e.clientY - rect.top;
  };

  private onMouseDown = (e: MouseEvent) => {
    if (this.phase !== 'playing') return;
    if (e.button === 0) {
      this.mouseDown = true;
    } else if (e.button === 2) {
      this.dashBufferTimer = 0.14;
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) {
      this.mouseDown = false;
    }
  };

  private onContextMenu = (e: MouseEvent) => {
    if (this.phase === 'playing') {
      e.preventDefault();
    }
  };

  private onBlur = () => {
    this.clearInputs();
  };

  private onVisibilityChange = () => {
    if (document.hidden) {
      this.clearInputs();
    }
  };

  private syncSize = () => {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(320, Math.round(rect.width || window.innerWidth));
    const h = Math.max(240, Math.round(rect.height || window.innerHeight));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    this.viewW = w;
    this.viewH = h;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // 0.5x resolution offscreen vision mask: 75% less pixel fill + atmospheric soft shadow edges
    this.visionCanvas.width = Math.max(160, Math.round(w * this.visionScale));
    this.visionCanvas.height = Math.max(120, Math.round(h * this.visionScale));
    this.dirtyStaticFrame = true;
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('visibilitychange', this.onVisibilityChange);
    this.canvas.addEventListener('mousemove', this.onMouseMove);
    this.canvas.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    this.canvas.addEventListener('contextmenu', this.onContextMenu);

    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.syncSize());
      this.resizeObserver.observe(this.canvas);
    } else {
      window.addEventListener('resize', this.syncSize);
    }
  }

  private unbindEvents(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('visibilitychange', this.onVisibilityChange);
    this.canvas.removeEventListener('mousemove', this.onMouseMove);
    this.canvas.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    this.canvas.removeEventListener('contextmenu', this.onContextMenu);
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    } else {
      window.removeEventListener('resize', this.syncSize);
    }
  }

  private screenToWorld(sx: number, sy: number): Vec2 {
    return {
      x: this.camX - this.viewW * 0.5 + sx,
      y: this.camY - this.viewH * 0.5 + sy,
    };
  }

  // ===== Simulation Update =====
  private update(dt: number): void {
    if (this.phase === 'paused' || this.phase === 'gameover') {
      this.shakeTrauma = Math.max(0, this.shakeTrauma - dt * 2.5);
      return;
    }

    if (this.phase === 'title') {
      this.updateTitleTour(dt);
      return;
    }

    // Real-time visual timers tick even during hitstop
    this.shakeTrauma = Math.max(0, this.shakeTrauma - dt * 2.8);
    for (const a of this.actors) {
      if (a.hitFlashTimer > 0) a.hitFlashTimer = Math.max(0, a.hitFlashTimer - dt);
      if (a.koTimer > 0) a.koTimer = Math.max(0, a.koTimer - dt);
    }
    this.updateParticles(dt);
    this.updateRipples(dt);

    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    this.matchTime += dt;
    if (this.radioCalloutTimer > 0) {
      this.radioCalloutTimer = Math.max(0, this.radioCalloutTimer - dt);
      if (this.radioCalloutTimer <= 0) this.radioCallout = null;
    }
    if (this.thermalScanTimer > 0) {
      this.thermalScanTimer = Math.max(0, this.thermalScanTimer - dt);
    }

    // Shrinking tactical storm ring after 22s to guarantee decisive late-match combat
    if (this.matchTime > 22) {
      this.stormRadius = Math.max(190, this.stormRadius - dt * 16);
    }

    // Hazard conduit periodic pulse (3.8s cycle: 0..2.7 idle, 2.7..3.4 telegraph, 3.4..3.8 active zap)
    this.hazardPulseTimer = (this.hazardPulseTimer + dt) % 3.8;

    // Buffered active skill
    if (this.dashBufferTimer > 0) {
      this.dashBufferTimer = Math.max(0, this.dashBufferTimer - dt);
      const p = this.getPlayer();
      if (p && p.alive && !p.downed && p.activeCooldown <= 0) {
        this.activateHeroSkill(p, 'active');
        this.dashBufferTimer = 0;
      }
    }

    this.updateAttackTokens();
    this.updateActors(dt);
    this.updateTurrets(dt);
    this.updateZones(dt);
    this.updateProjectiles(dt);
    this.updatePickups(dt);
    this.updateCamera(dt);
    this.updateAdaptiveSampling(dt);
    this.checkMatchOutcome(dt);

    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.085) {
      this.hudEmitTimer = 0;
      this.emitHud();
    }
  }

  private updateTitleTour(dt: number): void {
    this.titleTourTime += dt;
    const cx = this.map.width * 0.5;
    const cy = this.map.height * 0.5;
    const maxPanX = Math.max(0, (this.map.width - this.viewW) * 0.5);
    const maxPanY = Math.max(0, (this.map.height - this.viewH) * 0.5);
    this.camX = cx + Math.cos(this.titleTourTime * 0.22) * Math.min(220, maxPanX);
    this.camY = cy + Math.sin(this.titleTourTime * 0.17) * Math.min(130, maxPanY);

    for (const a of this.actors) {
      const toWpX = a.aiWaypoint.x - a.x;
      const toWpY = a.aiWaypoint.y - a.y;
      const d = Math.hypot(toWpX, toWpY);
      if (d < 45 || a.aiRetargetTimer <= 0) {
        a.aiWaypoint = {
          x: 160 + Math.random() * (this.map.width - 320),
          y: 160 + Math.random() * (this.map.height - 320),
        };
        a.aiRetargetTimer = 4 + Math.random() * 4;
      } else {
        a.aiRetargetTimer -= dt;
        const desiredAngle = Math.atan2(toWpY, toWpX);
        a.angle = normalizeAngle(a.angle + angleDiff(a.angle, desiredAngle) * Math.min(1, dt * 3.5));
        const spd = a.speed * 0.52;
        const resolved = resolveCircleRects(
          a.x + Math.cos(a.angle) * spd * dt,
          a.y + Math.sin(a.angle) * spd * dt,
          a.radius,
          this.obstacles
        );
        a.x = clamp(resolved.x, 48, this.map.width - 48);
        a.y = clamp(resolved.y, 48, this.map.height - 48);
        a.walkPhase += spd * dt * 0.06;
      }
    }
    this.updateParticles(dt);
  }

  private updateAttackTokens(): void {
    // Limit simultaneous enemy shooters attacking the player (max 3 concurrent) for fair readability
    const player = this.getPlayer();
    if (!player || !player.alive) return;

    const enemies = this.actors
      .filter((a) => a.team === 'B' && a.alive && !a.downed)
      .sort((a, b) => dist(a, player) - dist(b, player));

    const maxTokens = this.mode === 'team3v3' ? 3 : 3;
    enemies.forEach((e, idx) => {
      e.aiHasAttackToken = idx < maxTokens;
    });
  }

  private updateActors(dt: number): void {
    const center = { x: this.map.width * 0.5, y: this.map.height * 0.5 };
    const hazardActive = this.hazardPulseTimer >= 3.4;

    for (const a of this.actors) {
      if (!a.alive) continue;

      // Cooldowns & buffs
      if (a.fireCooldown > 0) a.fireCooldown = Math.max(0, a.fireCooldown - dt);
      if (a.activeCooldown > 0) a.activeCooldown = Math.max(0, a.activeCooldown - dt);
      if (a.ultimateCooldown > 0) a.ultimateCooldown = Math.max(0, a.ultimateCooldown - dt);
      if (a.activeDuration > 0) a.activeDuration = Math.max(0, a.activeDuration - dt);
      if (a.ultimateDuration > 0) a.ultimateDuration = Math.max(0, a.ultimateDuration - dt);
      if (a.killBoostTimer > 0) a.killBoostTimer = Math.max(0, a.killBoostTimer - dt);
      if (a.stealthTimer > 0) a.stealthTimer = Math.max(0, a.stealthTimer - dt);
      if (a.revealedTimer > 0) a.revealedTimer = Math.max(0, a.revealedTimer - dt);
      if (a.vulnerableTimer > 0) a.vulnerableTimer = Math.max(0, a.vulnerableTimer - dt);
      if (a.slowTimer > 0) a.slowTimer = Math.max(0, a.slowTimer - dt);
      if (a.visorBoostTimer > 0) a.visorBoostTimer = Math.max(0, a.visorBoostTimer - dt);
      a.timeSinceDamaged += dt;

      // Bima-09 Passive: Armor Regeneration when out of combat
      if (a.heroId === 'bima' && !a.downed && a.timeSinceDamaged >= 3.5 && a.armor < a.maxArmor) {
        const regen = a.passiveEvolved ? 13 : 8;
        a.armor = Math.min(a.maxArmor, a.armor + regen * dt);
      }

      // Reload timer
      if (a.reloading) {
        a.reloadTimer -= dt;
        if (a.reloadTimer <= 0) {
          a.reloading = false;
          a.ammo = a.maxAmmo;
        }
      }

      // Downed / Revive logic (Team 3v3)
      if (a.downed) {
        a.vx = 0;
        a.vy = 0;
        a.bleedoutTimer -= dt;

        // Check if any standing teammate is within revive radius (62px)
        const reviver = this.actors.find(
          (other) =>
            other.id !== a.id &&
            other.team === a.team &&
            other.alive &&
            !other.downed &&
            dist(other, a) <= 64
        );
        if (reviver) {
          const speedMult = reviver.heroId === 'tala' ? 1.45 : 1.0;
          a.reviveProgress += (dt / 2.6) * speedMult;
          if (a.reviveProgress >= 1) {
            a.downed = false;
            a.reviveProgress = 0;
            a.hp = Math.round(a.maxHp * 0.55);
            a.armor = Math.round(a.maxArmor * 0.35);
            audioEngine.playPickup();
            this.spawnBurst(a.x, a.y, '#10b981', 14, 150);
            if (reviver.isPlayer) {
              this.playerRevives += 1;
            }
            this.pushKillFeed(`${reviver.name} membangkitkan ${a.name}!`, 'ally');
          }
        } else {
          a.reviveProgress = Math.max(0, a.reviveProgress - dt * 0.25);
        }

        if (a.bleedoutTimer <= 0) {
          this.finalizeElimination(a, null);
        }
        continue;
      }

      // Storm zone damage
      if (dist(a, center) > this.stormRadius) {
        this.applyDamage(a, 11 * dt, 1, null, false);
        if (!a.alive || a.downed) continue;
      }

      // Hazard floor damage
      if (hazardActive) {
        for (const obs of this.obstacles) {
          if (obs.kind === 'hazard' && pointInRect(a.x, a.y, obs)) {
            this.applyDamage(a, 34 * dt, 0.7, null, false);
            break;
          }
        }
        if (!a.alive || a.downed) continue;
      }

      // Movement & Decision
      if (a.isPlayer) {
        this.updatePlayerActor(a, dt);
      } else {
        this.updateBotActor(a, dt);
      }
    }
  }

  private updatePlayerActor(p: SimActor, dt: number): void {
    let mx = 0;
    let my = 0;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) my -= 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) my += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) mx -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) mx += 1;

    const mag = Math.hypot(mx, my);
    if (mag > 0) {
      mx /= mag;
      my /= mag;
      p.stillTimer = 0;
    } else {
      p.stillTimer += dt;
    }

    let moveSpd = p.speed;
    if (p.killBoostTimer > 0) moveSpd *= 1.18;
    if (p.stealthTimer > 0) moveSpd *= 1.15;
    if (p.slowTimer > 0) moveSpd *= 0.62;
    if (p.activeDuration > 0 && p.heroId === 'bima') moveSpd *= 0.76; // Shield brace

    p.vx = mx * moveSpd;
    p.vy = my * moveSpd;

    const resolved = resolveCircleRects(p.x + p.vx * dt, p.y + p.vy * dt, p.radius, this.obstacles);
    const moved = Math.hypot(resolved.x - p.x, resolved.y - p.y);
    p.x = clamp(resolved.x, 36, this.map.width - 36);
    p.y = clamp(resolved.y, 36, this.map.height - 36);
    p.walkPhase += moved * 0.09;
    p.stepDistAcc += moved;

    // Footstep sound ripples
    if (p.stepDistAcc >= 68) {
      p.stepDistAcc = 0;
      const inBush = isPositionInBush(p, this.obstacles);
      const quietMult = p.heroId === 'kairo' ? 0.55 : 1;
      if (!inBush && p.stealthTimer <= 0) {
        this.spawnRipple(p.x, p.y, p.footstepNoise * quietMult * 0.65, 'rgba(226, 232, 240, 0.35)');
      }
    }

    // Aim toward mouse cursor in world space
    const mouseWorld = this.screenToWorld(this.mouseScreen.x, this.mouseScreen.y);
    p.angle = Math.atan2(mouseWorld.y - p.y, mouseWorld.x - p.x);

    // Manual fire OR Bullet Echo signature Auto-Fire when visible enemy enters weapon cone!
    let shouldShoot = this.mouseDown;
    if (!shouldShoot && this.autoFire && !p.reloading && p.fireCooldown <= 0) {
      const weapon = HEROES[p.heroId].weapon;
      const inConeTarget = this.actors.find((e) => {
        if (e.team === p.team || !e.alive || e.downed) return false;
        const d = dist(p, e);
        if (d > weapon.range * 1.02) return false;
        const toE = Math.atan2(e.y - p.y, e.x - p.x);
        if (Math.abs(angleDiff(p.angle, toE)) > Math.min(0.46, p.visionArcRad * 0.45)) return false;
        return hasLineOfSight(p, e, this.obstacles, false);
      });
      if (inConeTarget) {
        shouldShoot = true;
      }
    }

    if (shouldShoot) {
      this.tryFireWeapon(p, mag > 0.1);
    }
  }

  private updateBotActor(bot: SimActor, dt: number): void {
    const hero = HEROES[bot.heroId];
    const weapon = hero.weapon;
    const isAlly = bot.team === 'A';
    const player = this.getPlayer();
    const insights = analyzeAdaptiveMemory(this.adaptiveMemory);

    // 1. Acquire highest-priority visible enemy
    let target: SimActor | null = null;
    let bestScore = Infinity;

    for (const other of this.actors) {
      if (other.team === bot.team || !other.alive || other.downed) continue;
      const d = dist(bot, other);
      // Stealth bush / Kairo cloak reduces bot detection radius
      const inBush = isPositionInBush(other, this.obstacles);
      const effectiveDetectRange =
        other.stealthTimer > 0
          ? 75
          : inBush
            ? 145
            : bot.visionRange * 1.05;

      const canSee =
        (other.revealedTimer > 0 && d < bot.visionRange * 1.25) ||
        (d <= effectiveDetectRange &&
          isPointInVisionCone(
            bot,
            bot.angle,
            bot.visionArcRad * 1.15,
            effectiveDetectRange,
            135,
            other,
            this.obstacles
          ));

      if (canSee) {
        const score = d - (other.hp / other.maxHp < 0.35 ? 110 : 0);
        if (score < bestScore) {
          bestScore = score;
          target = other;
        }
      }
    }

    // Also allow enemy bots to target Tala's deployed turrets!
    let targetTurret: DeployedTurret | null = null;
    if (!target) {
      for (const t of this.turrets) {
        if (t.team !== bot.team && dist(bot, t) < bot.visionRange && hasLineOfSight(bot, t, this.obstacles)) {
          targetTurret = t;
          break;
        }
      }
    }

    if (target) {
      bot.aiLastSeenEnemyPos = { x: target.x, y: target.y };
      bot.aiLastSeenTimer = 4.5;
    } else if (bot.aiLastSeenTimer > 0) {
      bot.aiLastSeenTimer = Math.max(0, bot.aiLastSeenTimer - dt);
    }

    // 2. Allied Bot priority: Revive downed teammate (especially player!)
    let moveGoal: Vec2 | null = null;
    if (isAlly) {
      const downedFriend = this.actors.find(
        (f) => f.team === 'A' && f.id !== bot.id && f.alive && f.downed
      );
      if (downedFriend) {
        moveGoal = { x: downedFriend.x, y: downedFriend.y };
      }
    }

    // 3. Handle active telegraphed attacks (Marksman Sniper Laser / Breacher Blast Ring)
    if (bot.aiTelegraphTimer > 0) {
      bot.aiTelegraphTimer -= dt;
      if (target && bot.aiTelegraphKind === 'sniper') {
        const leadAngle = computeAdaptiveAimAngle(
          bot,
          target,
          { x: target.vx, y: target.vy },
          weapon.projectileSpeed,
          this.adaptiveMemory,
          target.isPlayer
        );
        bot.angle = normalizeAngle(bot.angle + angleDiff(bot.angle, leadAngle) * Math.min(1, dt * 6));
      }
      if (bot.aiTelegraphTimer <= 0) {
        if (bot.aiTelegraphKind === 'sniper') {
          this.tryFireWeapon(bot, false, true);
        } else if (bot.aiTelegraphKind === 'breach' && bot.aiTelegraphTarget) {
          this.zones.push({
            id: `breach_${Date.now()}_${Math.random()}`,
            kind: 'breach_blast',
            team: bot.team,
            ownerId: bot.id,
            x: bot.aiTelegraphTarget.x,
            y: bot.aiTelegraphTarget.y,
            radius: 78,
            ttl: 0.25,
            maxTtl: 0.25,
            power: Math.round(30 * (0.9 + insights.adaptationLevel * 0.05)),
            detonated: false,
          });
        }
        bot.aiTelegraphKind = 'none';
        bot.aiTelegraphTarget = null;
      }
      bot.vx *= 0.7;
      bot.vy *= 0.7;
      return;
    }

    // 4. Compute movement vector based on Team Role / Archetype / Adaptive Memory
    let desiredMoveAngle: number | null = null;
    let speedFactor = 0.88;

    if (moveGoal) {
      desiredMoveAngle = Math.atan2(moveGoal.y - bot.y, moveGoal.x - bot.x);
      speedFactor = 1.0;
    } else if (target) {
      const d = dist(bot, target);
      const toTargetAngle = Math.atan2(target.y - bot.y, target.x - bot.x);

      // Predictive aiming for enemies against player!
      const aimAngle = !isAlly
        ? computeAdaptiveAimAngle(
            bot,
            target,
            { x: target.vx, y: target.vy },
            weapon.projectileSpeed,
            this.adaptiveMemory,
            target.isPlayer
          )
        : toTargetAngle;

      bot.angle = normalizeAngle(bot.angle + angleDiff(bot.angle, aimAngle) * Math.min(1, dt * 8.5));

      // Archetype movement policies (4 genuinely distinct behaviors!)
      if (bot.archetype === 'marksman') {
        // Kiter: maintains long range 330..440px, retreats if player closes in
        if (d < 275) {
          desiredMoveAngle = toTargetAngle + Math.PI + bot.aiStrafeDir * 0.35;
          speedFactor = 0.96;
        } else if (d > 430) {
          desiredMoveAngle = toTargetAngle;
          speedFactor = 0.82;
        } else {
          desiredMoveAngle = toTargetAngle + (Math.PI * 0.5) * bot.aiStrafeDir;
          speedFactor = 0.55;
        }
      } else if (bot.archetype === 'vanguard') {
        // Shielded Front: advances steadily toward target, pops Aegis shield under fire
        if (d > 175) {
          desiredMoveAngle = toTargetAngle + bot.aiStrafeDir * 0.18;
          speedFactor = 0.85;
        } else {
          desiredMoveAngle = toTargetAngle + (Math.PI * 0.5) * bot.aiStrafeDir;
          speedFactor = 0.55;
        }
      } else if (bot.archetype === 'breacher') {
        // Area-Denial: holds mid-range and telegraphs blast ring when player camps/lingers
        if (d < 190) {
          desiredMoveAngle = toTargetAngle + Math.PI * 0.85 * bot.aiStrafeDir;
          speedFactor = 0.85;
        } else if (d > 330) {
          desiredMoveAngle = toTargetAngle;
          speedFactor = 0.82;
        } else {
          desiredMoveAngle = toTargetAngle + (Math.PI * 0.5) * bot.aiStrafeDir;
          speedFactor = 0.65;
        }
      } else {
        // Scout / Flanker: orbits aggressively using ADAPTIVE flank sign!
        const flankSign = !isAlly ? insights.preferredFlankSign : bot.aiStrafeDir;
        const preferredDist = !isAlly && this.adaptiveMemory.avgEngageRange < 220 ? 235 : 165;
        if (d > preferredDist + 45) {
          desiredMoveAngle = toTargetAngle + flankSign * 0.52;
          speedFactor = 1.0;
        } else if (d < preferredDist - 40) {
          desiredMoveAngle = toTargetAngle + Math.PI - flankSign * 0.45;
          speedFactor = 0.92;
        } else {
          desiredMoveAngle = toTargetAngle + (Math.PI * 0.5) * flankSign;
          speedFactor = 0.92;
        }
      }

      // Periodically flip strafe so bots don't get stuck on walls
      bot.aiRetargetTimer -= dt;
      if (bot.aiRetargetTimer <= 0) {
        bot.aiStrafeDir *= -1;
        bot.aiRetargetTimer = 1.4 + Math.random() * 1.6;
      }

      // Smart skill usage by bots
      if (bot.activeCooldown <= 0 && d < 360) {
        if (bot.heroId === 'bima' && bot.hp < bot.maxHp * 0.85) {
          this.activateHeroSkill(bot, 'active');
        } else if (bot.heroId === 'tala' && d < 280) {
          this.activateHeroSkill(bot, 'active');
        } else if (bot.heroId === 'vexa' && d < 320) {
          this.activateHeroSkill(bot, 'active');
        } else if (bot.heroId === 'laras' && isAlly) {
          this.activateHeroSkill(bot, 'active');
        }
      }
      if (bot.ultimateCooldown <= 0 && bot.hp < bot.maxHp * 0.65 && (bot.heroId === 'tala' || bot.heroId === 'vexa')) {
        this.activateHeroSkill(bot, 'ultimate');
      }

      // Combat Firing with telegraphs & attack token pool
      const canAttack = isAlly || bot.aiHasAttackToken;
      if (canAttack && d <= weapon.range * 1.05 && Math.abs(angleDiff(bot.angle, aimAngle)) < 0.34) {
        if (!isAlly && bot.archetype === 'marksman' && bot.fireCooldown <= 0 && !bot.reloading) {
          // Visible 0.55s Sniper Laser Telegraph!
          bot.aiTelegraphKind = 'sniper';
          bot.aiTelegraphMax = 0.55;
          bot.aiTelegraphTimer = 0.55;
          bot.aiTelegraphTarget = { x: target.x, y: target.y };
        } else if (
          !isAlly &&
          bot.archetype === 'breacher' &&
          bot.activeCooldown <= 0 &&
          d < 340 &&
          (this.adaptiveMemory.coverCampRatio > 0.35 || Math.random() < 0.35)
        ) {
          // Visible 0.65s Breacher Ground Blast Ring Telegraph!
          bot.activeCooldown = 7.5;
          bot.aiTelegraphKind = 'breach';
          bot.aiTelegraphMax = 0.65;
          bot.aiTelegraphTimer = 0.65;
          bot.aiTelegraphTarget = {
            x: clamp(target.x + target.vx * 0.35, 60, this.map.width - 60),
            y: clamp(target.y + target.vy * 0.35, 60, this.map.height - 60),
          };
        } else {
          this.tryFireWeapon(bot, true);
        }
      }
    } else if (targetTurret) {
      const toT = Math.atan2(targetTurret.y - bot.y, targetTurret.x - bot.x);
      bot.angle = normalizeAngle(bot.angle + angleDiff(bot.angle, toT) * Math.min(1, dt * 7));
      if (dist(bot, targetTurret) <= weapon.range) {
        this.tryFireWeapon(bot, false);
      } else {
        desiredMoveAngle = toT;
      }
    } else {
      // No target visible: execute Squad Command (if ally) or Adaptive Heatmap Hunt (if enemy)!
      bot.aiRetargetTimer -= dt;
      const center = { x: this.map.width * 0.5, y: this.map.height * 0.5 };

      if (isAlly && player && player.alive) {
        const allyIdx = bot.id.endsWith('0') ? 0 : 1;
        const sideOffset = allyIdx === 0 ? -1 : 1;

        if (this.squadCommand === 'follow') {
          const flankAng = player.angle + Math.PI * 0.72 * sideOffset;
          bot.aiWaypoint = {
            x: clamp(player.x + Math.cos(flankAng) * 95, 64, this.map.width - 64),
            y: clamp(player.y + Math.sin(flankAng) * 95, 64, this.map.height - 64),
          };
        } else if (this.squadCommand === 'regroup') {
          bot.aiWaypoint = {
            x: clamp(player.x + sideOffset * 55, 64, this.map.width - 64),
            y: clamp(player.y + 40, 64, this.map.height - 64),
          };
        } else if (this.squadCommand === 'defend') {
          if (bot.aiRetargetTimer <= 0) {
            bot.aiWaypoint = {
              x: clamp(player.x + Math.cos(player.angle + sideOffset * 0.9) * 140, 70, this.map.width - 70),
              y: clamp(player.y + Math.sin(player.angle + sideOffset * 0.9) * 140, 70, this.map.height - 70),
            };
            bot.aiRetargetTimer = 2.6;
          }
        } else if (this.squadCommand === 'attack') {
          const nearestEnemy = this.actors
            .filter((e) => e.team === 'B' && e.alive && !e.downed)
            .sort((a, b) => dist(bot, a) - dist(bot, b))[0];
          if (nearestEnemy) {
            // Flank around nearest enemy
            const angToE = Math.atan2(nearestEnemy.y - bot.y, nearestEnemy.x - bot.x);
            bot.aiWaypoint = {
              x: clamp(nearestEnemy.x + Math.cos(angToE + sideOffset * 1.1) * 130, 70, this.map.width - 70),
              y: clamp(nearestEnemy.y + Math.sin(angToE + sideOffset * 1.1) * 130, 70, this.map.height - 70),
            };
          }
        }
      } else {
        // Enemy Bot: Use learned Adaptive Heatmap hotspots OR last-seen position OR stay inside storm!
        if (dist(bot, center) > this.stormRadius - 90) {
          bot.aiWaypoint = { x: center.x + (Math.random() - 0.5) * 200, y: center.y + (Math.random() - 0.5) * 200 };
        } else if (bot.aiLastSeenEnemyPos && bot.aiLastSeenTimer > 0) {
          bot.aiWaypoint = bot.aiLastSeenEnemyPos;
        } else if (dist(bot, bot.aiWaypoint) < 60 || bot.aiRetargetTimer <= 0) {
          const hotspots = getTopPlayerHotspots(
            this.adaptiveMemory,
            this.map.id,
            this.map.width,
            this.map.height,
            3
          );
          if (hotspots.length > 0 && Math.random() < 0.65) {
            const pick = hotspots[Math.floor(Math.random() * hotspots.length)];
            bot.aiWaypoint = {
              x: clamp(pick.x + (Math.random() - 0.5) * 120, 80, this.map.width - 80),
              y: clamp(pick.y + (Math.random() - 0.5) * 120, 80, this.map.height - 80),
            };
          } else {
            // Patrol tactical mid lanes
            bot.aiWaypoint = {
              x: clamp(center.x + (Math.random() - 0.5) * 900, 90, this.map.width - 90),
              y: clamp(center.y + (Math.random() - 0.5) * 650, 90, this.map.height - 90),
            };
          }
          bot.aiRetargetTimer = 3.2 + Math.random() * 2.5;
        }
      }

      const toWp = Math.atan2(bot.aiWaypoint.y - bot.y, bot.aiWaypoint.x - bot.x);
      if (dist(bot, bot.aiWaypoint) > 36) {
        desiredMoveAngle = toWp;
        bot.angle = normalizeAngle(bot.angle + angleDiff(bot.angle, toWp) * Math.min(1, dt * 4.8));
      } else {
        // Scan flashlight around defensively
        bot.angle = normalizeAngle(bot.angle + Math.sin(this.matchTime * 1.4 + bot.x) * dt * 1.1);
      }
    }

    // Apply movement with obstacle steering
    if (desiredMoveAngle !== null) {
      let spd = bot.speed * speedFactor;
      if (bot.slowTimer > 0) spd *= 0.62;
      if (bot.activeDuration > 0 && bot.heroId === 'bima') spd *= 0.78;

      const tryX = bot.x + Math.cos(desiredMoveAngle) * spd * dt;
      const tryY = bot.y + Math.sin(desiredMoveAngle) * spd * dt;
      const res = resolveCircleRects(tryX, tryY, bot.radius, this.obstacles);

      const actualMove = Math.hypot(res.x - bot.x, res.y - bot.y);
      // If blocked by wall, nudge perpendicular to slide smoothly around corners!
      if (actualMove < spd * dt * 0.25) {
        const slideAng = desiredMoveAngle + (Math.PI * 0.5) * bot.aiStrafeDir;
        const slideRes = resolveCircleRects(
          bot.x + Math.cos(slideAng) * spd * dt,
          bot.y + Math.sin(slideAng) * spd * dt,
          bot.radius,
          this.obstacles
        );
        bot.vx = (slideRes.x - bot.x) / dt;
        bot.vy = (slideRes.y - bot.y) / dt;
        bot.x = clamp(slideRes.x, 36, this.map.width - 36);
        bot.y = clamp(slideRes.y, 36, this.map.height - 36);
      } else {
        bot.vx = (res.x - bot.x) / dt;
        bot.vy = (res.y - bot.y) / dt;
        bot.x = clamp(res.x, 36, this.map.width - 36);
        bot.y = clamp(res.y, 36, this.map.height - 36);
      }

      bot.walkPhase += actualMove * 0.085;
      bot.stepDistAcc += actualMove;
      if (bot.stepDistAcc >= 82) {
        bot.stepDistAcc = 0;
        const inBush = isPositionInBush(bot, this.obstacles);
        if (!inBush && bot.stealthTimer <= 0) {
          this.spawnRipple(
            bot.x,
            bot.y,
            bot.footstepNoise * 0.55,
            bot.team === 'B' ? 'rgba(239, 68, 68, 0.42)' : 'rgba(16, 185, 129, 0.3)'
          );
        }
      }
    } else {
      bot.vx = 0;
      bot.vy = 0;
    }
  }

  private startReload(actor: SimActor): void {
    actor.reloading = true;
    actor.reloadTimer = HEROES[actor.heroId].weapon.reloadTime;
  }

  private tryFireWeapon(actor: SimActor, isMoving: boolean, forcedAccurate = false): void {
    if (actor.reloading || actor.fireCooldown > 0 || !actor.alive || actor.downed) return;
    if (actor.ammo <= 0) {
      this.startReload(actor);
      return;
    }

    const hero = HEROES[actor.heroId];
    const w = hero.weapon;
    actor.ammo -= 1;
    actor.fireCooldown = 1 / w.fireRate;
    actor.stealthTimer = 0; // Firing breaks cloak!

    let dmg = actor.damage;
    let armorPen = w.armorPen;
    let pierceLow = Boolean(w.pierceLowCover);
    let isCrit = false;

    if (actor.cloakCritReady) {
      dmg = Math.round(dmg * 1.8);
      if (actor.ultimateEvolved) armorPen = Math.max(armorPen, 0.65);
      actor.cloakCritReady = false;
      isCrit = true;
    }
    if (actor.pierceShotReady) {
      dmg = Math.round(dmg * 2.1);
      pierceLow = true;
      if (actor.ultimateEvolved) armorPen = 1;
      actor.pierceShotReady = false;
      isCrit = true;
    }
    if (actor.heroId === 'laras' && actor.stillTimer >= 0.5 && actor.passiveEvolved) {
      dmg = Math.round(dmg * 1.15);
      isCrit = true;
    }

    // Spread calculation
    let spread = w.spreadRad + (isMoving ? w.moveSpreadBonus : 0);
    if (actor.heroId === 'laras' && actor.stillTimer >= 0.5) spread *= 0.3;
    if (!actor.isPlayer && !forcedAccurate) {
      const diff = computeBotDifficultyScale(
        computeHeroStats(actor.heroId, this.profile.heroProgress[actor.heroId]),
        getAdaptationLevel(this.adaptiveMemory),
        this.profile.winStreak
      );
      spread += diff.accuracySpread * 0.55;
    }

    const muzzleX = actor.x + Math.cos(actor.angle) * (actor.radius + 9);
    const muzzleY = actor.y + Math.sin(actor.angle) * (actor.radius + 9);

    for (let i = 0; i < w.pellets; i++) {
      const offset = (Math.random() - 0.5) * spread * 2;
      const shotAng = actor.angle + offset;
      this.spawnProjectile({
        ownerId: actor.id,
        team: actor.team,
        heroId: actor.heroId,
        x: muzzleX,
        y: muzzleY,
        vx: Math.cos(shotAng) * w.projectileSpeed,
        vy: Math.sin(shotAng) * w.projectileSpeed,
        damage: dmg,
        armorPen,
        remainingDist: w.range,
        color: isCrit ? '#fef08a' : w.tracerColor,
        radius: actor.heroId === 'vexa' ? 5 : actor.heroId === 'laras' ? 3.5 : 2.8,
        pierceLowCover: pierceLow,
        splashRadius: w.splashRadius ?? 0,
        applyBioMark: actor.heroId === 'vexa',
        isCrit,
      });
    }

    // Muzzle flash particles & gunfire sound ripple
    this.spawnBurst(muzzleX, muzzleY, isCrit ? '#fef08a' : w.tracerColor, 4, 140);
    this.spawnRipple(
      actor.x,
      actor.y,
      w.noiseRadius * 0.52,
      actor.team === 'B' ? 'rgba(248, 113, 113, 0.58)' : 'rgba(251, 191, 36, 0.35)'
    );

    const player = this.getPlayer();
    if (actor.isPlayer) {
      audioEngine.playShoot(actor.heroId, 0.24);
      this.shakeTrauma = Math.min(1, this.shakeTrauma + (actor.heroId === 'laras' || actor.heroId === 'tala' ? 0.22 : 0.08));
    } else if (player && dist(actor, player) < 620) {
      audioEngine.playShoot(actor.heroId, 0.11);
    }

    if (actor.ammo <= 0) {
      this.startReload(actor);
    }
  }

  private activateHeroSkill(actor: SimActor, slot: 'active' | 'ultimate'): void {
    if (slot === 'active') {
      if (actor.activeCooldown > 0) return;
      actor.activeCooldown = actor.activeMaxCooldown;
      if (actor.isPlayer) audioEngine.playSkill(false);

      if (actor.heroId === 'kairo') {
        // Blink Dash forward along aim angle
        const dashDist = actor.activeEvolved ? 175 : 140;
        const steps = 6;
        let nx = actor.x;
        let ny = actor.y;
        this.spawnBurst(actor.x, actor.y, '#f59e0b', 12, 160);
        for (let i = 1; i <= steps; i++) {
          const res = resolveCircleRects(
            nx + (Math.cos(actor.angle) * dashDist) / steps,
            ny + (Math.sin(actor.angle) * dashDist) / steps,
            actor.radius,
            this.obstacles
          );
          nx = clamp(res.x, 36, this.map.width - 36);
          ny = clamp(res.y, 36, this.map.height - 36);
        }
        actor.x = nx;
        actor.y = ny;
        this.spawnBurst(actor.x, actor.y, '#fbbf24', 14, 180);
      } else if (actor.heroId === 'bima') {
        // Mobile Aegis Shield
        actor.activeDuration = 4.2;
        this.spawnBurst(actor.x, actor.y, '#fb923c', 12, 130);
      } else if (actor.heroId === 'laras') {
        // Thermal Spirit Lantern Pulse: reveals all enemies through walls!
        const dur = actor.activeEvolved ? 6.0 : 4.5;
        actor.activeDuration = dur;
        if (actor.team === 'A') this.thermalScanTimer = dur;
        for (const e of this.actors) {
          if (e.team !== actor.team && e.alive) {
            e.revealedTimer = Math.max(e.revealedTimer, dur);
          }
        }
        this.spawnRipple(actor.x, actor.y, 580, '#fde047');
        if (actor.isPlayer) {
          this.radioCallout = 'Pendar Lentera aktif — posisi semua musuh tersingkap!';
          this.radioCalloutTimer = 2.6;
        }
      } else if (actor.heroId === 'tala') {
        // Deploy Scrap Mini-Turret
        const tx = clamp(actor.x + Math.cos(actor.angle) * 44, 50, this.map.width - 50);
        const ty = clamp(actor.y + Math.sin(actor.angle) * 44, 50, this.map.height - 50);
        const res = resolveCircleRects(tx, ty, 15, this.obstacles);
        // Max 1 active turret per Tala
        this.turrets = this.turrets.filter((t) => t.ownerId !== actor.id);
        this.turrets.push({
          id: `turret_${actor.id}_${Date.now()}`,
          ownerId: actor.id,
          team: actor.team,
          x: res.x,
          y: res.y,
          angle: actor.angle,
          hp: Math.round((actor.activeEvolved ? 130 : 95) * actor.skillPower),
          maxHp: Math.round((actor.activeEvolved ? 130 : 95) * actor.skillPower),
          ttl: 14,
          fireCooldown: 0.3,
          damage: Math.round(13 * actor.skillPower),
        });
        this.spawnBurst(res.x, res.y, '#14b8a6', 12, 140);
      } else if (actor.heroId === 'vexa') {
        // Throw Spore Cloud toward aim
        const targetDist = 175;
        const gx = clamp(actor.x + Math.cos(actor.angle) * targetDist, 60, this.map.width - 60);
        const gy = clamp(actor.y + Math.sin(actor.angle) * targetDist, 60, this.map.height - 60);
        this.zones.push({
          id: `spore_${Date.now()}_${Math.random()}`,
          kind: 'spore',
          team: actor.team,
          ownerId: actor.id,
          x: gx,
          y: gy,
          radius: actor.activeEvolved ? 115 : 92,
          ttl: 6.2,
          maxTtl: 6.2,
          power: Math.round(18 * actor.skillPower),
        });
        this.spawnBurst(gx, gy, '#10b981', 16, 160);
      }
    } else {
      // Ultimate Skill [E]
      if (actor.ultimateCooldown > 0) return;
      actor.ultimateCooldown = actor.ultimateMaxCooldown;
      if (actor.isPlayer) {
        audioEngine.playSkill(true);
        this.shakeTrauma = Math.min(1, this.shakeTrauma + 0.25);
      }

      if (actor.heroId === 'kairo') {
        // Chrono Cloak + guaranteed crit shot
        const dur = actor.ultimateEvolved ? 4.5 : 3.5;
        actor.stealthTimer = dur;
        actor.ultimateDuration = dur;
        actor.cloakCritReady = true;
        this.spawnBurst(actor.x, actor.y, '#f59e0b', 18, 170);
      } else if (actor.heroId === 'bima') {
        // Seismic Slam: AoE damage + knockback + breaks nearby crates
        const slamRadius = 155;
        this.spawnRipple(actor.x, actor.y, slamRadius, '#fb923c');
        this.spawnBurst(actor.x, actor.y, '#f97316', 24, 240);
        for (const obs of this.obstacles) {
          if (obs.kind === 'crate' && (obs.hp ?? 0) > 0) {
            const cx = obs.x + obs.w * 0.5;
            const cy = obs.y + obs.h * 0.5;
            if (dist(actor, { x: cx, y: cy }) <= slamRadius) {
              obs.hp = 0;
              this.onCrateDestroyed(obs);
            }
          }
        }
        for (const e of this.actors) {
          if (e.team !== actor.team && e.alive && !e.downed && dist(actor, e) <= slamRadius) {
            this.applyDamage(e, Math.round(48 * actor.skillPower), 0.5, actor, true);
            const pushAng = Math.atan2(e.y - actor.y, e.x - actor.x);
            const pushed = resolveCircleRects(
              e.x + Math.cos(pushAng) * 58,
              e.y + Math.sin(pushAng) * 58,
              e.radius,
              this.obstacles
            );
            e.x = clamp(pushed.x, 36, this.map.width - 36);
            e.y = clamp(pushed.y, 36, this.map.height - 36);
            if (actor.ultimateEvolved) e.slowTimer = 2.5;
          }
        }
      } else if (actor.heroId === 'laras') {
        // Spirit Piercer empowered shot
        actor.pierceShotReady = true;
        actor.ultimateDuration = 6.0;
        actor.ammo = Math.max(actor.ammo, 1);
        actor.reloading = false;
        this.spawnBurst(actor.x, actor.y, '#fde047', 16, 150);
      } else if (actor.heroId === 'tala') {
        // Nano Patch Healing Dome
        actor.ultimateDuration = 5.2;
        this.zones.push({
          id: `heal_${Date.now()}_${Math.random()}`,
          kind: 'heal',
          team: actor.team,
          ownerId: actor.id,
          x: actor.x,
          y: actor.y,
          radius: 135,
          ttl: 5.2,
          maxTtl: 5.2,
          power: Math.round(22 * actor.skillPower),
        });
        this.spawnBurst(actor.x, actor.y, '#2dd4bf', 20, 170);
      } else if (actor.heroId === 'vexa') {
        // Bioluminescent Overgrowth Surge
        const surgeRadius = 210;
        this.spawnRipple(actor.x, actor.y, surgeRadius, '#34d399');
        this.spawnBurst(actor.x, actor.y, '#34d399', 24, 210);
        for (const other of this.actors) {
          if (!other.alive || other.downed || dist(actor, other) > surgeRadius) continue;
          if (other.team === actor.team) {
            other.hp = Math.min(other.maxHp, other.hp + Math.round(35 * actor.skillPower));
            other.armor = Math.min(other.maxArmor, other.armor + Math.round(25 * actor.skillPower));
          } else {
            other.vulnerableTimer = 5.0;
            other.revealedTimer = Math.max(other.revealedTimer, 4.5);
            if (actor.ultimateEvolved) {
              this.applyDamage(other, Math.round(28 * actor.skillPower), 0.6, actor, false);
            }
          }
        }
      }
    }
    this.emitHud();
  }

  private updateTurrets(dt: number): void {
    for (let i = this.turrets.length - 1; i >= 0; i--) {
      const t = this.turrets[i];
      t.ttl -= dt;
      if (t.ttl <= 0 || t.hp <= 0) {
        this.spawnBurst(t.x, t.y, '#14b8a6', 12, 140);
        this.turrets.splice(i, 1);
        continue;
      }

      if (t.fireCooldown > 0) t.fireCooldown -= dt;

      const target = this.actors
        .filter((e) => e.team !== t.team && e.alive && !e.downed && dist(t, e) < 290 && hasLineOfSight(t, e, this.obstacles))
        .sort((a, b) => dist(t, a) - dist(t, b))[0];

      if (target) {
        const desired = Math.atan2(target.y - t.y, target.x - t.x);
        t.angle = normalizeAngle(t.angle + angleDiff(t.angle, desired) * Math.min(1, dt * 10));
        if (t.fireCooldown <= 0 && Math.abs(angleDiff(t.angle, desired)) < 0.25) {
          t.fireCooldown = 0.34;
          this.spawnProjectile({
            ownerId: t.ownerId,
            team: t.team,
            heroId: 'tala',
            x: t.x + Math.cos(t.angle) * 14,
            y: t.y + Math.sin(t.angle) * 14,
            vx: Math.cos(t.angle) * 760,
            vy: Math.sin(t.angle) * 760,
            damage: t.damage,
            armorPen: 0.25,
            remainingDist: 300,
            color: '#5eead4',
            radius: 2.6,
            pierceLowCover: false,
            splashRadius: 0,
            applyBioMark: false,
            isCrit: false,
          });
        }
      } else {
        t.angle = normalizeAngle(t.angle + dt * 1.1);
      }
    }
  }

  private updateZones(dt: number): void {
    for (let i = this.zones.length - 1; i >= 0; i--) {
      const z = this.zones[i];
      z.ttl -= dt;

      if (z.kind === 'breach_blast' && !z.detonated) {
        z.detonated = true;
        this.spawnBurst(z.x, z.y, '#f97316', 22, 230);
        this.spawnRipple(z.x, z.y, z.radius * 1.6, '#ef4444');
        const owner = this.actors.find((a) => a.id === z.ownerId) ?? null;
        for (const a of this.actors) {
          if (a.team !== z.team && a.alive && !a.downed && dist(a, z) <= z.radius + a.radius) {
            this.applyDamage(a, z.power, 0.5, owner, true);
          }
        }
      } else if (z.kind === 'spore') {
        const owner = this.actors.find((a) => a.id === z.ownerId) ?? null;
        for (const a of this.actors) {
          if (a.team !== z.team && a.alive && !a.downed && dist(a, z) <= z.radius) {
            a.slowTimer = Math.max(a.slowTimer, 0.4);
            a.revealedTimer = Math.max(a.revealedTimer, 0.6);
            this.applyDamage(a, z.power * dt, 0.55, owner, false);
          }
        }
      } else if (z.kind === 'heal') {
        for (const a of this.actors) {
          if (a.team === z.team && a.alive && !a.downed && dist(a, z) <= z.radius) {
            a.hp = Math.min(a.maxHp, a.hp + z.power * dt);
            a.armor = Math.min(a.maxArmor, a.armor + z.power * 0.75 * dt);
          }
        }
      }

      if (z.ttl <= 0) {
        this.zones.splice(i, 1);
      }
    }
  }

  private updateProjectiles(dt: number): void {
    for (let i = 0; i < this.projectiles.length; i++) {
      const pr = this.projectiles[i];
      if (!pr.active) continue;

      const stepX = pr.vx * dt;
      const stepY = pr.vy * dt;
      const stepDist = Math.hypot(stepX, stepY);
      pr.x += stepX;
      pr.y += stepY;
      pr.remainingDist -= stepDist;

      if (
        pr.remainingDist <= 0 ||
        pr.x < 10 ||
        pr.x > this.map.width - 10 ||
        pr.y < 10 ||
        pr.y > this.map.height - 10
      ) {
        pr.active = false;
        continue;
      }

      // Check Wall / Destructible Crate collision
      let hitWall = false;
      for (const obs of this.obstacles) {
        if (obs.kind === 'bush' || obs.kind === 'hazard') continue;
        if (obs.kind === 'low_cover') continue; // Bullets fly over low barricades!
        if (obs.kind === 'crate' && (obs.hp ?? 0) <= 0) continue;

        if (circleIntersectsRect(pr.x, pr.y, pr.radius, obs)) {
          if (obs.kind === 'crate' && obs.hp !== undefined) {
            obs.hp -= pr.damage;
            this.spawnBurst(pr.x, pr.y, '#c2854c', 6, 130);
            if (obs.hp <= 0) {
              this.onCrateDestroyed(obs);
            }
          } else {
            this.spawnBurst(pr.x, pr.y, '#cbd5e1', 5, 110);
          }
          hitWall = true;
          break;
        }
      }
      if (hitWall) {
        if (pr.splashRadius > 0) this.triggerSplash(pr);
        pr.active = false;
        continue;
      }

      // Check Turret collision
      let hitSomething = false;
      for (const t of this.turrets) {
        if (t.team !== pr.team && dist(pr, t) <= 16 + pr.radius) {
          t.hp -= pr.damage;
          this.spawnBurst(pr.x, pr.y, '#5eead4', 6, 130);
          hitSomething = true;
          break;
        }
      }
      if (hitSomething) {
        pr.active = false;
        continue;
      }

      // Check Actor collision
      for (const a of this.actors) {
        if (a.team === pr.team || !a.alive || a.downed) continue;
        if (dist(pr, a) <= a.radius + pr.radius) {
          const attacker = this.actors.find((u) => u.id === pr.ownerId) ?? null;

          // Check Bima-09 Aegis Shield or Vanguard frontal ballistic shield
          let finalDmg = pr.damage;
          const incomingAngle = Math.atan2(pr.y - a.y, pr.x - a.x);
          const frontalHit = Math.abs(angleDiff(a.angle, incomingAngle)) < 1.15;

          if (a.heroId === 'bima' && a.activeDuration > 0 && frontalHit) {
            finalDmg *= 0.2;
            this.spawnBurst(pr.x, pr.y, '#38bdf8', 7, 160);
          } else if (!a.isPlayer && a.archetype === 'vanguard' && frontalHit) {
            finalDmg *= 0.58;
            this.spawnBurst(pr.x, pr.y, '#94a3b8', 5, 130);
          }

          if (pr.applyBioMark) {
            a.revealedTimer = Math.max(a.revealedTimer, attacker?.passiveEvolved ? 4.0 : 2.5);
          }

          this.applyDamage(a, finalDmg, pr.armorPen, attacker, pr.isCrit || finalDmg >= 35);
          if (pr.splashRadius > 0) this.triggerSplash(pr);
          pr.active = false;
          break;
        }
      }
    }
  }

  private triggerSplash(pr: Projectile): void {
    const attacker = this.actors.find((u) => u.id === pr.ownerId) ?? null;
    this.spawnBurst(pr.x, pr.y, '#34d399', 12, 160);
    for (const a of this.actors) {
      if (a.team === pr.team || !a.alive || a.downed) continue;
      if (dist(pr, a) <= pr.splashRadius) {
        this.applyDamage(a, pr.damage * 0.45, 0.5, attacker, false);
        a.revealedTimer = Math.max(a.revealedTimer, 2.5);
      }
    }
  }

  private onCrateDestroyed(obs: MapObstacle): void {
    const cx = obs.x + obs.w * 0.5;
    const cy = obs.y + obs.h * 0.5;
    this.spawnBurst(cx, cy, '#d97706', 18, 210);
    audioEngine.playHit(true);
    // Drop guaranteed tactical armor or medkit where crate shattered!
    this.pickups.push({
      id: `crate_drop_${obs.id}_${Date.now()}`,
      kind: Math.random() < 0.55 ? 'armor' : 'medkit',
      x: cx,
      y: cy,
      active: true,
      respawnTimer: 0,
    });
  }

  private applyDamage(
    target: SimActor,
    rawAmount: number,
    armorPen: number,
    attacker: SimActor | null,
    heavy: boolean
  ): void {
    if (!target.alive || target.downed) return;
    let amount = rawAmount;
    if (target.vulnerableTimer > 0) amount *= 1.35;

    target.timeSinceDamaged = 0;
    target.hitFlashTimer = 0.06;

    // Split damage across armor and HP
    let hpDmg = amount * armorPen;
    let armorDmg = amount * (1 - armorPen);
    if (target.armor >= armorDmg) {
      target.armor -= armorDmg;
    } else {
      const overflow = armorDmg - target.armor;
      target.armor = 0;
      hpDmg += overflow;
    }

    target.hp -= hpDmg;

    if (attacker?.isPlayer) {
      this.playerDamage += amount;
      audioEngine.playHit(heavy);
    } else if (target.isPlayer && heavy) {
      audioEngine.playHit(true);
      this.shakeTrauma = Math.min(1, this.shakeTrauma + 0.34);
    }

    this.spawnBurst(target.x, target.y, target.armor > 0 ? '#60a5fa' : '#f87171', heavy ? 12 : 5, heavy ? 190 : 120);

    if (target.hp <= 0) {
      target.hp = 0;
      // In Team 3v3, if at least 1 standing teammate exists, enter Downed state for revive!
      const standingMate =
        this.mode === 'team3v3' &&
        this.actors.some((other) => other.team === target.team && other.id !== target.id && other.alive && !other.downed);

      if (standingMate) {
        target.downed = true;
        target.bleedoutTimer = 14;
        target.reviveProgress = 0;
        this.hitstopTimer = 0.035;
        this.pushKillFeed(
          `${target.name} tumbang — butuh kebangkitan skuad!`,
          target.team === 'A' ? 'enemy' : 'ally'
        );
      } else {
        this.finalizeElimination(target, attacker);
      }
    }
  }

  private finalizeElimination(target: SimActor, attacker: SimActor | null): void {
    target.alive = false;
    target.downed = false;
    target.koTimer = 0.42;
    this.spawnBurst(target.x, target.y, target.team === 'A' ? '#fbbf24' : '#ef4444', 24, 240);

    if (attacker?.isPlayer || target.isPlayer) {
      this.hitstopTimer = 0.055;
      this.shakeTrauma = Math.min(1, this.shakeTrauma + 0.48);
    }

    if (attacker) {
      if (attacker.isPlayer) {
        this.playerKills += 1;
      }
      // Kairo passive: speed boost + reload on kill
      if (attacker.heroId === 'kairo') {
        attacker.killBoostTimer = 2.6;
        if (attacker.passiveEvolved) {
          attacker.ammo = Math.min(attacker.maxAmmo, attacker.ammo + Math.ceil(attacker.maxAmmo * 0.4));
        }
      }
      this.pushKillFeed(
        `${attacker.name} mengeliminasi ${target.name}`,
        attacker.team === 'A' ? 'ally' : 'enemy'
      );
    } else {
      this.pushKillFeed(`${target.name} tumbang oleh arena`, 'system');
    }

    // If a team has no standing members left, any downed members immediately finalize
    if (this.mode === 'team3v3') {
      const teamStanding = this.actors.some((a) => a.team === target.team && a.alive && !a.downed);
      if (!teamStanding) {
        for (const m of this.actors) {
          if (m.team === target.team && m.alive && m.downed) {
            m.alive = false;
            m.downed = false;
            m.koTimer = 0.35;
          }
        }
      }
    }
  }

  private updatePickups(dt: number): void {
    for (const pk of this.pickups) {
      if (!pk.active) {
        pk.respawnTimer -= dt;
        if (pk.respawnTimer <= 0) pk.active = true;
        continue;
      }

      for (const a of this.actors) {
        if (!a.alive || a.downed) continue;
        if (dist(a, pk) <= a.radius + 16) {
          let consumed = false;
          if (pk.kind === 'medkit' && a.hp < a.maxHp) {
            a.hp = Math.min(a.maxHp, a.hp + Math.round(a.maxHp * 0.42));
            consumed = true;
          } else if (pk.kind === 'armor' && a.armor < a.maxArmor) {
            const mult = a.heroId === 'tala' ? 1.25 : 1.0;
            a.armor = Math.min(a.maxArmor, a.armor + Math.round(a.maxArmor * 0.55 * mult));
            consumed = true;
          } else if (pk.kind === 'ammo' && a.ammo < a.maxAmmo) {
            a.ammo = a.maxAmmo;
            a.reloading = false;
            consumed = true;
          } else if (pk.kind === 'visor') {
            a.visorBoostTimer = 12;
            consumed = true;
          }

          if (consumed) {
            pk.active = false;
            pk.respawnTimer = 22;
            this.spawnBurst(pk.x, pk.y, '#fbbf24', 10, 120);
            if (a.isPlayer) audioEngine.playPickup();
            // Tala Lv.2+ Passive: Team micro-heal on pickup
            if (a.heroId === 'tala' && a.passiveEvolved) {
              for (const mate of this.actors) {
                if (mate.team === a.team && mate.alive && !mate.downed) {
                  mate.hp = Math.min(mate.maxHp, mate.hp + 15);
                }
              }
            }
            break;
          }
        }
      }
    }
  }

  private updateCamera(dt: number): void {
    const player = this.getPlayer();
    if (!player) return;

    // Subtle look-ahead in aiming direction (Bullet Echo spatial feel!)
    const lookAheadX = Math.cos(player.angle) * 58;
    const lookAheadY = Math.sin(player.angle) * 58;
    const targetX = clamp(
      player.x + lookAheadX,
      Math.min(this.map.width * 0.5, this.viewW * 0.36),
      Math.max(this.map.width * 0.5, this.map.width - this.viewW * 0.36)
    );
    const targetY = clamp(
      player.y + lookAheadY,
      Math.min(this.map.height * 0.5, this.viewH * 0.36),
      Math.max(this.map.height * 0.5, this.map.height - this.viewH * 0.36)
    );

    const smooth = 1 - Math.exp(-8.5 * dt);
    this.camX += (targetX - this.camX) * smooth;
    this.camY += (targetY - this.camY) * smooth;
  }

  private updateAdaptiveSampling(dt: number): void {
    this.sampleTimer += dt;
    if (this.sampleTimer < 0.45) return;
    this.sampleTimer = 0;

    const player = this.getPlayer();
    if (!player || !player.alive || player.downed) return;

    const nearestEnemy = this.actors
      .filter((e) => e.team === 'B' && e.alive && !e.downed)
      .sort((a, b) => dist(player, a) - dist(player, b))[0];

    const nearCover = this.obstacles.some(
      (obs) =>
        (obs.kind === 'wall' || obs.kind === 'low_cover') &&
        circleIntersectsRect(player.x, player.y, player.radius + 36, obs)
    );
    const speed = Math.hypot(player.vx, player.vy);

    this.adaptiveMemory = recordPlayerMovementSample(this.adaptiveMemory, {
      mapId: this.map.id,
      mapWidth: this.map.width,
      mapHeight: this.map.height,
      playerPos: { x: player.x, y: player.y },
      playerVel: { x: player.vx, y: player.vy },
      nearestEnemyPos: nearestEnemy ? { x: nearestEnemy.x, y: nearestEnemy.y } : null,
      isMovingFast: speed > player.speed * 0.65,
      nearCover,
    });
    this.callbacks.onMemoryUpdate(this.adaptiveMemory);
  }

  private checkMatchOutcome(dt: number): void {
    if (this.pendingVictory !== null) {
      this.finishDelayTimer -= dt;
      if (this.finishDelayTimer <= 0) {
        const victory = this.pendingVictory;
        this.pendingVictory = null;
        this.completeMatch(victory);
      }
      return;
    }

    const teamAAlive = this.actors.some((a) => a.team === 'A' && a.alive);
    const teamBAlive = this.actors.some((a) => a.team === 'B' && a.alive);
    const player = this.getPlayer();

    if (!teamBAlive) {
      this.pendingVictory = true;
      this.finishDelayTimer = 0.55;
    } else if (!teamAAlive || (this.mode === 'solo' && player && !player.alive)) {
      this.pendingVictory = false;
      this.finishDelayTimer = 0.55;
    }
  }

  private completeMatch(victory: boolean): void {
    this.clearInputs();
    audioEngine.playOutcome(victory);

    const finalizedMemory: AdaptiveBotMemory = {
      ...this.adaptiveMemory,
      matchesAnalyzed: this.adaptiveMemory.matchesAnalyzed + 1,
    };
    this.adaptiveMemory = finalizedMemory;
    const insights = analyzeAdaptiveMemory(finalizedMemory);

    const summary: MatchSummary = {
      victory,
      mode: this.mode,
      mapId: this.map.id,
      heroId: this.profile.selectedHeroId,
      eliminations: this.playerKills,
      damageDealt: Math.round(this.playerDamage),
      revives: this.playerRevives,
      survivalSeconds: Math.round(this.matchTime),
      xpEarned: 0,
      scrapEarned: 0,
      leveledUp: false,
      previousLevel: this.profile.heroProgress[this.profile.selectedHeroId].level,
      newLevel: this.profile.heroProgress[this.profile.selectedHeroId].level,
      adaptationLevelBefore: this.startAdaptationLevel,
      adaptationLevelAfter: insights.adaptationLevel,
      botCounterNote: insights.counterTacticSummary,
    };

    this.setPhase('gameover');
    this.callbacks.onMatchEnd(summary, finalizedMemory);
    this.emitHud();
  }

  private spawnProjectile(p: Omit<Projectile, 'active'>): void {
    for (let i = 0; i < this.projectiles.length; i++) {
      if (!this.projectiles[i].active) {
        Object.assign(this.projectiles[i], p, { active: true });
        return;
      }
    }
  }

  private spawnBurst(x: number, y: number, color: string, count: number, maxSpeed: number): void {
    for (let i = 0; i < count; i++) {
      const pt = this.particles[this.particleCursor];
      this.particleCursor = (this.particleCursor + 1) % MAX_PARTICLES;
      const ang = Math.random() * Math.PI * 2;
      const spd = 25 + Math.random() * maxSpeed;
      pt.active = true;
      pt.x = x;
      pt.y = y;
      pt.vx = Math.cos(ang) * spd;
      pt.vy = Math.sin(ang) * spd;
      pt.size = 2 + Math.random() * 3.2;
      pt.maxLife = 0.22 + Math.random() * 0.28;
      pt.life = pt.maxLife;
      pt.color = color;
      pt.drag = 0.9;
    }
  }

  private spawnRipple(x: number, y: number, maxRadius: number, color: string): void {
    const r = this.ripples[this.rippleCursor];
    this.rippleCursor = (this.rippleCursor + 1) % MAX_RIPPLES;
    r.active = true;
    r.x = x;
    r.y = y;
    r.radius = 12;
    r.maxRadius = Math.max(40, maxRadius);
    r.alpha = 0.85;
    r.color = color;
  }

  private updateParticles(dt: number): void {
    for (let i = 0; i < this.particles.length; i++) {
      const pt = this.particles[i];
      if (!pt.active) continue;
      pt.life -= dt;
      if (pt.life <= 0) {
        pt.active = false;
        continue;
      }
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.vx *= Math.pow(pt.drag, dt * 60);
      pt.vy *= Math.pow(pt.drag, dt * 60);
    }
  }

  private updateRipples(dt: number): void {
    for (let i = 0; i < this.ripples.length; i++) {
      const r = this.ripples[i];
      if (!r.active) continue;
      r.radius += (r.maxRadius - r.radius) * Math.min(1, dt * 4.5) + dt * 55;
      r.alpha -= dt * 1.45;
      if (r.alpha <= 0.02 || r.radius >= r.maxRadius) {
        r.active = false;
      }
    }
  }

  private pushKillFeed(text: string, tone: 'ally' | 'enemy' | 'system'): void {
    const now = performance.now();
    this.killFeed = [
      ...this.killFeed.filter((k) => k.expiresAt > now).slice(-3),
      { id: this.killFeedSeq++, text, tone, expiresAt: now + 4500 },
    ];
  }

  private isActorVisibleToTeamA(target: SimActor): boolean {
    if (target.team === 'A') return true;
    if (this.thermalScanTimer > 0 || target.revealedTimer > 0) return true;

    const inBush = isPositionInBush(target, this.obstacles);
    const allies = this.actors.filter((a) => a.team === 'A' && a.alive);
    for (const ally of allies) {
      const visorBonus = ally.visorBoostTimer > 0 ? 1.2 : 1;
      const focusBonus = ally.heroId === 'laras' && ally.stillTimer >= 0.5 ? 1.18 : 1;
      const range = ally.visionRange * visorBonus * focusBonus;
      const effectiveRange = target.stealthTimer > 0 ? 75 : inBush ? 130 : range;
      if (
        isPointInVisionCone(
          ally,
          ally.angle,
          ally.visionArcRad,
          effectiveRange,
          92,
          target,
          this.obstacles
        )
      ) {
        return true;
      }
    }
    return false;
  }

  private emitHud(): void {
    const player = this.getPlayer();
    const insights = analyzeAdaptiveMemory(this.adaptiveMemory);
    const now = performance.now();
    this.killFeed = this.killFeed.filter((k) => k.expiresAt > now);

    const allies = this.actors.filter((a) => a.team === 'A');
    const enemies = this.actors.filter((a) => a.team === 'B');
    const weapon = HEROES[player?.heroId ?? this.profile.selectedHeroId].weapon;

    const snapshot: HudSnapshot = {
      phase: this.phase,
      mode: this.mode,
      mapId: this.map.id,
      playerHeroId: player?.heroId ?? this.profile.selectedHeroId,
      playerHp: Math.round(player?.hp ?? 0),
      playerMaxHp: Math.round(player?.maxHp ?? 100),
      playerArmor: Math.round(player?.armor ?? 0),
      playerMaxArmor: Math.round(player?.maxArmor ?? 50),
      ammo: player?.ammo ?? 0,
      maxAmmo: player?.maxAmmo ?? weapon.magSize,
      reloading: Boolean(player?.reloading),
      reloadProgress: player?.reloading ? clamp(1 - player.reloadTimer / weapon.reloadTime, 0, 1) : 1,
      activeCooldown: Number((player?.activeCooldown ?? 0).toFixed(1)),
      activeMaxCooldown: player?.activeMaxCooldown ?? 8,
      ultimateCooldown: Number((player?.ultimateCooldown ?? 0).toFixed(1)),
      ultimateMaxCooldown: player?.ultimateMaxCooldown ?? 16,
      activeDuration: Number((player?.activeDuration ?? 0).toFixed(1)),
      ultimateDuration: Number((player?.ultimateDuration ?? 0).toFixed(1)),
      autoFire: this.autoFire,
      squadCommand: this.squadCommand,
      alliesAlive: allies.filter((a) => a.alive).length,
      alliesTotal: allies.length,
      enemiesAlive: enemies.filter((e) => e.alive).length,
      enemiesTotal: enemies.length,
      matchTime: Math.round(this.matchTime),
      stormRadius: Math.round(this.stormRadius),
      stormMaxRadius: Math.round(this.stormMaxRadius),
      playerKills: this.playerKills,
      playerDamage: Math.round(this.playerDamage),
      playerRevives: this.playerRevives,
      playerDowned: Boolean(player?.downed),
      playerReviveProgress: player?.reviveProgress ?? 0,
      adaptationLevel: insights.adaptationLevel,
      adaptationSummary: insights.counterTacticSummary,
      actors: this.actors.map((a) => ({
        id: a.id,
        name: a.name,
        heroId: a.heroId,
        team: a.team,
        isPlayer: a.isPlayer,
        hp: Math.round(a.hp),
        maxHp: Math.round(a.maxHp),
        armor: Math.round(a.armor),
        maxArmor: Math.round(a.maxArmor),
        alive: a.alive,
        downed: a.downed,
        reviveProgress: a.reviveProgress,
        x: Math.round(a.x),
        y: Math.round(a.y),
        angle: a.angle,
        visibleToPlayer: this.isActorVisibleToTeamA(a),
        roleLabel: HEROES[a.heroId].role,
      })),
      killFeed: [...this.killFeed],
      radioCallout: this.radioCallout,
    };

    this.callbacks.onHudUpdate(snapshot);
  }

  // ===== Canvas 2D Bird's-Eye Rendering =====
  private render(): void {
    const ctx = this.ctx;
    const w = this.viewW;
    const h = this.viewH;

    const shakeMag = this.shakeTrauma * this.shakeTrauma * 11;
    const shakeX = shakeMag > 0.1 ? (Math.random() - 0.5) * 2 * shakeMag : 0;
    const shakeY = shakeMag > 0.1 ? (Math.random() - 0.5) * 2 * shakeMag : 0;

    const offsetX = Math.round(w * 0.5 - this.camX + shakeX);
    const offsetY = Math.round(h * 0.5 - this.camY + shakeY);

    ctx.fillStyle = '#070b10';
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    ctx.translate(offsetX, offsetY);

    this.renderFloor(ctx);
    this.renderZones(ctx);
    this.renderPickups(ctx);
    this.renderObstacles(ctx, 'floor');
    this.renderTurrets(ctx);
    this.renderActors(ctx, false); // Actors visible inside vision cones
    this.renderProjectiles(ctx);
    this.renderParticles(ctx);
    this.renderObstacles(ctx, 'walls');
    this.renderStormRing(ctx);

    ctx.restore();

    // Dynamic Bullet Echo Ray-Casted Vision Darkness Mask!
    this.renderDynamicLighting(offsetX, offsetY);

    // Post-darkness diegetic layer (sound ripples, thermal/bio wallhack silhouettes, telegraphs, aiming reticle)
    ctx.save();
    ctx.translate(offsetX, offsetY);
    this.renderRipples(ctx);
    this.renderPostDarknessOverlays(ctx);
    ctx.restore();
  }

  private renderFloor(ctx: CanvasRenderingContext2D): void {
    const pal = this.map.palette;
    ctx.fillStyle = pal.floorBase;
    ctx.fillRect(0, 0, this.map.width, this.map.height);

    // Architectural tactical floor tiles
    const tile = 64;
    ctx.strokeStyle = pal.floorGrid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 0; x <= this.map.width; x += tile) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.map.height);
    }
    for (let y = 0; y <= this.map.height; y += tile) {
      ctx.moveTo(0, y);
      ctx.lineTo(this.map.width, y);
    }
    ctx.stroke();

    // Subtle center sector tactical markings
    ctx.strokeStyle = pal.floorAccent;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(this.map.width * 0.5, this.map.height * 0.5, 118, 0, Math.PI * 2);
    ctx.stroke();

    ctx.setLineDash([10, 10]);
    ctx.beginPath();
    ctx.moveTo(this.map.width * 0.5, 40);
    ctx.lineTo(this.map.width * 0.5, this.map.height - 40);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  private renderObstacles(ctx: CanvasRenderingContext2D, layer: 'floor' | 'walls'): void {
    const pal = this.map.palette;
    const hazardWarn = this.hazardPulseTimer >= 2.7 && this.hazardPulseTimer < 3.4;
    const hazardZap = this.hazardPulseTimer >= 3.4;

    for (const obs of this.obstacles) {
      if (layer === 'floor') {
        if (obs.kind === 'bush') {
          ctx.fillStyle = pal.bushFill;
          ctx.beginPath();
          ctx.roundRect(obs.x, obs.y, obs.w, obs.h, 14);
          ctx.fill();
          ctx.strokeStyle = 'rgba(52, 211, 153, 0.25)';
          ctx.lineWidth = 1.5;
          ctx.stroke();
          // Stylized foliage blades
          ctx.fillStyle = 'rgba(74, 222, 128, 0.16)';
          for (let bx = obs.x + 16; bx < obs.x + obs.w - 10; bx += 26) {
            for (let by = obs.y + 16; by < obs.y + obs.h - 10; by += 26) {
              ctx.beginPath();
              ctx.arc(bx, by, 10, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        } else if (obs.kind === 'hazard') {
          ctx.fillStyle = hazardZap
            ? 'rgba(239, 68, 68, 0.45)'
            : hazardWarn
              ? 'rgba(245, 158, 11, 0.28)'
              : 'rgba(30, 41, 59, 0.7)';
          ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
          ctx.strokeStyle = hazardZap ? '#ef4444' : hazardWarn ? '#f59e0b' : 'rgba(245, 158, 11, 0.35)';
          ctx.lineWidth = hazardZap ? 2.5 : 1.5;
          ctx.strokeRect(obs.x + 2, obs.y + 2, obs.w - 4, obs.h - 4);
          // Caution diagonal hatch
          ctx.strokeStyle = hazardZap ? 'rgba(254, 202, 202, 0.7)' : 'rgba(245, 158, 11, 0.35)';
          ctx.beginPath();
          ctx.moveTo(obs.x + 8, obs.y + obs.h - 8);
          ctx.lineTo(obs.x + obs.w - 8, obs.y + 8);
          ctx.moveTo(obs.x + 8, obs.y + 8);
          ctx.lineTo(obs.x + obs.w - 8, obs.y + obs.h - 8);
          ctx.stroke();
        } else if (obs.kind === 'low_cover') {
          // Drop shadow
          ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
          ctx.fillRect(obs.x + 4, obs.y + 5, obs.w, obs.h);
          ctx.fillStyle = pal.coverFill;
          ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
          ctx.strokeStyle = 'rgba(226, 232, 240, 0.28)';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(obs.x + 0.5, obs.y + 0.5, obs.w - 1, obs.h - 1);
          // Sandbag / tactical rib detail
          ctx.fillStyle = 'rgba(255,255,255,0.08)';
          ctx.fillRect(obs.x + 4, obs.y + 4, obs.w - 8, 5);
        }
      } else {
        if (obs.kind === 'wall') {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.52)';
          ctx.fillRect(obs.x + 6, obs.y + 7, obs.w, obs.h);
          ctx.fillStyle = pal.wallTop;
          ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
          ctx.strokeStyle = pal.wallBorder;
          ctx.lineWidth = 2;
          ctx.strokeRect(obs.x + 1, obs.y + 1, obs.w - 2, obs.h - 2);
          // Top bevel highlight
          ctx.fillStyle = 'rgba(255, 255, 255, 0.055)';
          ctx.fillRect(obs.x + 3, obs.y + 3, obs.w - 6, Math.min(10, obs.h * 0.25));
        } else if (obs.kind === 'crate' && (obs.hp ?? 0) > 0) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
          ctx.fillRect(obs.x + 4, obs.y + 5, obs.w, obs.h);
          ctx.fillStyle = pal.crateFill;
          ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
          ctx.strokeStyle = '#b47b44';
          ctx.lineWidth = 2;
          ctx.strokeRect(obs.x + 1, obs.y + 1, obs.w - 2, obs.h - 2);
          // Cross timber slats
          ctx.strokeStyle = 'rgba(30, 18, 8, 0.6)';
          ctx.beginPath();
          ctx.moveTo(obs.x + 5, obs.y + 5);
          ctx.lineTo(obs.x + obs.w - 5, obs.y + obs.h - 5);
          ctx.moveTo(obs.x + obs.w - 5, obs.y + 5);
          ctx.lineTo(obs.x + 5, obs.y + obs.h - 5);
          ctx.stroke();

          // Damage crack bar if damaged
          if (obs.maxHp && obs.hp! < obs.maxHp) {
            const frac = clamp(obs.hp! / obs.maxHp, 0, 1);
            ctx.fillStyle = 'rgba(10,14,20,0.8)';
            ctx.fillRect(obs.x + 6, obs.y - 8, obs.w - 12, 4);
            ctx.fillStyle = '#f59e0b';
            ctx.fillRect(obs.x + 6, obs.y - 8, (obs.w - 12) * frac, 4);
          }
        }
      }
    }
  }

  private renderPickups(ctx: CanvasRenderingContext2D): void {
    const pulse = 0.85 + Math.sin(this.matchTime * 4) * 0.15;
    for (const pk of this.pickups) {
      if (!pk.active) continue;
      ctx.save();
      ctx.translate(pk.x, pk.y);
      ctx.scale(pulse, pulse);

      const color =
        pk.kind === 'medkit'
          ? '#10b981'
          : pk.kind === 'armor'
            ? '#3b82f6'
            : pk.kind === 'ammo'
              ? '#f59e0b'
              : '#eab308';

      ctx.fillStyle = 'rgba(11, 16, 23, 0.9)';
      ctx.beginPath();
      ctx.arc(0, 0, 13, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = color;
      if (pk.kind === 'medkit') {
        ctx.fillRect(-6, -2, 12, 4);
        ctx.fillRect(-2, -6, 4, 12);
      } else if (pk.kind === 'armor') {
        ctx.beginPath();
        ctx.moveTo(0, -7);
        ctx.lineTo(6, -3);
        ctx.lineTo(4, 5);
        ctx.lineTo(0, 7);
        ctx.lineTo(-4, 5);
        ctx.lineTo(-6, -3);
        ctx.closePath();
        ctx.fill();
      } else if (pk.kind === 'ammo') {
        ctx.fillRect(-5, -5, 3, 10);
        ctx.fillRect(-1, -5, 3, 10);
        ctx.fillRect(3, -5, 3, 10);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  private renderZones(ctx: CanvasRenderingContext2D): void {
    for (const z of this.zones) {
      ctx.save();
      const alpha = clamp(z.ttl / z.maxTtl, 0.2, 1);
      if (z.kind === 'spore') {
        const grad = ctx.createRadialGradient(z.x, z.y, 10, z.x, z.y, z.radius);
        grad.addColorStop(0, `rgba(16, 185, 129, ${0.34 * alpha})`);
        grad.addColorStop(0.75, `rgba(132, 204, 22, ${0.18 * alpha})`);
        grad.addColorStop(1, 'rgba(16, 185, 129, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(z.x, z.y, z.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = `rgba(52, 211, 153, ${0.55 * alpha})`;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([6, 6]);
        ctx.stroke();
      } else if (z.kind === 'heal') {
        const grad = ctx.createRadialGradient(z.x, z.y, 12, z.x, z.y, z.radius);
        grad.addColorStop(0, `rgba(45, 212, 191, ${0.28 * alpha})`);
        grad.addColorStop(1, 'rgba(45, 212, 191, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(z.x, z.y, z.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = `rgba(94, 234, 212, ${0.6 * alpha})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  private renderTurrets(ctx: CanvasRenderingContext2D): void {
    for (const t of this.turrets) {
      ctx.save();
      ctx.translate(t.x, t.y);
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      ctx.beginPath();
      ctx.arc(2, 3, 14, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#1e293b';
      ctx.strokeStyle = t.team === 'A' ? '#14b8a6' : '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.rotate(t.angle);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(0, -3, 17, 6);
      ctx.fillStyle = t.team === 'A' ? '#5eead4' : '#f87171';
      ctx.beginPath();
      ctx.arc(0, 0, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderActors(ctx: CanvasRenderingContext2D, revealedOverlayOnly: boolean): void {
    for (const a of this.actors) {
      if (!a.alive && a.koTimer <= 0) continue;

      const isVisible = this.phase === 'title' ? true : this.isActorVisibleToTeamA(a);
      if (revealedOverlayOnly) {
        // Draw enemies revealed through walls (thermal scan or bio-mark) on top of darkness
        if (a.team === 'B' && a.alive && (this.thermalScanTimer > 0 || a.revealedTimer > 0)) {
          ctx.save();
          ctx.translate(a.x, a.y);
          ctx.strokeStyle = a.vulnerableTimer > 0 ? '#34d399' : '#fde047';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(0, 0, a.radius + 6, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = a.vulnerableTimer > 0 ? 'rgba(52, 211, 153, 0.22)' : 'rgba(253, 224, 71, 0.18)';
          ctx.fill();
          ctx.restore();
        }
        continue;
      }

      if (!isVisible && a.alive) continue;

      ctx.save();
      ctx.translate(a.x, a.y);

      // KO dissolve transition
      if (!a.alive) {
        const t = clamp(a.koTimer / 0.42, 0, 1);
        ctx.globalAlpha = t;
        ctx.scale(1 + (1 - t) * 0.25, 1 + (1 - t) * 0.25);
      } else if (a.stealthTimer > 0) {
        ctx.globalAlpha = a.team === 'A' ? 0.42 : 0.15;
      }

      // Ground shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.beginPath();
      ctx.ellipse(2, 4, a.radius * 1.05, a.radius * 0.85, 0, 0, Math.PI * 2);
      ctx.fill();

      // Team ring
      ctx.strokeStyle = a.isPlayer
        ? '#f59e0b'
        : a.team === 'A'
          ? '#10b981'
          : '#ef4444';
      ctx.lineWidth = a.isPlayer ? 2.4 : 1.8;
      ctx.beginPath();
      ctx.arc(0, 0, a.radius + 4, 0, Math.PI * 2);
      ctx.stroke();

      // Downed bleedout / revive ring
      if (a.downed) {
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, a.radius + 10, -Math.PI * 0.5, -Math.PI * 0.5 + Math.PI * 2 * Math.max(0.05, a.reviveProgress));
        ctx.stroke();
      }

      // Rotate to hero facing angle and draw BESPOKE freestyle silhouette!
      ctx.save();
      ctx.rotate(a.angle);
      const bob = Math.sin(a.walkPhase) * 1.6;
      this.drawUniqueHeroSilhouette(ctx, a, bob);
      ctx.restore();

      // Overhead compact HP + Armor bar & Callsign (only in gameplay)
      if (this.phase !== 'title' && a.alive) {
        const bw = 38;
        const bx = -bw * 0.5;
        const by = -a.radius - 16;
        ctx.fillStyle = 'rgba(8, 12, 18, 0.85)';
        ctx.fillRect(bx - 1, by - 1, bw + 2, 9);
        // HP bar
        ctx.fillStyle = a.team === 'A' ? '#10b981' : '#ef4444';
        ctx.fillRect(bx, by, bw * clamp(a.hp / a.maxHp, 0, 1), 4);
        // Armor bar
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(bx, by + 5, bw * clamp(a.armor / Math.max(1, a.maxArmor), 0, 1), 2.5);

        if (!a.isPlayer) {
          ctx.font = '600 10px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillStyle = a.downed ? '#fbbf24' : a.team === 'A' ? '#a7f3d0' : '#fecaca';
          ctx.fillText(a.downed ? 'BANGKITKAN!' : a.name, 0, by - 5);
        }
      }

      ctx.restore();
    }
  }

  private drawUniqueHeroSilhouette(ctx: CanvasRenderingContext2D, a: SimActor, bob: number): void {
    const flash = a.hitFlashTimer > 0;
    const hero = HEROES[a.heroId];

    if (a.heroId === 'kairo') {
      // Flowing obsidian cloak cape behind
      ctx.fillStyle = flash ? '#ffffff' : '#1e293b';
      ctx.beginPath();
      ctx.moveTo(-4, -14);
      ctx.lineTo(-22 - Math.abs(bob), -8 + bob);
      ctx.lineTo(-24, 0);
      ctx.lineTo(-22 - Math.abs(bob), 8 - bob);
      ctx.lineTo(-4, 14);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#b45309';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Rotating brass clock gear halo
      ctx.save();
      ctx.rotate(this.matchTime * 2.2);
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.65)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.arc(0, 0, a.radius + 1, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      // Twin silenced needle pistols
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(6, -11, 18, 3.2);
      ctx.fillRect(6, 7.8, 18, 3.2);
      // Hooded head & glowing amber chronometer eye
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.beginPath();
      ctx.arc(0, 0, 11.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(5, -3.5, 3, 0, Math.PI * 2);
      ctx.fill();
    } else if (a.heroId === 'bima') {
      // Hexagonal heavy salvaged crimson & copper mech chassis
      ctx.fillStyle = flash ? '#ffffff' : '#991b1b';
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const ang = (Math.PI / 3) * i + Math.PI / 6;
        const px = Math.cos(ang) * 20;
        const py = Math.sin(ang) * 20;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 2.4;
      ctx.stroke();

      // Twin shoulder floodlights
      ctx.fillStyle = '#fde68a';
      ctx.fillRect(4, -17, 6, 5);
      ctx.fillRect(4, 12, 6, 5);

      // Heavy rotary rivet cannon
      ctx.fillStyle = '#475569';
      ctx.fillRect(8, -5, 22, 10);
      ctx.fillStyle = '#f97316';
      ctx.fillRect(24, -4, 5, 8);

      // Furnace visor slit
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(3, -5, 5, 10);

      // Active Aegis Energy Shield arc!
      if (a.activeDuration > 0) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, a.radius + 11, -1.2, 1.2);
        ctx.stroke();
      }
    } else if (a.heroId === 'laras') {
      // Flowing indigo-gold batik shawl
      ctx.fillStyle = flash ? '#ffffff' : '#312e81';
      ctx.beginPath();
      ctx.ellipse(-2, 0, 14, 16, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Long ornate bamboo-alloy rail rifle
      ctx.fillStyle = '#475569';
      ctx.fillRect(4, -2.5, 30, 5);
      ctx.fillStyle = a.pierceShotReady ? '#fef08a' : '#eab308';
      ctx.fillRect(10, -1, 20, 2);

      // Head
      ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
      ctx.beginPath();
      ctx.arc(0, 0, 9.5, 0, Math.PI * 2);
      ctx.fill();

      // Orbiting Golden Spirit Lantern!
      const lx = -12 + Math.cos(this.matchTime * 2.6) * 3;
      const ly = -16 + Math.sin(this.matchTime * 2.6) * 3;
      ctx.fillStyle = 'rgba(253, 224, 71, 0.35)';
      ctx.beginPath();
      ctx.arc(lx, ly, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(lx, ly, 4, 0, Math.PI * 2);
      ctx.fill();
    } else if (a.heroId === 'tala') {
      // Teal asymmetrical poncho
      ctx.fillStyle = flash ? '#ffffff' : '#0f766e';
      ctx.beginPath();
      ctx.roundRect(-14, -14, 24, 28, 8);
      ctx.fill();
      ctx.strokeStyle = '#5eead4';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      // Chunky scatter shotgun
      ctx.fillStyle = '#334155';
      ctx.fillRect(6, -4.5, 20, 9);
      ctx.fillStyle = '#f97316';
      ctx.fillRect(12, -3, 7, 6);

      // Fox-eared scrap visor silhouette
      ctx.fillStyle = flash ? '#ffffff' : '#334155';
      ctx.beginPath();
      ctx.arc(0, 0, 10, 0, Math.PI * 2);
      ctx.fill();
      // Fox ears
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.moveTo(-2, -9);
      ctx.lineTo(-10, -16);
      ctx.lineTo(4, -10);
      ctx.moveTo(-2, 9);
      ctx.lineTo(-10, 16);
      ctx.lineTo(4, 10);
      ctx.fill();

      // Hovering tiny repair drone!
      const dx = -13 + Math.sin(this.matchTime * 3.5) * 2.5;
      const dy = 16 + Math.cos(this.matchTime * 3.5) * 2.5;
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.arc(dx, dy, 5.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(dx + 1, dy, 2.5, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Dr. Vexa: Wide-brimmed botanical hat + bioluminescent spore backpack + vial launcher
      ctx.fillStyle = '#10b981';
      ctx.fillRect(-17, -7, 8, 14); // Glowing spore backpack

      // Vial launcher
      ctx.fillStyle = '#334155';
      ctx.fillRect(6, -4, 20, 8);
      ctx.fillStyle = '#34d399';
      ctx.fillRect(16, -2.5, 8, 5);

      // Wide botanical hat brim
      ctx.fillStyle = flash ? '#ffffff' : '#292524';
      ctx.beginPath();
      ctx.ellipse(0, 0, 14, 16, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      // Glowing bioluminescent mushroom spots on hat
      ctx.fillStyle = '#4ade80';
      ctx.beginPath();
      ctx.arc(-4, -7, 2.8, 0, Math.PI * 2);
      ctx.arc(-6, 5, 2.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = hero.accentColor;
      ctx.beginPath();
      ctx.arc(5, 0, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Enemy Vanguard ballistic shield visual
    if (!a.isPlayer && a.archetype === 'vanguard' && a.heroId !== 'bima') {
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.arc(0, 0, a.radius + 7, -0.95, 0.95);
      ctx.stroke();
    }
  }

  private renderProjectiles(ctx: CanvasRenderingContext2D): void {
    for (let i = 0; i < this.projectiles.length; i++) {
      const pr = this.projectiles[i];
      if (!pr.active) continue;
      const spd = Math.hypot(pr.vx, pr.vy) || 1;
      const tailLen = pr.heroId === 'laras' ? 28 : 14;
      const tx = pr.x - (pr.vx / spd) * tailLen;
      const ty = pr.y - (pr.vy / spd) * tailLen;

      ctx.strokeStyle = pr.color;
      ctx.lineWidth = pr.radius * 1.4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(pr.x, pr.y);
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, pr.radius * 0.7, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private renderParticles(ctx: CanvasRenderingContext2D): void {
    for (let i = 0; i < this.particles.length; i++) {
      const pt = this.particles[i];
      if (!pt.active) continue;
      ctx.globalAlpha = clamp(pt.life / pt.maxLife, 0, 1);
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  private renderRipples(ctx: CanvasRenderingContext2D): void {
    for (let i = 0; i < this.ripples.length; i++) {
      const r = this.ripples[i];
      if (!r.active) continue;
      ctx.save();
      ctx.globalAlpha = clamp(r.alpha, 0, 1);
      ctx.strokeStyle = r.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  private renderStormRing(ctx: CanvasRenderingContext2D): void {
    if (this.phase === 'title') return;
    const cx = this.map.width * 0.5;
    const cy = this.map.height * 0.5;

    ctx.save();
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.72)';
    ctx.lineWidth = 3;
    ctx.setLineDash([12, 8]);
    ctx.beginPath();
    ctx.arc(cx, cy, this.stormRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }

  private renderDynamicLighting(offsetX: number, offsetY: number): void {
    const vctx = this.visionCtx;
    const vw = this.visionCanvas.width;
    const vh = this.visionCanvas.height;
    const s = this.visionScale;

    vctx.setTransform(1, 0, 0, 1, 0, 0);
    vctx.globalCompositeOperation = 'source-over';
    vctx.clearRect(0, 0, vw, vh);
    vctx.fillStyle = this.map.palette.ambientTint;
    vctx.fillRect(0, 0, vw, vh);

    // Choose light emitters: in title tour all actors emit beams; in gameplay Team A shares flashlight vision!
    const emitters =
      this.phase === 'title'
        ? this.actors.filter((a) => a.alive)
        : this.actors.filter((a) => a.team === 'A' && a.alive);

    // Compute each emitter's raycast vision polygon ONCE per frame
    const cachedCones = emitters.map((a) => {
      const visorBonus = a.visorBoostTimer > 0 ? 1.2 : 1;
      const focusBonus = a.heroId === 'laras' && a.stillTimer >= 0.5 ? 1.18 : 1;
      const range = a.visionRange * visorBonus * focusBonus;
      const poly = buildVisionConePolygon(a, a.angle, a.visionArcRad, range, this.obstacles, 28);
      return { actor: a, range, poly };
    });

    vctx.save();
    vctx.scale(s, s);
    vctx.translate(offsetX, offsetY);

    // Carve out raycasted vision cones and ambient circles
    vctx.globalCompositeOperation = 'destination-out';
    for (const { actor: a, range, poly } of cachedCones) {
      // Close ambient aura
      const ambGrad = vctx.createRadialGradient(a.x, a.y, 18, a.x, a.y, 98);
      ambGrad.addColorStop(0, 'rgba(0,0,0,1)');
      ambGrad.addColorStop(1, 'rgba(0,0,0,0)');
      vctx.fillStyle = ambGrad;
      vctx.beginPath();
      vctx.arc(a.x, a.y, 98, 0, Math.PI * 2);
      vctx.fill();

      // Ray-casted flashlight vision polygon
      const coneGrad = vctx.createRadialGradient(a.x, a.y, 16, a.x, a.y, range);
      coneGrad.addColorStop(0, 'rgba(0,0,0,0.98)');
      coneGrad.addColorStop(0.75, 'rgba(0,0,0,0.88)');
      coneGrad.addColorStop(1, 'rgba(0,0,0,0)');
      vctx.fillStyle = coneGrad;
      vctx.beginPath();
      vctx.moveTo(poly[0].x, poly[0].y);
      for (let i = 1; i < poly.length; i++) {
        vctx.lineTo(poly[i].x, poly[i].y);
      }
      vctx.closePath();
      vctx.fill();
    }

    vctx.restore();

    // Composite downscaled darkness mask smoothly onto main canvas
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.drawImage(this.visionCanvas, 0, 0, this.viewW, this.viewH);

    // Paint subtle warm tungsten flashlight beam tint reusing cached polygons
    this.ctx.save();
    this.ctx.translate(offsetX, offsetY);
    for (const { actor: a, range, poly } of cachedCones) {
      const beam = this.ctx.createRadialGradient(a.x, a.y, 10, a.x, a.y, range);
      const tint = a.isPlayer ? '251, 191, 36' : '148, 163, 184';
      beam.addColorStop(0, `rgba(${tint}, 0.14)`);
      beam.addColorStop(0.7, `rgba(${tint}, 0.05)`);
      beam.addColorStop(1, `rgba(${tint}, 0)`);
      this.ctx.fillStyle = beam;
      this.ctx.beginPath();
      this.ctx.moveTo(poly[0].x, poly[0].y);
      for (let i = 1; i < poly.length; i++) {
        this.ctx.lineTo(poly[i].x, poly[i].y);
      }
      this.ctx.closePath();
      this.ctx.fill();
    }
    this.ctx.restore();
  }

  private renderPostDarknessOverlays(ctx: CanvasRenderingContext2D): void {
    // 1. Thermal / Bio-marked enemies visible through darkness & walls
    this.renderActors(ctx, true);

    // 2. Enemy Attack Telegraphs (Marksman Laser Sight & Breacher Blast Ring)
    for (const a of this.actors) {
      if (!a.alive || a.aiTelegraphTimer <= 0) continue;
      const progress = clamp(1 - a.aiTelegraphTimer / a.aiTelegraphMax, 0, 1);

      if (a.aiTelegraphKind === 'sniper') {
        const dx = Math.cos(a.angle);
        const dy = Math.sin(a.angle);
        let maxD = 500;
        for (const obs of this.obstacles) {
          if (obs.kind !== 'wall') continue;
          const hit = rayIntersectRect(a.x, a.y, dx, dy, maxD, obs);
          if (hit !== null && hit < maxD) maxD = hit;
        }
        ctx.save();
        ctx.strokeStyle = `rgba(239, 68, 68, ${0.45 + progress * 0.55})`;
        ctx.lineWidth = 1.5 + progress * 1.5;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(a.x + dx * maxD, a.y + dy * maxD);
        ctx.stroke();
        ctx.restore();
      } else if (a.aiTelegraphKind === 'breach' && a.aiTelegraphTarget) {
        const tx = a.aiTelegraphTarget.x;
        const ty = a.aiTelegraphTarget.y;
        ctx.save();
        ctx.fillStyle = `rgba(239, 68, 68, ${0.12 + progress * 0.2})`;
        ctx.beginPath();
        ctx.arc(tx, ty, 78, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#f97316';
        ctx.lineWidth = 2.5;
        ctx.stroke();
        // Expanding inner detonation progress ring
        ctx.beginPath();
        ctx.arc(tx, ty, 78 * progress, 0, Math.PI * 2);
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
      }
    }

    // 3. Player Aim Reticle & Weapon Range Arc (in 'playing')
    if (this.phase === 'playing') {
      const p = this.getPlayer();
      if (p && p.alive && !p.downed) {
        const mw = this.screenToWorld(this.mouseScreen.x, this.mouseScreen.y);
        ctx.save();
        ctx.translate(mw.x, mw.y);
        ctx.strokeStyle = p.reloading ? '#94a3b8' : '#fbbf24';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.arc(0, 0, 11, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-16, 0);
        ctx.lineTo(-7, 0);
        ctx.moveTo(7, 0);
        ctx.lineTo(16, 0);
        ctx.moveTo(0, -16);
        ctx.lineTo(0, -7);
        ctx.moveTo(0, 7);
        ctx.lineTo(0, 16);
        ctx.stroke();
        ctx.restore();
      }
    }
  }
}
