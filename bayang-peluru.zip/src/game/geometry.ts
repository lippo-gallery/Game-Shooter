import { MapObstacle, Rect, Vec2 } from './types';

export function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function normalizeAngle(angle: number): number {
  let a = angle;
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

export function angleDiff(from: number, to: number): number {
  return normalizeAngle(to - from);
}

export function dist(a: Vec2, b: Vec2): number {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

export function pointInRect(x: number, y: number, r: Rect): boolean {
  return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
}

export function circleIntersectsRect(cx: number, cy: number, radius: number, r: Rect): boolean {
  const closestX = clamp(cx, r.x, r.x + r.w);
  const closestY = clamp(cy, r.y, r.y + r.h);
  const dx = cx - closestX;
  const dy = cy - closestY;
  return dx * dx + dy * dy < radius * radius;
}

export function resolveCircleRects(
  x: number,
  y: number,
  radius: number,
  obstacles: MapObstacle[]
): Vec2 {
  let rx = x;
  let ry = y;

  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < obstacles.length; i++) {
      const obs = obstacles[i];
      if (obs.kind === 'bush' || obs.kind === 'hazard') continue;
      if (obs.kind === 'crate' && (obs.hp ?? 0) <= 0) continue;

      const closestX = clamp(rx, obs.x, obs.x + obs.w);
      const closestY = clamp(ry, obs.y, obs.y + obs.h);
      const dx = rx - closestX;
      const dy = ry - closestY;
      const distSq = dx * dx + dy * dy;

      if (distSq < radius * radius) {
        if (distSq > 0.0001) {
          const d = Math.sqrt(distSq);
          const overlap = radius - d;
          rx += (dx / d) * overlap;
          ry += (dy / d) * overlap;
        } else {
          // Circle center inside rect: push out along shortest axis
          const leftPen = rx - obs.x;
          const rightPen = obs.x + obs.w - rx;
          const topPen = ry - obs.y;
          const bottomPen = obs.y + obs.h - ry;
          const minPen = Math.min(leftPen, rightPen, topPen, bottomPen);
          if (minPen === leftPen) rx = obs.x - radius;
          else if (minPen === rightPen) rx = obs.x + obs.w + radius;
          else if (minPen === topPen) ry = obs.y - radius;
          else ry = obs.y + obs.h + radius;
        }
      }
    }
  }

  return { x: rx, y: ry };
}

/**
 * Ray-AABB intersection returning distance t along normalized ray (dx, dy),
 * or null if no hit within maxDist.
 */
export function rayIntersectRect(
  ox: number,
  oy: number,
  dx: number,
  dy: number,
  maxDist: number,
  r: Rect
): number | null {
  const invX = Math.abs(dx) > 1e-8 ? 1 / dx : Infinity;
  const invY = Math.abs(dy) > 1e-8 ? 1 / dy : Infinity;

  let t1 = (r.x - ox) * invX;
  let t2 = (r.x + r.w - ox) * invX;
  let tmin = Math.min(t1, t2);
  let tmax = Math.max(t1, t2);

  let t3 = (r.y - oy) * invY;
  let t4 = (r.y + r.h - oy) * invY;
  tmin = Math.max(tmin, Math.min(t3, t4));
  tmax = Math.min(tmax, Math.max(t3, t4));

  if (tmax < 0 || tmin > tmax) return null;
  const t = tmin >= 0 ? tmin : tmax;
  if (t < 0 || t > maxDist) return null;
  return t;
}

export function castVisionRay(
  ox: number,
  oy: number,
  angle: number,
  maxDist: number,
  obstacles: MapObstacle[]
): Vec2 {
  const dx = Math.cos(angle);
  const dy = Math.sin(angle);
  let bestT = maxDist;

  for (let i = 0; i < obstacles.length; i++) {
    const obs = obstacles[i];
    if (obs.kind !== 'wall' && !(obs.kind === 'crate' && (obs.hp ?? 0) > 0)) {
      continue;
    }
    const hit = rayIntersectRect(ox, oy, dx, dy, bestT, obs);
    if (hit !== null && hit < bestT) {
      bestT = hit;
    }
  }

  return { x: ox + dx * bestT, y: oy + dy * bestT };
}

export function hasLineOfSight(
  from: Vec2,
  to: Vec2,
  obstacles: MapObstacle[],
  blockOnLowCover = false
): boolean {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const totalDist = Math.hypot(dx, dy);
  if (totalDist < 1) return true;
  const nx = dx / totalDist;
  const ny = dy / totalDist;

  for (let i = 0; i < obstacles.length; i++) {
    const obs = obstacles[i];
    const blocks =
      obs.kind === 'wall' ||
      (obs.kind === 'crate' && (obs.hp ?? 0) > 0) ||
      (blockOnLowCover && obs.kind === 'low_cover');
    if (!blocks) continue;
    const hit = rayIntersectRect(from.x, from.y, nx, ny, totalDist - 2, obs);
    if (hit !== null) return false;
  }
  return true;
}

export function buildVisionConePolygon(
  origin: Vec2,
  facingAngle: number,
  arcRad: number,
  range: number,
  obstacles: MapObstacle[],
  steps = 36
): Vec2[] {
  const pts: Vec2[] = [{ x: origin.x, y: origin.y }];
  const start = facingAngle - arcRad * 0.5;
  for (let i = 0; i <= steps; i++) {
    const a = start + (arcRad * i) / steps;
    pts.push(castVisionRay(origin.x, origin.y, a, range, obstacles));
  }
  return pts;
}

export function isPointInVisionCone(
  observer: Vec2,
  facingAngle: number,
  arcRad: number,
  range: number,
  ambientRadius: number,
  target: Vec2,
  obstacles: MapObstacle[]
): boolean {
  const d = dist(observer, target);
  if (d > range) return false;
  if (d <= ambientRadius) {
    return hasLineOfSight(observer, target, obstacles, false);
  }
  const toTarget = Math.atan2(target.y - observer.y, target.x - observer.x);
  if (Math.abs(angleDiff(facingAngle, toTarget)) > arcRad * 0.52) {
    return false;
  }
  return hasLineOfSight(observer, target, obstacles, false);
}

export function isPositionInBush(pos: Vec2, obstacles: MapObstacle[]): boolean {
  for (let i = 0; i < obstacles.length; i++) {
    if (obstacles[i].kind === 'bush' && pointInRect(pos.x, pos.y, obstacles[i])) {
      return true;
    }
  }
  return false;
}
