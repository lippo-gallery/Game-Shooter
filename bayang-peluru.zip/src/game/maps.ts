import { MapDefinition, MapId, MapObstacle } from './types';

function makePerimeterWalls(w: number, h: number, t = 28): MapObstacle[] {
  return [
    { id: 'bound_top', kind: 'wall', x: 0, y: 0, w, h: t },
    { id: 'bound_bottom', kind: 'wall', x: 0, y: h - t, w, h: t },
    { id: 'bound_left', kind: 'wall', x: 0, y: t, w: t, h: h - t * 2 },
    { id: 'bound_right', kind: 'wall', x: w - t, y: t, w: t, h: h - t * 2 },
  ];
}

export const MAPS: Record<MapId, MapDefinition> = {
  cargo_docks: {
    id: 'cargo_docks',
    name: 'Pelabuhan Kargo',
    subtitle: 'Dermaga Kontainer Malam',
    description: 'Jajaran kontainer baja menciptakan lorong penyergapan sempit, sementara barikade pelabuhan membuka jalur tembak lintas dek.',
    tacticalNote: 'Kontainer memblokir cahaya senter & peluru. Hancurkan peti kayu untuk membuka jalur flank baru.',
    width: 1600,
    height: 1120,
    palette: {
      floorBase: '#121922',
      floorGrid: '#1b2533',
      floorAccent: '#253447',
      wallTop: '#243242',
      wallBorder: '#3b4e63',
      coverFill: '#3b434d',
      crateFill: '#78522d',
      bushFill: '#1b3d33',
      hazardColor: '#d97706',
      ambientTint: 'rgba(6, 10, 16, 0.87)',
    },
    obstacles: [
      ...makePerimeterWalls(1600, 1120),
      // Upper-left shipping container cluster
      { id: 'cd_w1', kind: 'wall', x: 260, y: 180, w: 220, h: 68 },
      { id: 'cd_w2', kind: 'wall', x: 260, y: 360, w: 72, h: 190 },
      // Lower-left shipping container
      { id: 'cd_w3', kind: 'wall', x: 260, y: 740, w: 230, h: 68 },
      // Upper-right shipping container cluster
      { id: 'cd_w4', kind: 'wall', x: 1120, y: 180, w: 220, h: 68 },
      { id: 'cd_w5', kind: 'wall', x: 1268, y: 360, w: 72, h: 190 },
      // Lower-right shipping container
      { id: 'cd_w6', kind: 'wall', x: 1110, y: 740, w: 230, h: 68 },
      // Central loading bay pillars
      { id: 'cd_c1', kind: 'wall', x: 640, y: 350, w: 120, h: 64 },
      { id: 'cd_c2', kind: 'wall', x: 840, y: 706, w: 120, h: 64 },
      { id: 'cd_c3', kind: 'wall', x: 752, y: 512, w: 96, h: 96 },
      // Low cover barricades (bullets pass over, movement blocked)
      { id: 'cd_lc1', kind: 'low_cover', x: 540, y: 190, w: 110, h: 36 },
      { id: 'cd_lc2', kind: 'low_cover', x: 950, y: 890, w: 110, h: 36 },
      { id: 'cd_lc3', kind: 'low_cover', x: 520, y: 540, w: 40, h: 110 },
      { id: 'cd_lc4', kind: 'low_cover', x: 1040, y: 470, w: 40, h: 110 },
      // Destructible crates (drop loot when shattered!)
      { id: 'cd_cr1', kind: 'crate', x: 600, y: 530, w: 54, h: 54, hp: 70, maxHp: 70 },
      { id: 'cd_cr2', kind: 'crate', x: 946, y: 530, w: 54, h: 54, hp: 70, maxHp: 70 },
      { id: 'cd_cr3', kind: 'crate', x: 430, y: 560, w: 54, h: 54, hp: 70, maxHp: 70 },
      { id: 'cd_cr4', kind: 'crate', x: 1116, y: 560, w: 54, h: 54, hp: 70, maxHp: 70 },
      // Stealth bushes / tarps
      { id: 'cd_b1', kind: 'bush', x: 480, y: 340, w: 100, h: 90 },
      { id: 'cd_b2', kind: 'bush', x: 1020, y: 690, w: 100, h: 90 },
      // Electrified dock crane floor vents
      { id: 'cd_h1', kind: 'hazard', x: 760, y: 210, w: 80, h: 80 },
      { id: 'cd_h2', kind: 'hazard', x: 760, y: 830, w: 80, h: 80 },
    ],
    teamASpawns: [
      { x: 130, y: 560 },
      { x: 150, y: 420 },
      { x: 150, y: 700 },
    ],
    teamBSpawns: [
      { x: 1470, y: 560 },
      { x: 1450, y: 420 },
      { x: 1450, y: 700 },
    ],
    soloSpawns: [
      { x: 130, y: 560 },
      { x: 1470, y: 560 },
      { x: 800, y: 115 },
      { x: 800, y: 1005 },
      { x: 160, y: 130 },
      { x: 1440, y: 990 },
    ],
    pickupSpots: [
      { x: 800, y: 390 },
      { x: 800, y: 730 },
      { x: 420, y: 290 },
      { x: 1180, y: 830 },
      { x: 420, y: 860 },
      { x: 1180, y: 290 },
      { x: 640, y: 560 },
      { x: 960, y: 560 },
    ],
  },

  abandoned_metro: {
    id: 'abandoned_metro',
    name: 'Stasiun Metro Tua',
    subtitle: 'Peron Bawah Tanah Gelap',
    description: 'Pilar beton berbaris sepanjang peron kereta tua. Sudut tikungan tajam menuntut kewaspadaan terhadap suara langkah.',
    tacticalNote: 'Manfaatkan loket tiket sebagai perlindungan penuh dan perhatikan jejak suara di terowongan tengah.',
    width: 1600,
    height: 1120,
    palette: {
      floorBase: '#14151b',
      floorGrid: '#20222c',
      floorAccent: '#2c303e',
      wallTop: '#2d313d',
      wallBorder: '#474e61',
      coverFill: '#45403b',
      crateFill: '#7a4b31',
      bushFill: '#1f3632',
      hazardColor: '#ef4444',
      ambientTint: 'rgba(8, 8, 12, 0.89)',
    },
    obstacles: [
      ...makePerimeterWalls(1600, 1120),
      // Subway car shells along center horizontal tracks
      { id: 'am_w1', kind: 'wall', x: 340, y: 455, w: 300, h: 66 },
      { id: 'am_w2', kind: 'wall', x: 960, y: 455, w: 300, h: 66 },
      { id: 'am_w3', kind: 'wall', x: 340, y: 605, w: 300, h: 66 },
      { id: 'am_w4', kind: 'wall', x: 960, y: 605, w: 300, h: 66 },
      // Platform ticket booths (top & bottom)
      { id: 'am_w5', kind: 'wall', x: 700, y: 170, w: 200, h: 74 },
      { id: 'am_w6', kind: 'wall', x: 700, y: 876, w: 200, h: 74 },
      // Concrete support pillars
      { id: 'am_p1', kind: 'wall', x: 290, y: 210, w: 68, h: 68 },
      { id: 'am_p2', kind: 'wall', x: 1242, y: 210, w: 68, h: 68 },
      { id: 'am_p3', kind: 'wall', x: 290, y: 842, w: 68, h: 68 },
      { id: 'am_p4', kind: 'wall', x: 1242, y: 842, w: 68, h: 68 },
      // Turnstile low covers
      { id: 'am_lc1', kind: 'low_cover', x: 500, y: 240, w: 120, h: 34 },
      { id: 'am_lc2', kind: 'low_cover', x: 980, y: 240, w: 120, h: 34 },
      { id: 'am_lc3', kind: 'low_cover', x: 500, y: 846, w: 120, h: 34 },
      { id: 'am_lc4', kind: 'low_cover', x: 980, y: 846, w: 120, h: 34 },
      // Destructible glass / luggage crates blocking mid cross
      { id: 'am_cr1', kind: 'crate', x: 773, y: 533, w: 54, h: 54, hp: 65, maxHp: 65 },
      { id: 'am_cr2', kind: 'crate', x: 670, y: 533, w: 52, h: 52, hp: 65, maxHp: 65 },
      { id: 'am_cr3', kind: 'crate', x: 878, y: 533, w: 52, h: 52, hp: 65, maxHp: 65 },
      // Dark shadow maintenance alcoves
      { id: 'am_b1', kind: 'bush', x: 170, y: 280, w: 92, h: 110 },
      { id: 'am_b2', kind: 'bush', x: 1338, y: 730, w: 92, h: 110 },
      // Live third-rail shock strips
      { id: 'am_h1', kind: 'hazard', x: 750, y: 340, w: 100, h: 64 },
      { id: 'am_h2', kind: 'hazard', x: 750, y: 716, w: 100, h: 64 },
    ],
    teamASpawns: [
      { x: 140, y: 560 },
      { x: 155, y: 400 },
      { x: 155, y: 720 },
    ],
    teamBSpawns: [
      { x: 1460, y: 560 },
      { x: 1445, y: 400 },
      { x: 1445, y: 720 },
    ],
    soloSpawns: [
      { x: 140, y: 560 },
      { x: 1460, y: 560 },
      { x: 460, y: 120 },
      { x: 1140, y: 1000 },
      { x: 1140, y: 120 },
      { x: 460, y: 1000 },
    ],
    pickupSpots: [
      { x: 800, y: 560 },
      { x: 800, y: 295 },
      { x: 800, y: 825 },
      { x: 450, y: 375 },
      { x: 1150, y: 745 },
      { x: 450, y: 745 },
      { x: 1150, y: 375 },
    ],
  },

  misty_shrine: {
    id: 'misty_shrine',
    name: 'Taman Kuil Kabut',
    subtitle: 'Pelataran Batu & Rumpun Bambu',
    description: 'Pelataran kuil tua yang diselimuti rumpun bambu penyamaran dan paviliun batu simetris—surga bagi penyergap dan penembak jitu.',
    tacticalNote: 'Rumpun bambu menyembunyikan hero selama bergerak pelan dan tidak menembak.',
    width: 1600,
    height: 1120,
    palette: {
      floorBase: '#111a18',
      floorGrid: '#1a2724',
      floorAccent: '#233631',
      wallTop: '#2c3532',
      wallBorder: '#4e5d56',
      coverFill: '#4d4a40',
      crateFill: '#7c5c34',
      bushFill: '#184735',
      hazardColor: '#eab308',
      ambientTint: 'rgba(6, 13, 12, 0.85)',
    },
    obstacles: [
      ...makePerimeterWalls(1600, 1120),
      // Central pavilion corner pillars (open inner cross)
      { id: 'ms_c1', kind: 'wall', x: 640, y: 400, w: 96, h: 64 },
      { id: 'ms_c2', kind: 'wall', x: 864, y: 400, w: 96, h: 64 },
      { id: 'ms_c3', kind: 'wall', x: 640, y: 656, w: 96, h: 64 },
      { id: 'ms_c4', kind: 'wall', x: 864, y: 656, w: 96, h: 64 },
      // Outer shrine gates
      { id: 'ms_w1', kind: 'wall', x: 310, y: 260, w: 72, h: 210 },
      { id: 'ms_w2', kind: 'wall', x: 310, y: 650, w: 72, h: 210 },
      { id: 'ms_w3', kind: 'wall', x: 1218, y: 260, w: 72, h: 210 },
      { id: 'ms_w4', kind: 'wall', x: 1218, y: 650, w: 72, h: 210 },
      // Stone garden walls (low cover)
      { id: 'ms_lc1', kind: 'low_cover', x: 520, y: 185, w: 150, h: 36 },
      { id: 'ms_lc2', kind: 'low_cover', x: 930, y: 185, w: 150, h: 36 },
      { id: 'ms_lc3', kind: 'low_cover', x: 520, y: 899, w: 150, h: 36 },
      { id: 'ms_lc4', kind: 'low_cover', x: 930, y: 899, w: 150, h: 36 },
      // Dense bamboo stealth groves!
      { id: 'ms_b1', kind: 'bush', x: 440, y: 450, w: 120, h: 220 },
      { id: 'ms_b2', kind: 'bush', x: 1040, y: 450, w: 120, h: 220 },
      { id: 'ms_b3', kind: 'bush', x: 720, y: 170, w: 160, h: 120 },
      { id: 'ms_b4', kind: 'bush', x: 720, y: 830, w: 160, h: 120 },
      // Offering crates
      { id: 'ms_cr1', kind: 'crate', x: 773, y: 533, w: 54, h: 54, hp: 60, maxHp: 60 },
      { id: 'ms_cr2', kind: 'crate', x: 460, y: 270, w: 52, h: 52, hp: 60, maxHp: 60 },
      { id: 'ms_cr3', kind: 'crate', x: 1088, y: 798, w: 52, h: 52, hp: 60, maxHp: 60 },
      // Spirit fire braziers (hazard)
      { id: 'ms_h1', kind: 'hazard', x: 600, y: 528, w: 64, h: 64 },
      { id: 'ms_h2', kind: 'hazard', x: 936, y: 528, w: 64, h: 64 },
    ],
    teamASpawns: [
      { x: 145, y: 560 },
      { x: 160, y: 380 },
      { x: 160, y: 740 },
    ],
    teamBSpawns: [
      { x: 1455, y: 560 },
      { x: 1440, y: 380 },
      { x: 1440, y: 740 },
    ],
    soloSpawns: [
      { x: 145, y: 560 },
      { x: 1455, y: 560 },
      { x: 800, y: 100 },
      { x: 800, y: 1020 },
      { x: 170, y: 150 },
      { x: 1430, y: 970 },
    ],
    pickupSpots: [
      { x: 800, y: 490 },
      { x: 800, y: 630 },
      { x: 500, y: 560 },
      { x: 1100, y: 560 },
      { x: 800, y: 230 },
      { x: 800, y: 890 },
      { x: 450, y: 840 },
      { x: 1150, y: 280 },
    ],
  },

  subterranean_lab: {
    id: 'subterranean_lab',
    name: 'Laboratorium Bawah Tanah',
    subtitle: 'Sektor Reaktor & Atrium Kaca',
    description: 'Ruang riset bertingkat rendah dengan atrium inti terbuka, peti suplai mudah pecah, dan ventilasi energi berdenyut.',
    tacticalNote: 'Atrium tengah penuh suplai berharga namun dikelilingi 4 sudut tembak dan ventilasi energi aktif.',
    width: 1600,
    height: 1120,
    palette: {
      floorBase: '#101720',
      floorGrid: '#182433',
      floorAccent: '#1f3246',
      wallTop: '#263445',
      wallBorder: '#435b75',
      coverFill: '#374759',
      crateFill: '#855a2e',
      bushFill: '#153e42',
      hazardColor: '#f59e0b',
      ambientTint: 'rgba(5, 9, 15, 0.88)',
    },
    obstacles: [
      ...makePerimeterWalls(1600, 1120),
      // Reinforced reactor ring (4 angled lab rooms)
      { id: 'sl_w1', kind: 'wall', x: 350, y: 220, w: 180, h: 64 },
      { id: 'sl_w2', kind: 'wall', x: 350, y: 284, w: 64, h: 150 },
      { id: 'sl_w3', kind: 'wall', x: 1070, y: 220, w: 180, h: 64 },
      { id: 'sl_w4', kind: 'wall', x: 1186, y: 284, w: 64, h: 150 },
      { id: 'sl_w5', kind: 'wall', x: 350, y: 836, w: 180, h: 64 },
      { id: 'sl_w6', kind: 'wall', x: 350, y: 686, w: 64, h: 150 },
      { id: 'sl_w7', kind: 'wall', x: 1070, y: 836, w: 180, h: 64 },
      { id: 'sl_w8', kind: 'wall', x: 1186, y: 686, w: 64, h: 150 },
      // Central glass-and-steel lab desks (low cover)
      { id: 'sl_lc1', kind: 'low_cover', x: 660, y: 420, w: 280, h: 36 },
      { id: 'sl_lc2', kind: 'low_cover', x: 660, y: 664, w: 280, h: 36 },
      // Destructible containment crates
      { id: 'sl_cr1', kind: 'crate', x: 600, y: 533, w: 54, h: 54, hp: 65, maxHp: 65 },
      { id: 'sl_cr2', kind: 'crate', x: 946, y: 533, w: 54, h: 54, hp: 65, maxHp: 65 },
      { id: 'sl_cr3', kind: 'crate', x: 773, y: 240, w: 54, h: 54, hp: 65, maxHp: 65 },
      { id: 'sl_cr4', kind: 'crate', x: 773, y: 826, w: 54, h: 54, hp: 65, maxHp: 65 },
      // Coolant steam patches (stealth)
      { id: 'sl_b1', kind: 'bush', x: 460, y: 480, w: 100, h: 160 },
      { id: 'sl_b2', kind: 'bush', x: 1040, y: 480, w: 100, h: 160 },
      // Reactor surge floor vents
      { id: 'sl_h1', kind: 'hazard', x: 755, y: 515, w: 90, h: 90 },
      { id: 'sl_h2', kind: 'hazard', x: 205, y: 525, w: 70, h: 70 },
      { id: 'sl_h3', kind: 'hazard', x: 1325, y: 525, w: 70, h: 70 },
    ],
    teamASpawns: [
      { x: 120, y: 560 },
      { x: 150, y: 360 },
      { x: 150, y: 760 },
    ],
    teamBSpawns: [
      { x: 1480, y: 560 },
      { x: 1450, y: 360 },
      { x: 1450, y: 760 },
    ],
    soloSpawns: [
      { x: 120, y: 560 },
      { x: 1480, y: 560 },
      { x: 800, y: 110 },
      { x: 800, y: 1010 },
      { x: 165, y: 145 },
      { x: 1435, y: 975 },
    ],
    pickupSpots: [
      { x: 800, y: 360 },
      { x: 800, y: 760 },
      { x: 690, y: 560 },
      { x: 910, y: 560 },
      { x: 470, y: 340 },
      { x: 1130, y: 780 },
      { x: 470, y: 780 },
      { x: 1130, y: 340 },
    ],
  },
};

export const MAP_LIST: MapDefinition[] = [
  MAPS.cargo_docks,
  MAPS.abandoned_metro,
  MAPS.misty_shrine,
  MAPS.subterranean_lab,
];
