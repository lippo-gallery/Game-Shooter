export type GamePhase = 'title' | 'playing' | 'paused' | 'gameover';

export type GameMode = 'team3v3' | 'solo';

export type HeroId = 'kairo' | 'bima' | 'laras' | 'tala' | 'vexa';

export type MapId = 'cargo_docks' | 'abandoned_metro' | 'misty_shrine' | 'subterranean_lab';

export type UpgradeAttribute = 'firepower' | 'vitality' | 'agility' | 'optics' | 'skillMastery';

export type SquadCommand = 'follow' | 'attack' | 'defend' | 'regroup';

export type BotArchetype = 'scout' | 'marksman' | 'vanguard' | 'breacher';

export type ObstacleKind = 'wall' | 'low_cover' | 'crate' | 'bush' | 'hazard';

export interface Vec2 {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface MapObstacle extends Rect {
  id: string;
  kind: ObstacleKind;
  hp?: number;
  maxHp?: number;
  label?: string;
}

export interface MapDefinition {
  id: MapId;
  name: string;
  subtitle: string;
  description: string;
  tacticalNote: string;
  width: number;
  height: number;
  palette: {
    floorBase: string;
    floorGrid: string;
    floorAccent: string;
    wallTop: string;
    wallBorder: string;
    coverFill: string;
    crateFill: string;
    bushFill: string;
    hazardColor: string;
    ambientTint: string;
  };
  obstacles: MapObstacle[];
  teamASpawns: Vec2[];
  teamBSpawns: Vec2[];
  soloSpawns: Vec2[];
  pickupSpots: Vec2[];
}

export interface SkillDefinition {
  name: string;
  keyHint: string;
  cooldown: number;
  description: string;
  unlockLevel: number;
  evolutionNote: string;
}

export interface WeaponProfile {
  name: string;
  damage: number;
  fireRate: number; // shots per second
  projectileSpeed: number;
  range: number;
  pellets: number;
  spreadRad: number;
  moveSpreadBonus: number;
  magSize: number;
  reloadTime: number;
  armorPen: number; // 0..1 fraction bypassing armor
  noiseRadius: number;
  pierceLowCover?: boolean;
  splashRadius?: number;
  tracerColor: string;
}

export interface HeroDefinition {
  id: HeroId;
  name: string;
  epithet: string;
  role: string;
  accentColor: string;
  secondaryColor: string;
  portraitUrl: string;
  lore: string;
  strengths: string[];
  weaknesses: string[];
  baseStats: {
    hp: number;
    armor: number;
    speed: number;
    visionRange: number;
    visionArcRad: number;
    footstepNoise: number;
    radius: number;
  };
  weapon: WeaponProfile;
  passive: {
    name: string;
    description: string;
    evolutionNote: string;
  };
  activeSkill: SkillDefinition;
  ultimateSkill: SkillDefinition;
}

export interface HeroUpgradeState {
  firepower: number; // 0..5
  vitality: number; // 0..5
  agility: number; // 0..5
  optics: number; // 0..5
  skillMastery: number; // 0..5
}

export interface HeroProgress {
  heroId: HeroId;
  level: number;
  xp: number;
  matchesPlayed: number;
  wins: number;
  eliminations: number;
  upgrades: HeroUpgradeState;
}

export interface ComputedHeroStats {
  maxHp: number;
  maxArmor: number;
  speed: number;
  damage: number;
  visionRange: number;
  visionArcRad: number;
  footstepNoise: number;
  activeCooldown: number;
  ultimateCooldown: number;
  skillPowerMultiplier: number;
  powerRating: number;
  rankTitle: string;
  passiveEvolved: boolean;
  activeEvolved: boolean;
  ultimateEvolved: boolean;
}

export interface PlayerProfile {
  scrap: number;
  selectedHeroId: HeroId;
  selectedMapId: MapId;
  selectedMode: GameMode;
  totalMatches: number;
  totalWins: number;
  winStreak: number;
  heroProgress: Record<HeroId, HeroProgress>;
}

export interface AdaptiveMapHeatmap {
  cols: number;
  rows: number;
  cells: number[];
}

export interface AdaptiveBotMemory {
  version: number;
  samples: number;
  matchesAnalyzed: number;
  strafeLeftScore: number; // -1 (right) to +1 (left)
  avgEngageRange: number;
  sprintRatio: number; // 0..1
  coverCampRatio: number; // 0..1
  skillSpamRate: number;
  heatmaps: Record<MapId, AdaptiveMapHeatmap>;
}

export interface AdaptiveInsights {
  adaptationLevel: number; // 1..10
  strafeTendencyLabel: string;
  rangeStyleLabel: string;
  tempoLabel: string;
  counterTacticSummary: string;
  aimLeadBias: number; // radians/scalar multiplier
  preferredFlankSign: 1 | -1;
}

export type PickupKind = 'medkit' | 'armor' | 'ammo' | 'visor';

export interface WorldPickup {
  id: string;
  kind: PickupKind;
  x: number;
  y: number;
  active: boolean;
  respawnTimer: number;
}

export interface ActorHudEntry {
  id: string;
  name: string;
  heroId: HeroId;
  team: 'A' | 'B';
  isPlayer: boolean;
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  alive: boolean;
  downed: boolean;
  reviveProgress: number;
  x: number;
  y: number;
  angle: number;
  visibleToPlayer: boolean;
  roleLabel: string;
}

export interface KillFeedItem {
  id: number;
  text: string;
  tone: 'ally' | 'enemy' | 'system';
  expiresAt: number;
}

export interface HudSnapshot {
  phase: GamePhase;
  mode: GameMode;
  mapId: MapId;
  playerHeroId: HeroId;
  playerHp: number;
  playerMaxHp: number;
  playerArmor: number;
  playerMaxArmor: number;
  ammo: number;
  maxAmmo: number;
  reloading: boolean;
  reloadProgress: number;
  activeCooldown: number;
  activeMaxCooldown: number;
  ultimateCooldown: number;
  ultimateMaxCooldown: number;
  activeDuration: number;
  ultimateDuration: number;
  autoFire: boolean;
  squadCommand: SquadCommand;
  alliesAlive: number;
  alliesTotal: number;
  enemiesAlive: number;
  enemiesTotal: number;
  matchTime: number;
  stormRadius: number;
  stormMaxRadius: number;
  playerKills: number;
  playerDamage: number;
  playerRevives: number;
  playerDowned: boolean;
  playerReviveProgress: number;
  adaptationLevel: number;
  adaptationSummary: string;
  actors: ActorHudEntry[];
  killFeed: KillFeedItem[];
  radioCallout: string | null;
}

export interface MatchSummary {
  victory: boolean;
  mode: GameMode;
  mapId: MapId;
  heroId: HeroId;
  eliminations: number;
  damageDealt: number;
  revives: number;
  survivalSeconds: number;
  xpEarned: number;
  scrapEarned: number;
  leveledUp: boolean;
  previousLevel: number;
  newLevel: number;
  adaptationLevelBefore: number;
  adaptationLevelAfter: number;
  botCounterNote: string;
}
