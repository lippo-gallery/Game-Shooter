import { AdaptiveBotMemory, AdaptiveInsights, AdaptiveMapHeatmap, MapId, Vec2 } from './types';
import { clamp } from './geometry';

const STORAGE_KEY = 'bayang_peluru_adaptive_ai_v1';
export const HEATMAP_COLS = 16;
export const HEATMAP_ROWS = 11;

function createEmptyHeatmap(): AdaptiveMapHeatmap {
  return {
    cols: HEATMAP_COLS,
    rows: HEATMAP_ROWS,
    cells: new Array(HEATMAP_COLS * HEATMAP_ROWS).fill(0),
  };
}

export function createDefaultAdaptiveMemory(): AdaptiveBotMemory {
  return {
    version: 1,
    samples: 0,
    matchesAnalyzed: 0,
    strafeLeftScore: 0,
    avgEngageRange: 270,
    sprintRatio: 0.45,
    coverCampRatio: 0.3,
    skillSpamRate: 0.25,
    heatmaps: {
      cargo_docks: createEmptyHeatmap(),
      abandoned_metro: createEmptyHeatmap(),
      misty_shrine: createEmptyHeatmap(),
      subterranean_lab: createEmptyHeatmap(),
    },
  };
}

export function loadAdaptiveMemory(): AdaptiveBotMemory {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return createDefaultAdaptiveMemory();
    }
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultAdaptiveMemory();
    const parsed = JSON.parse(raw) as Partial<AdaptiveBotMemory>;
    const base = createDefaultAdaptiveMemory();
    const mergedHeatmaps = { ...base.heatmaps };
    if (parsed.heatmaps) {
      (Object.keys(base.heatmaps) as MapId[]).forEach((mapId) => {
        const hm = parsed.heatmaps?.[mapId];
        if (hm && Array.isArray(hm.cells) && hm.cells.length === HEATMAP_COLS * HEATMAP_ROWS) {
          mergedHeatmaps[mapId] = {
            cols: HEATMAP_COLS,
            rows: HEATMAP_ROWS,
            cells: hm.cells.map((v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0)),
          };
        }
      });
    }
    return {
      ...base,
      ...parsed,
      heatmaps: mergedHeatmaps,
    };
  } catch {
    return createDefaultAdaptiveMemory();
  }
}

export function saveAdaptiveMemory(memory: AdaptiveBotMemory): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(memory));
  } catch {
    // Ignore storage quota errors
  }
}

export function recordPlayerMovementSample(
  memory: AdaptiveBotMemory,
  params: {
    mapId: MapId;
    mapWidth: number;
    mapHeight: number;
    playerPos: Vec2;
    playerVel: Vec2;
    nearestEnemyPos: Vec2 | null;
    isMovingFast: boolean;
    nearCover: boolean;
  }
): AdaptiveBotMemory {
  const { mapId, mapWidth, mapHeight, playerPos, playerVel, nearestEnemyPos, isMovingFast, nearCover } = params;
  const hm = memory.heatmaps[mapId] ?? createEmptyHeatmap();
  const col = clamp(Math.floor((playerPos.x / mapWidth) * hm.cols), 0, hm.cols - 1);
  const row = clamp(Math.floor((playerPos.y / mapHeight) * hm.rows), 0, hm.rows - 1);
  const idx = row * hm.cols + col;

  // Mild decay across heatmap so recent tactical habits stay prominent
  const nextCells = hm.cells.slice();
  if (memory.samples % 25 === 0) {
    for (let i = 0; i < nextCells.length; i++) {
      nextCells[i] = Number((nextCells[i] * 0.96).toFixed(3));
    }
  }
  nextCells[idx] = Math.min(40, Number((nextCells[idx] + 1).toFixed(3)));

  // Calculate perpendicular strafe direction relative to nearest enemy
  const alpha = 0.08;
  let nextStrafe = memory.strafeLeftScore;
  let nextRange = memory.avgEngageRange;

  if (nearestEnemyPos) {
    const toPlayerX = playerPos.x - nearestEnemyPos.x;
    const toPlayerY = playerPos.y - nearestEnemyPos.y;
    const distance = Math.hypot(toPlayerX, toPlayerY);
    if (distance > 30 && distance < 620) {
      nextRange = memory.avgEngageRange * (1 - alpha) + distance * alpha;
      const speed = Math.hypot(playerVel.x, playerVel.y);
      if (speed > 35) {
        // Cross product of (enemy -> player) x velocity determines clockwise vs counter-clockwise strafe
        const nx = toPlayerX / distance;
        const ny = toPlayerY / distance;
        const vnx = playerVel.x / speed;
        const vny = playerVel.y / speed;
        const cross = nx * vny - ny * vnx; // +1 = left/CCW, -1 = right/CW
        nextStrafe = clamp(memory.strafeLeftScore * (1 - alpha) + cross * alpha, -1, 1);
      }
    }
  }

  const nextSprint = clamp(memory.sprintRatio * (1 - alpha) + (isMovingFast ? 1 : 0) * alpha, 0, 1);
  const nextCover = clamp(memory.coverCampRatio * (1 - alpha) + (nearCover ? 1 : 0) * alpha, 0, 1);

  return {
    ...memory,
    samples: memory.samples + 1,
    strafeLeftScore: Number(nextStrafe.toFixed(4)),
    avgEngageRange: Math.round(nextRange),
    sprintRatio: Number(nextSprint.toFixed(4)),
    coverCampRatio: Number(nextCover.toFixed(4)),
    heatmaps: {
      ...memory.heatmaps,
      [mapId]: {
        ...hm,
        cells: nextCells,
      },
    },
  };
}

export function getAdaptationLevel(memory: AdaptiveBotMemory): number {
  const raw = 1 + Math.floor(memory.samples / 45) + Math.floor(memory.matchesAnalyzed * 0.7);
  return clamp(raw, 1, 10);
}

export function analyzeAdaptiveMemory(memory: AdaptiveBotMemory): AdaptiveInsights {
  const adaptationLevel = getAdaptationLevel(memory);

  let strafeTendencyLabel = 'Pola menghindar seimbang';
  let preferredFlankSign: 1 | -1 = 1;
  if (memory.strafeLeftScore > 0.16) {
    strafeTendencyLabel = 'Dominan strafe ke kiri';
    preferredFlankSign = 1;
  } else if (memory.strafeLeftScore < -0.16) {
    strafeTendencyLabel = 'Dominan strafe ke kanan';
    preferredFlankSign = -1;
  }

  let rangeStyleLabel = 'Pertempuran jarak menengah';
  if (memory.avgEngageRange < 225) {
    rangeStyleLabel = 'Agresif jarak dekat (Rush)';
  } else if (memory.avgEngageRange > 325) {
    rangeStyleLabel = 'Penembak jarak jauh (Kiting)';
  }

  let tempoLabel = 'Tempo seimbang';
  if (memory.coverCampRatio > 0.56) {
    tempoLabel = 'Sering bertahan di balik cover';
  } else if (memory.sprintRatio > 0.68) {
    tempoLabel = 'Rotasi cepat & agresif';
  }

  let counterTacticSummary = 'Bot masih mengumpulkan pola pergerakan awalmu.';
  if (adaptationLevel >= 2) {
    if (memory.coverCampRatio > 0.56) {
      counterTacticSummary = 'Bot mengirim Pembongkar & pengepung ke posisi cover favoritmu.';
    } else if (memory.avgEngageRange < 225) {
      counterTacticSummary = 'Bot menjaga jarak & menyilangkan tembakan saat kamu menerjang.';
    } else if (Math.abs(memory.strafeLeftScore) > 0.16) {
      const side = memory.strafeLeftScore > 0 ? 'kiri' : 'kanan';
      counterTacticSummary = `Bot memprediksi hindaran ke ${side} & memotong jalur flank.`;
    } else {
      counterTacticSummary = 'Bot memetakan zona panasmu & mengoordinasi penyergapan dua arah.';
    }
  }

  // Higher adaptation = stronger predictive lead along observed strafe vector
  const strength = clamp((adaptationLevel - 1) / 9, 0.08, 1);
  const aimLeadBias = memory.strafeLeftScore * strength;

  return {
    adaptationLevel,
    strafeTendencyLabel,
    rangeStyleLabel,
    tempoLabel,
    counterTacticSummary,
    aimLeadBias,
    preferredFlankSign,
  };
}

/**
 * Returns the world coordinates of the player's top favorite ambush/patrol hotspots on this map.
 */
export function getTopPlayerHotspots(
  memory: AdaptiveBotMemory,
  mapId: MapId,
  mapWidth: number,
  mapHeight: number,
  count = 3
): Vec2[] {
  const hm = memory.heatmaps[mapId];
  if (!hm) return [];

  const indexed = hm.cells
    .map((heat, idx) => ({ heat, idx }))
    .filter((entry) => entry.heat > 0.5)
    .sort((a, b) => b.heat - a.heat)
    .slice(0, count);

  const cellW = mapWidth / hm.cols;
  const cellH = mapHeight / hm.rows;

  return indexed.map(({ idx }) => {
    const col = idx % hm.cols;
    const row = Math.floor(idx / hm.cols);
    return {
      x: (col + 0.5) * cellW,
      y: (row + 0.5) * cellH,
    };
  });
}

/**
 * Computes predictive aim angle for an enemy bot factoring in target velocity
 * and the bot's learned strafe bias of the player.
 */
export function computeAdaptiveAimAngle(
  shooterPos: Vec2,
  targetPos: Vec2,
  targetVel: Vec2,
  projectileSpeed: number,
  memory: AdaptiveBotMemory,
  isTargetPlayer: boolean
): number {
  const dx = targetPos.x - shooterPos.x;
  const dy = targetPos.y - shooterPos.y;
  const distance = Math.hypot(dx, dy);
  if (distance < 1) return 0;

  const adaptationLevel = getAdaptationLevel(memory);
  const leadFactor = isTargetPlayer ? clamp(0.28 + adaptationLevel * 0.072, 0.25, 0.96) : 0.45;
  const travelTime = Math.min(0.65, distance / Math.max(200, projectileSpeed));

  let predX = targetPos.x + targetVel.x * travelTime * leadFactor;
  let predY = targetPos.y + targetVel.y * travelTime * leadFactor;

  // Apply subtle learned strafe anticipation even when player momentarily pauses to shoot
  if (isTargetPlayer && Math.abs(memory.strafeLeftScore) > 0.14 && adaptationLevel >= 2) {
    const nx = dx / distance;
    const ny = dy / distance;
    // Perpendicular vector matching cross product convention (+1 = CCW)
    const perpX = -ny;
    const perpY = nx;
    const strafeShift = memory.strafeLeftScore * (14 + adaptationLevel * 3.8);
    predX += perpX * strafeShift;
    predY += perpY * strafeShift;
  }

  return Math.atan2(predY - shooterPos.y, predX - shooterPos.x);
}
