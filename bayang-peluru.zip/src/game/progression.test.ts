import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyUpgrade,
  computeBotDifficultyScale,
  computeHeroStats,
  createDefaultProfile,
  getUpgradeCost,
  grantMatchRewards,
  xpRequiredForLevel,
} from './progression';

test('hero upgrade deducts scrap and increases computed stats', () => {
  const profile = createDefaultProfile();
  const before = computeHeroStats('kairo', profile.heroProgress.kairo);
  const cost = getUpgradeCost(0);

  const res = applyUpgrade(profile, 'kairo', 'firepower');
  assert.equal(res.success, true);
  assert.equal(res.profile.scrap, profile.scrap - cost);
  assert.equal(res.profile.heroProgress.kairo.upgrades.firepower, 1);

  const after = computeHeroStats('kairo', res.profile.heroProgress.kairo);
  assert.ok(after.damage > before.damage, 'Firepower upgrade must increase weapon damage');
  assert.ok(after.powerRating > before.powerRating);
});

test('dynamic leveling handles multi-level XP grants and unlocks skill evolutions', () => {
  let profile = createDefaultProfile();
  assert.equal(profile.heroProgress.laras.level, 1);

  // Grant several high-impact victories
  for (let i = 0; i < 4; i++) {
    const reward = grantMatchRewards(profile, {
      heroId: 'laras',
      victory: true,
      eliminations: 4,
      damageDealt: 650,
      revives: 1,
      survivalSeconds: 65,
      adaptationLevel: 4,
    });
    profile = reward.profile;
    assert.ok(reward.xpEarned > 0);
    assert.ok(reward.scrapEarned > 0);
  }

  const prog = profile.heroProgress.laras;
  assert.ok(prog.level >= 4, `Expected level >= 4 after strong matches, got ${prog.level}`);
  assert.ok(prog.xp < xpRequiredForLevel(prog.level));

  const stats = computeHeroStats('laras', prog);
  assert.equal(stats.passiveEvolved, true);
  assert.equal(stats.activeEvolved, true);
});

test('competitive bot difficulty scales up with hero power and adaptation level', () => {
  const profile = createDefaultProfile();
  const baseStats = computeHeroStats('bima', profile.heroProgress.bima);
  const lowScale = computeBotDifficultyScale(baseStats, 1, 0);

  const highProg = {
    ...profile.heroProgress.bima,
    level: 8,
    upgrades: { firepower: 4, vitality: 4, agility: 3, optics: 3, skillMastery: 3 },
  };
  const highStats = computeHeroStats('bima', highProg);
  const highScale = computeBotDifficultyScale(highStats, 7, 3);

  assert.ok(highScale.hpScale > lowScale.hpScale);
  assert.ok(highScale.damageScale > lowScale.damageScale);
  assert.ok(highScale.reactionDelay < lowScale.reactionDelay);
  assert.ok(highScale.accuracySpread < lowScale.accuracySpread);
});
