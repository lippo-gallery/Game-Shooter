import test from 'node:test';
import assert from 'node:assert/strict';
import {
  analyzeAdaptiveMemory,
  computeAdaptiveAimAngle,
  createDefaultAdaptiveMemory,
  getAdaptationLevel,
  getTopPlayerHotspots,
  recordPlayerMovementSample,
} from './adaptiveAI';

test('adaptive memory tracks spatial hotspots accurately', () => {
  let mem = createDefaultAdaptiveMemory();
  for (let i = 0; i < 12; i++) {
    mem = recordPlayerMovementSample(mem, {
      mapId: 'cargo_docks',
      mapWidth: 1600,
      mapHeight: 1120,
      playerPos: { x: 800, y: 560 },
      playerVel: { x: 0, y: 0 },
      nearestEnemyPos: { x: 1000, y: 560 },
      isMovingFast: false,
      nearCover: true,
    });
  }

  const hotspots = getTopPlayerHotspots(mem, 'cargo_docks', 1600, 1120, 1);
  assert.equal(hotspots.length, 1);
  assert.ok(Math.abs(hotspots[0].x - 800) < 120);
  assert.ok(Math.abs(hotspots[0].y - 560) < 120);
});

test('adaptive memory learns strafe bias and elevates adaptation level', () => {
  let mem = createDefaultAdaptiveMemory();
  assert.equal(getAdaptationLevel(mem), 1);

  // Enemy is at (800, 560), player is at (600, 560), moving DOWN (+y):
  // enemy->player = (-200, 0) => nx=-1, ny=0; vel=(0, 200) => vnx=0, vny=1; cross = -1 (right/CW)
  for (let i = 0; i < 55; i++) {
    mem = recordPlayerMovementSample(mem, {
      mapId: 'abandoned_metro',
      mapWidth: 1600,
      mapHeight: 1120,
      playerPos: { x: 600, y: 560 },
      playerVel: { x: 0, y: 200 },
      nearestEnemyPos: { x: 800, y: 560 },
      isMovingFast: true,
      nearCover: false,
    });
  }

  const insights = analyzeAdaptiveMemory(mem);
  assert.ok(insights.adaptationLevel >= 2, 'Adaptation level should grow with samples');
  assert.ok(mem.strafeLeftScore < -0.2, 'Should detect dominant right strafe');
  assert.equal(insights.preferredFlankSign, -1);

  // Predictive aim should lead downward (+y) when shooting from (800, 560) toward (600, 560)
  const rawAngle = Math.atan2(0, -200); // PI
  const predAngle = computeAdaptiveAimAngle(
    { x: 800, y: 560 },
    { x: 600, y: 560 },
    { x: 0, y: 200 },
    700,
    mem,
    true
  );
  // Moving downward from x=600 puts predicted point at y > 560 => angle slightly less than PI (positive y, negative x)
  assert.ok(predAngle > 0 && predAngle < rawAngle, `Expected predictive lead below PI, got ${predAngle}`);
});
