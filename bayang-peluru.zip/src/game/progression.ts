import { HEROES } from './heroes';
import {
  ComputedHeroStats,
  HeroId,
  HeroProgress,
  HeroUpgradeState,
  PlayerProfile,
  UpgradeAttribute,
} from './types';
import { clamp } from './geometry';

const PROFILE_STORAGE_KEY = 'bayang_peluru_profile_v1';
export const MAX_HERO_LEVEL = 20;
export const MAX_UPGRADE_RANK = 5;

export const UPGRADE_META: Record<
  UpgradeAttribute,
  { label: string; effectDesc: string; bonusPerRank: string }
> = {
  firepower: {
    label: 'Daya Tembak',
    effectDesc: 'Meningkatkan damage senjata & penetrasi',
    bonusPerRank: '+8% DMG',
  },
  vitality: {
    label: 'Ketahanan',
    effectDesc: 'Meningkatkan batas HP & Armor maksimum',
    bonusPerRank: '+10% HP/ARM',
  },
  agility: {
    label: 'Mobilitas',
    effectDesc: 'Meningkatkan kecepatan gerak & langkah senyap',
    bonusPerRank: '+4% SPD',
  },
  optics: {
    label: 'Optik & Visi',
    effectDesc: 'Memperpanjang jarak & lebar senter taktis',
    bonusPerRank: '+6% VISI',
  },
  skillMastery: {
    label: 'Keahlian Taktis',
    effectDesc: 'Mempercepat cooldown & memperkuat skill aktif/ult',
    bonusPerRank: '-6% CD',
  },
};

export function createDefaultHeroProgress(heroId: HeroId): HeroProgress {
  return {
    heroId,
    level: 1,
    xp: 0,
    matchesPlayed: 0,
    wins: 0,
    eliminations: 0,
    upgrades: {
      firepower: 0,
      vitality: 0,
      agility: 0,
      optics: 0,
      skillMastery: 0,
    },
  };
}

export function createDefaultProfile(): PlayerProfile {
  return {
    scrap: 180, // Starter tactical scrap so players can immediately try upgrading a hero!
    selectedHeroId: 'kairo',
    selectedMapId: 'cargo_docks',
    selectedMode: 'team3v3',
    totalMatches: 0,
    totalWins: 0,
    winStreak: 0,
    heroProgress: {
      kairo: createDefaultHeroProgress('kairo'),
      bima: createDefaultHeroProgress('bima'),
      laras: createDefaultHeroProgress('laras'),
      tala: createDefaultHeroProgress('tala'),
      vexa: createDefaultHeroProgress('vexa'),
    },
  };
}

export function loadPlayerProfile(): PlayerProfile {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return createDefaultProfile();
    }
    const raw = window.localStorage.getItem(PROFILE_STORAGE_KEY);
    if (!raw) return createDefaultProfile();
    const parsed = JSON.parse(raw) as Partial<PlayerProfile>;
    const base = createDefaultProfile();
    const heroProgress = { ...base.heroProgress };
    if (parsed.heroProgress) {
      (Object.keys(base.heroProgress) as HeroId[]).forEach((id) => {
        const hp = parsed.heroProgress?.[id];
        if (hp) {
          heroProgress[id] = {
            ...base.heroProgress[id],
            ...hp,
            upgrades: {
              ...base.heroProgress[id].upgrades,
              ...(hp.upgrades ?? {}),
            },
          };
        }
      });
    }
    return {
      ...base,
      ...parsed,
      heroProgress,
    };
  } catch {
    return createDefaultProfile();
  }
}

export function savePlayerProfile(profile: PlayerProfile): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    window.localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
  } catch {
    // Ignore storage errors
  }
}

export function xpRequiredForLevel(level: number): number {
  const safeLv = Math.max(1, Math.floor(level));
  return Math.round(120 + (safeLv - 1) * 65 + Math.pow(safeLv - 1, 1.45) * 18);
}

export function getHeroRankTitle(level: number): string {
  if (level >= 15) return 'Legenda Arena';
  if (level >= 10) return 'Komandan Elit';
  if (level >= 6) return 'Spesialis Taktis';
  if (level >= 3) return 'Veteran Bayangan';
  return 'Rekrut Lapangan';
}

export function getUpgradeCost(currentRank: number): number {
  if (currentRank >= MAX_UPGRADE_RANK) return 0;
  return 60 + currentRank * 55;
}

export function computeHeroStats(heroId: HeroId, progress: HeroProgress): ComputedHeroStats {
  const hero = HEROES[heroId];
  const lvBonus = Math.max(0, progress.level - 1);
  const up: HeroUpgradeState = progress.upgrades;

  const maxHp = Math.round(hero.baseStats.hp * (1 + lvBonus * 0.045 + up.vitality * 0.1));
  const maxArmor = Math.round(hero.baseStats.armor * (1 + lvBonus * 0.045 + up.vitality * 0.1));
  const speed = Math.round(hero.baseStats.speed * (1 + lvBonus * 0.008 + up.agility * 0.04));
  const damage = Math.round(hero.weapon.damage * (1 + lvBonus * 0.04 + up.firepower * 0.08));
  const visionRange = Math.round(hero.baseStats.visionRange * (1 + lvBonus * 0.012 + up.optics * 0.06));
  const visionArcRad = Number(
    clamp(hero.baseStats.visionArcRad * (1 + up.optics * 0.045), 0.55, 1.85).toFixed(3)
  );
  const footstepNoise = Math.round(hero.baseStats.footstepNoise * Math.max(0.55, 1 - up.agility * 0.06));

  const cdScale = Math.max(0.62, 1 - up.skillMastery * 0.06 - lvBonus * 0.008);
  const activeEvolved = progress.level >= 4;
  const activeCooldown = Number(
    Math.max(2.5, hero.activeSkill.cooldown * cdScale - (activeEvolved && heroId === 'kairo' ? 1.2 : 0)).toFixed(2)
  );
  const ultimateCooldown = Number(Math.max(7.5, hero.ultimateSkill.cooldown * cdScale).toFixed(2));
  const skillPowerMultiplier = Number((1 + lvBonus * 0.03 + up.skillMastery * 0.08).toFixed(2));

  const totalUpgradeRanks = up.firepower + up.vitality + up.agility + up.optics + up.skillMastery;
  const powerRating = Math.round(100 + lvBonus * 24 + totalUpgradeRanks * 18);

  return {
    maxHp,
    maxArmor,
    speed,
    damage,
    visionRange,
    visionArcRad,
    footstepNoise,
    activeCooldown,
    ultimateCooldown,
    skillPowerMultiplier,
    powerRating,
    rankTitle: getHeroRankTitle(progress.level),
    passiveEvolved: progress.level >= 2,
    activeEvolved,
    ultimateEvolved: progress.level >= 6,
  };
}

export function applyUpgrade(
  profile: PlayerProfile,
  heroId: HeroId,
  attr: UpgradeAttribute
): { profile: PlayerProfile; success: boolean; reason?: string } {
  const heroProg = profile.heroProgress[heroId];
  const currentRank = heroProg.upgrades[attr];
  if (currentRank >= MAX_UPGRADE_RANK) {
    return { profile, success: false, reason: 'Sudah mencapai level maksimum' };
  }
  const cost = getUpgradeCost(currentRank);
  if (profile.scrap < cost) {
    return { profile, success: false, reason: 'Scrap tidak mencukupi' };
  }

  const nextProfile: PlayerProfile = {
    ...profile,
    scrap: profile.scrap - cost,
    heroProgress: {
      ...profile.heroProgress,
      [heroId]: {
        ...heroProg,
        upgrades: {
          ...heroProg.upgrades,
          [attr]: currentRank + 1,
        },
      },
    },
  };
  return { profile: nextProfile, success: true };
}

export function grantMatchRewards(
  profile: PlayerProfile,
  params: {
    heroId: HeroId;
    victory: boolean;
    eliminations: number;
    damageDealt: number;
    revives: number;
    survivalSeconds: number;
    adaptationLevel: number;
  }
): {
  profile: PlayerProfile;
  xpEarned: number;
  scrapEarned: number;
  previousLevel: number;
  newLevel: number;
  leveledUp: boolean;
} {
  const { heroId, victory, eliminations, damageDealt, revives, survivalSeconds, adaptationLevel } = params;
  const heroProg = profile.heroProgress[heroId];
  const previousLevel = heroProg.level;

  const adaptBonus = 1 + (adaptationLevel - 1) * 0.08;
  const baseXp =
    (victory ? 95 : 42) +
    eliminations * 32 +
    revives * 25 +
    Math.min(60, Math.floor(damageDealt / 18)) +
    Math.min(40, Math.floor(survivalSeconds * 0.6));
  const xpEarned = Math.round(baseXp * adaptBonus);

  const baseScrap =
    (victory ? 75 : 35) +
    eliminations * 20 +
    revives * 18 +
    Math.min(35, Math.floor(damageDealt / 30));
  const scrapEarned = Math.round(baseScrap * adaptBonus);

  let level = heroProg.level;
  let xp = heroProg.xp + xpEarned;
  while (level < MAX_HERO_LEVEL) {
    const needed = xpRequiredForLevel(level);
    if (xp >= needed) {
      xp -= needed;
      level += 1;
    } else {
      break;
    }
  }
  if (level >= MAX_HERO_LEVEL) {
    xp = Math.min(xp, xpRequiredForLevel(MAX_HERO_LEVEL));
  }

  const nextHeroProg: HeroProgress = {
    ...heroProg,
    level,
    xp,
    matchesPlayed: heroProg.matchesPlayed + 1,
    wins: heroProg.wins + (victory ? 1 : 0),
    eliminations: heroProg.eliminations + eliminations,
  };

  const nextProfile: PlayerProfile = {
    ...profile,
    scrap: profile.scrap + scrapEarned,
    totalMatches: profile.totalMatches + 1,
    totalWins: profile.totalWins + (victory ? 1 : 0),
    winStreak: victory ? profile.winStreak + 1 : 0,
    heroProgress: {
      ...profile.heroProgress,
      [heroId]: nextHeroProg,
    },
  };

  return {
    profile: nextProfile,
    xpEarned,
    scrapEarned,
    previousLevel,
    newLevel: level,
    leveledUp: level > previousLevel,
  };
}

/**
 * Scales bot stats dynamically so upgraded heroes & high win-streaks face genuinely competitive bots.
 */
export function computeBotDifficultyScale(
  playerStats: ComputedHeroStats,
  adaptationLevel: number,
  winStreak: number
): { hpScale: number; damageScale: number; reactionDelay: number; accuracySpread: number } {
  const powerDelta = Math.max(0, (playerStats.powerRating - 100) / 360);
  const adaptNorm = (adaptationLevel - 1) / 9;
  const streakBonus = Math.min(0.18, winStreak * 0.045);

  return {
    hpScale: Number((0.92 + powerDelta * 0.45 + adaptNorm * 0.16 + streakBonus).toFixed(3)),
    damageScale: Number((0.84 + powerDelta * 0.32 + adaptNorm * 0.16 + streakBonus * 0.6).toFixed(3)),
    reactionDelay: Number(clamp(0.42 - adaptNorm * 0.18 - streakBonus * 0.3, 0.16, 0.45).toFixed(3)),
    accuracySpread: Number(clamp(0.16 - adaptNorm * 0.075 - streakBonus * 0.08, 0.045, 0.17).toFixed(3)),
  };
}
